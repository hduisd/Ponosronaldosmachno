package com.antcolony.registry;

import com.antcolony.AntColonyMod;
import com.antcolony.colony.AnthillBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    private ModBlockEntities() {}

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AntColonyMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnthillBlockEntity>> ANTHILL =
            BLOCK_ENTITIES.register("anthill",
                    () -> BlockEntityType.Builder.of(AnthillBlockEntity::new, ModBlocks.ANTHILL.get()).build(null));
}
