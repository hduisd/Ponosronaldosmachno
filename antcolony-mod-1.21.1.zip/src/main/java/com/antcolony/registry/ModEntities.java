package com.antcolony.registry;

import com.antcolony.AntColonyMod;
import com.antcolony.entity.AntBrood;
import com.antcolony.entity.AntPrincess;
import com.antcolony.entity.AntQueen;
import com.antcolony.entity.AntSoldier;
import com.antcolony.entity.AntWorker;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    private ModEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, AntColonyMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<AntWorker>> ANT_WORKER =
            ENTITY_TYPES.register("ant_worker", () -> EntityType.Builder.of(AntWorker::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("ant_worker"));

    public static final DeferredHolder<EntityType<?>, EntityType<AntSoldier>> ANT_SOLDIER =
            ENTITY_TYPES.register("ant_soldier", () -> EntityType.Builder.of(AntSoldier::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("ant_soldier"));

    /** Принцеса — молода крилата королева. Може з'являтися в світі природно. */
    public static final DeferredHolder<EntityType<?>, EntityType<AntPrincess>> ANT_PRINCESS =
            ENTITY_TYPES.register("ant_princess", () -> EntityType.Builder.of(AntPrincess::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("ant_princess"));

    /** Королева більша за інших (розмір моделі збільшується в рендерері на 20%). */
    public static final DeferredHolder<EntityType<?>, EntityType<AntQueen>> ANT_QUEEN =
            ENTITY_TYPES.register("ant_queen", () -> EntityType.Builder.of(AntQueen::new, MobCategory.MISC)
                    .sized(0.72F, 2.16F)
                    .clientTrackingRange(10)
                    .build("ant_queen"));

    /** Виводок: яйце, личинка, лялечка. */
    public static final DeferredHolder<EntityType<?>, EntityType<AntBrood>> ANT_BROOD =
            ENTITY_TYPES.register("ant_brood", () -> EntityType.Builder.of(AntBrood::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .clientTrackingRange(6)
                    .build("ant_brood"));
}
