package com.antcolony.registry;

import com.antcolony.AntColonyMod;
import com.antcolony.item.ColonyGuideItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AntColonyMod.MODID);

    public static final DeferredItem<BlockItem> ANTHILL = ITEMS.registerSimpleBlockItem("anthill", ModBlocks.ANTHILL);

    public static final DeferredItem<ColonyGuideItem> COLONY_GUIDE = ITEMS.register("colony_guide",
            () -> new ColonyGuideItem(new Item.Properties().stacksTo(1)));

    public static final DeferredItem<DeferredSpawnEggItem> ANT_WORKER_SPAWN_EGG = ITEMS.register("ant_worker_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ANT_WORKER, 0xB8682A, 0x5E3416, new Item.Properties()));

    public static final DeferredItem<DeferredSpawnEggItem> ANT_SOLDIER_SPAWN_EGG = ITEMS.register("ant_soldier_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ANT_SOLDIER, 0x7A1E1E, 0x2B0F0F, new Item.Properties()));

    public static final DeferredItem<DeferredSpawnEggItem> ANT_PRINCESS_SPAWN_EGG = ITEMS.register("ant_princess_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ANT_PRINCESS, 0xD6C2F0, 0xE0B84A, new Item.Properties()));
}
