package com.antcolony.registry;

import com.antcolony.AntColonyMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModTabs {
    private ModTabs() {}

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AntColonyMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.antcolony"))
                    .icon(() -> ModItems.ANTHILL.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.ANTHILL.get());
                        output.accept(ModItems.COLONY_GUIDE.get());
                        output.accept(ModItems.ANT_PRINCESS_SPAWN_EGG.get());
                        output.accept(ModItems.ANT_WORKER_SPAWN_EGG.get());
                        output.accept(ModItems.ANT_SOLDIER_SPAWN_EGG.get());
                    })
                    .build());
}
