package com.antcolony.registry;

import com.antcolony.AntColonyMod;
import com.antcolony.colony.AnthillBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    private ModBlocks() {}

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(AntColonyMod.MODID);

    public static final DeferredBlock<AnthillBlock> ANTHILL = BLOCKS.register("anthill",
            () -> new AnthillBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIRT)
                    .strength(1.2F)
                    .sound(SoundType.GRAVEL)));
}
