package com.antcolony.colony;

import net.minecraft.network.chat.Component;

/**
 * Касти мурах. Королева — одна на колонію; принцеса — молода крилата королева,
 * яка може заснувати нову колонію; робітниці й солдати — доросле населення.
 */
public enum AntCaste {
    QUEEN("queen"),
    PRINCESS("princess"),
    WORKER("worker"),
    SOLDIER("soldier");

    private final String id;

    AntCaste(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    /** Королівські касти можуть заснувати колонію. */
    public boolean isRoyal() {
        return this == QUEEN || this == PRINCESS;
    }

    public Component displayName() {
        return Component.translatable("caste.antcolony." + id);
    }

    public static AntCaste byOrdinal(int ordinal) {
        AntCaste[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : WORKER;
    }
}
