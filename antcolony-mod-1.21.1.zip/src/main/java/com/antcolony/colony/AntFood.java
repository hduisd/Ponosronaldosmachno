package com.antcolony.colony;

import com.antcolony.AntColonyMod;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Що мурахи вважають їжею. Список — у тегу data/antcolony/tags/item/ant_food.json. */
public final class AntFood {
    private AntFood() {}

    public static final TagKey<Item> TAG = TagKey.create(Registries.ITEM, AntColonyMod.id("ant_food"));

    public static boolean isFood(ItemStack stack) {
        return !stack.isEmpty() && stack.is(TAG);
    }

    /** Скільки одиниць їжі колонії дає ОДИН предмет. */
    public static int valueOf(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0;
        }
        if (stack.is(Items.SUGAR)) {
            return 3;
        }
        FoodProperties food = stack.get(DataComponents.FOOD);
        if (food != null) {
            return Math.max(1, food.nutrition() / 2);
        }
        return 1;
    }

    /** Загальна цінність всього стеку. */
    public static int totalValue(ItemStack stack) {
        return valueOf(stack) * stack.getCount();
    }
}
