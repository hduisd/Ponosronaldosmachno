package com.antcolony.colony;

import com.antcolony.ColonyConfig;
import com.antcolony.entity.AbstractAnt;
import com.antcolony.entity.AntBrood;
import com.antcolony.entity.AntPrincess;
import com.antcolony.entity.AntQueen;
import com.antcolony.registry.ModBlockEntities;
import com.antcolony.registry.ModEntities;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * «Мозок» колонії: склад їжі, життя королеви, відкладання яєць, вибір касти, шлюбний виліт, тривога.
 * Усе, що відбувається в колонії, рахується тут раз на секунду.
 */
public class AnthillBlockEntity extends BlockEntity {
    /** Скільки їжі всього принесено, щоб досягти рівня 1, 2, 3 ... */
    private static final int[] LEVEL_FOOD = {0, 30, 90, 220, 500, 1000, 2000};

    // ----- зберігається
    private boolean founded;
    private int food;
    private int totalFood;
    private int freeEggs;
    private int eggTimer;
    private int upkeepTimer;
    private int queenHunger;
    private int headless;
    private int nuptialCooldown;
    private CasteFocus focus = CasteFocus.BALANCED;

    // ----- тимчасове
    private int secondTick;
    private int alarmTicks;
    @Nullable
    private UUID alarmTarget;
    @Nullable
    private AntQueen queen;
    private boolean queenAlive;
    private int workers;
    private int soldiers;
    private int princesses;
    private int broodWorkers;
    private int broodSoldiers;
    private int broodPrincess;

    public AnthillBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ANTHILL.get(), pos, state);
    }

    // =====================================================================
    //  Цикл
    // =====================================================================

    public static void serverTick(Level level, BlockPos pos, BlockState state, AnthillBlockEntity anthill) {
        if (level instanceof ServerLevel server) {
            anthill.tick(server);
        }
    }

    private void tick(ServerLevel level) {
        if (alarmTicks > 0) {
            alarmTicks--;
        }
        if (++secondTick < 20) {
            return;
        }
        secondTick = 0;
        if (!areaLoaded(level)) {
            return;
        }
        census(level);
        if (founded) {
            colonyStep(level);
        }
    }

    /** Чи завантажені чанки навколо мурашника (інакше перепис мешканців був би хибним). */
    private boolean areaLoaded(ServerLevel level) {
        return level.hasChunkAt(worldPosition.offset(-16, 0, -16))
                && level.hasChunkAt(worldPosition.offset(16, 0, -16))
                && level.hasChunkAt(worldPosition.offset(-16, 0, 16))
                && level.hasChunkAt(worldPosition.offset(16, 0, 16));
    }

    /** Підрахунок мешканців колонії та виводку навколо мурашника. */
    private void census(ServerLevel level) {
        AABB box = new AABB(worldPosition).inflate(ColonyConfig.COLONY_RADIUS.get());
        workers = 0;
        soldiers = 0;
        princesses = 0;
        queen = null;
        queenAlive = false;
        for (AbstractAnt ant : level.getEntitiesOfClass(AbstractAnt.class, box, AbstractAnt::isAlive)) {
            if (ant instanceof AntPrincess) {
                princesses++;
                continue;
            }
            if (!worldPosition.equals(ant.getNestPos())) {
                continue;
            }
            if (ant instanceof AntQueen q) {
                queen = q;
                queenAlive = true;
            } else if (ant.caste() == AntCaste.SOLDIER) {
                soldiers++;
            } else {
                workers++;
            }
        }
        broodWorkers = 0;
        broodSoldiers = 0;
        broodPrincess = 0;
        for (AntBrood brood : level.getEntitiesOfClass(AntBrood.class, box,
                b -> b.isAlive() && worldPosition.equals(b.getNestPos()))) {
            if (brood.getCaste() == AntCaste.SOLDIER) {
                broodSoldiers++;
            } else if (brood.getCaste() == AntCaste.PRINCESS) {
                broodPrincess++;
            } else {
                broodWorkers++;
            }
        }
    }

    private void colonyStep(ServerLevel level) {
        if (queenAlive) {
            headless = 0;
        } else {
            headless++;
            if (ColonyConfig.QUEEN_LOSS_COLLAPSES.get() && headless >= ColonyConfig.QUEEN_LOSS_GRACE.get()) {
                collapse(level);
                return;
            }
        }
        if (++upkeepTimer >= 60) {
            upkeepTimer = 0;
            upkeep();
        }
        if (queen != null) {
            if (queenHunger >= 120) {
                queen.hurt(level.damageSources().starve(), 1.0F);
            } else if (queenHunger == 0 && queen.getHealth() < queen.getMaxHealth()) {
                queen.heal(0.5F);
            }
        }
        if (eggTimer > 0) {
            eggTimer--;
        }
        if (nuptialCooldown > 0) {
            nuptialCooldown--;
        }
        if (queenAlive && eggTimer <= 0) {
            tryLayEgg(level);
        }
        setChanged();
    }

    /** Раз на хвилину королева й доросле населення їдять із запасів. */
    private void upkeep() {
        if (queenAlive) {
            int need = ColonyConfig.QUEEN_FOOD_PER_MINUTE.get();
            if (food >= need) {
                food -= need;
                queenHunger = 0;
            } else {
                food = 0;
                queenHunger += 60;
            }
        }
        int perFood = ColonyConfig.ANTS_PER_FOOD.get();
        int adultsNeed = (workers + soldiers + perFood - 1) / perFood;
        food = Math.max(0, food - adultsNeed);
    }

    private void tryLayEgg(ServerLevel level) {
        int population = workers + soldiers + broodWorkers + broodSoldiers + broodPrincess;
        if (population >= capacity()) {
            return;
        }
        int cost = freeEggs > 0 ? 0 : ColonyConfig.EGG_FOOD_COST.get();
        if (food < cost) {
            return;
        }
        AntCaste caste = chooseCaste(level);
        Vec3 site = findBroodSite(level);
        AntBrood brood = ModEntities.ANT_BROOD.get().create(level);
        if (brood == null) {
            return;
        }
        brood.moveTo(site.x, site.y, site.z, level.random.nextFloat() * 360.0F, 0.0F);
        brood.setNestPos(worldPosition);
        brood.setCaste(caste);
        level.addFreshEntity(brood);

        food -= cost;
        if (freeEggs > 0) {
            freeEggs--;
        }
        if (caste == AntCaste.PRINCESS) {
            nuptialCooldown = ColonyConfig.NUPTIAL_COOLDOWN.get();
            broodPrincess++;
        } else if (caste == AntCaste.SOLDIER) {
            broodSoldiers++;
        } else {
            broodWorkers++;
        }
        int base = ColonyConfig.EGG_INTERVAL.get();
        eggTimer = Math.max(base / 2, base - (colonyLevel() - 1) * 3);
        level.playSound(null, worldPosition, SoundEvents.TURTLE_LAY_EGG, SoundSource.NEUTRAL, 0.6F, 1.3F);
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, site.x, site.y + 0.2D, site.z, 4, 0.2D, 0.1D, 0.2D, 0.0D);
    }

    /** Яка каста буде в нового яйця: потреби колонії + шанс на принцесу. */
    private AntCaste chooseCaste(ServerLevel level) {
        boolean nuptial = ColonyConfig.NUPTIAL_ENABLED.get()
                && colonyLevel() >= ColonyConfig.NUPTIAL_MIN_LEVEL.get()
                && food >= ColonyConfig.NUPTIAL_FOOD.get()
                && nuptialCooldown <= 0
                && princesses + broodPrincess == 0;
        if (nuptial && level.random.nextFloat() < 0.4F) {
            return AntCaste.PRINCESS;
        }
        int w = workers + broodWorkers;
        int s = soldiers + broodSoldiers;
        int total = w + s;
        if (total == 0) {
            return AntCaste.WORKER;
        }
        return (double) s / (double) total < focus.soldierRatio() ? AntCaste.SOLDIER : AntCaste.WORKER;
    }

    @Nullable
    private BlockPos findStandPos(ServerLevel level, double x, double z, double baseY) {
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        int by = Mth.floor(baseY);
        for (int dy = 1; dy >= -3; dy--) {
            BlockPos feet = new BlockPos(bx, by + dy, bz);
            BlockPos below = feet.below();
            if (level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                    && !level.getBlockState(below).getCollisionShape(level, below).isEmpty()) {
                return feet;
            }
        }
        return null;
    }

    private Vec3 findBroodSite(ServerLevel level) {
        double cx = queen != null ? queen.getX() : worldPosition.getX() + 0.5D;
        double cy = queen != null ? queen.getY() : worldPosition.getY() + 1.0D;
        double cz = queen != null ? queen.getZ() : worldPosition.getZ() + 0.5D;
        for (int i = 0; i < 14; i++) {
            double x = cx + (level.random.nextDouble() - 0.5D) * 5.0D;
            double z = cz + (level.random.nextDouble() - 0.5D) * 5.0D;
            BlockPos feet = findStandPos(level, x, z, cy);
            if (feet != null && !feet.equals(worldPosition.above())) {
                return new Vec3(x, feet.getY(), z);
            }
        }
        return new Vec3(cx, cy, cz);
    }

    /** Розпад колонії після загибелі королеви. Виводок гине, запаси втрачаються. */
    private void collapse(ServerLevel level) {
        founded = false;
        food = 0;
        freeEggs = 0;
        headless = 0;
        queenHunger = 0;
        eggTimer = 0;
        AABB box = new AABB(worldPosition).inflate(ColonyConfig.COLONY_RADIUS.get());
        for (AntBrood brood : level.getEntitiesOfClass(AntBrood.class, box, b -> worldPosition.equals(b.getNestPos()))) {
            brood.discard();
        }
        for (Player player : level.players()) {
            if (player.blockPosition().distSqr(worldPosition) < 64.0D * 64.0D) {
                player.displayClientMessage(Component.translatable("message.antcolony.collapsed")
                        .withStyle(ChatFormatting.RED), false);
            }
        }
        setChanged();
    }

    // =====================================================================
    //  Заснування колонії
    // =====================================================================

    /**
     * Спроба заснувати колонію: поруч має бути принцеса або «безхатня» королева.
     * Принцеса скидає крила й стає королевою колонії.
     */
    public boolean tryFound(ServerLevel level, @Nullable Player player) {
        if (founded) {
            return false;
        }
        AABB box = new AABB(worldPosition).inflate(ColonyConfig.FOUNDING_RADIUS.get());
        Vec3 center = Vec3.atCenterOf(worldPosition);
        AbstractAnt best = null;
        double bestDist = Double.MAX_VALUE;
        for (AbstractAnt ant : level.getEntitiesOfClass(AbstractAnt.class, box,
                a -> a.isAlive() && a.caste().isRoyal() && !a.hasNest())) {
            double d = ant.distanceToSqr(center);
            if (d < bestDist) {
                bestDist = d;
                best = ant;
            }
        }
        if (best == null) {
            if (player != null) {
                player.displayClientMessage(Component.translatable("message.antcolony.need_queen")
                        .withStyle(ChatFormatting.YELLOW), false);
            }
            return false;
        }
        AntQueen newQueen;
        if (best instanceof AntQueen existing) {
            newQueen = existing;
        } else {
            EntityType<AntQueen> type = ModEntities.ANT_QUEEN.get();
            newQueen = type.create(level);
            if (newQueen == null) {
                return false;
            }
            newQueen.moveTo(best.getX(), best.getY(), best.getZ(), best.getYRot(), 0.0F);
            if (best.hasCustomName()) {
                newQueen.setCustomName(best.getCustomName());
            }
            best.discard();
            level.addFreshEntity(newQueen);
        }
        newQueen.setNestPos(worldPosition);
        newQueen.moveTo(worldPosition.getX() + 0.5D, worldPosition.getY() + 1.0D, worldPosition.getZ() + 0.5D,
                newQueen.getYRot(), 0.0F);
        queen = newQueen;
        queenAlive = true;
        founded = true;
        freeEggs = ColonyConfig.FREE_EGGS.get();
        eggTimer = 8;
        upkeepTimer = 0;
        queenHunger = 0;
        headless = 0;
        level.playSound(null, worldPosition, SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 0.8F, 1.0F);
        level.sendParticles(ParticleTypes.HEART, worldPosition.getX() + 0.5D, worldPosition.getY() + 2.0D,
                worldPosition.getZ() + 0.5D, 8, 0.4D, 0.3D, 0.4D, 0.02D);
        if (player != null) {
            player.displayClientMessage(Component.translatable("message.antcolony.founded")
                    .withStyle(ChatFormatting.GREEN), false);
        }
        setChanged();
        return true;
    }

    // =====================================================================
    //  Склад їжі, рівень, місткість
    // =====================================================================

    public void deposit(int nutrition) {
        if (nutrition <= 0) {
            return;
        }
        food += nutrition;
        totalFood += nutrition;
        setChanged();
    }

    public boolean consumeFood(int amount) {
        if (food >= amount) {
            food -= amount;
            setChanged();
            return true;
        }
        return false;
    }

    public int colonyLevel() {
        int result = 1;
        for (int i = 1; i < LEVEL_FOOD.length; i++) {
            if (totalFood >= LEVEL_FOOD[i]) {
                result = i + 1;
            }
        }
        return result;
    }

    public int capacity() {
        return ColonyConfig.BASE_CAPACITY.get() + ColonyConfig.CAPACITY_PER_LEVEL.get() * (colonyLevel() - 1);
    }

    public boolean isFounded() {
        return founded;
    }

    public int getFood() {
        return food;
    }

    /**
     * Гравець несе їжу в мурашник: ПКМ їжею — уся їжа з руки йде на склад колонії.
     * (Shift з предметом у руці не доходить до блока — це робить сама гра, тому окремого режиму немає.)
     */
    public void feedFromPlayer(Player player, ItemStack stack) {
        int count = stack.getCount();
        int value = AntFood.valueOf(stack) * count;
        if (!player.getAbilities().instabuild) {
            stack.shrink(count);
        }
        deposit(value);
        player.displayClientMessage(Component.translatable("message.antcolony.fed", value, food), true);
        if (level != null) {
            level.playSound(null, worldPosition, SoundEvents.COMPOSTER_FILL, SoundSource.BLOCKS, 0.7F, 1.0F);
        }
        if (ColonyConfig.DEPOSIT_BOOST.get()) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0));
        }
    }

    // =====================================================================
    //  Дорослі мурахи
    // =====================================================================

    /** Нова доросла мураха вилуплюється з лялечки. */
    public void spawnAdult(ServerLevel level, AntCaste caste, double x, double y, double z) {
        EntityType<? extends AbstractAnt> type = switch (caste) {
            case SOLDIER -> ModEntities.ANT_SOLDIER.get();
            case PRINCESS -> ModEntities.ANT_PRINCESS.get();
            default -> ModEntities.ANT_WORKER.get();
        };
        AbstractAnt ant = type.create(level);
        if (ant == null) {
            return;
        }
        ant.moveTo(x, y, z, level.random.nextFloat() * 360.0F, 0.0F);
        if (ant instanceof AntPrincess princess) {
            princess.startNuptialFlight(ColonyConfig.PRINCESS_FLIGHT_MINUTES.get() * 60 * 20);
            for (Player player : level.players()) {
                if (player.blockPosition().distSqr(worldPosition) < 48.0D * 48.0D) {
                    player.displayClientMessage(Component.translatable("message.antcolony.princess_born")
                            .withStyle(ChatFormatting.LIGHT_PURPLE), false);
                }
            }
        } else {
            ant.setNestPos(worldPosition);
        }
        level.addFreshEntity(ant);
        level.playSound(null, worldPosition, SoundEvents.TURTLE_EGG_HATCH, SoundSource.NEUTRAL, 0.7F, 1.0F);
    }

    // =====================================================================
    //  Тривога
    // =====================================================================

    public void raiseAlarm(LivingEntity attacker) {
        alarmTarget = attacker.getUUID();
        alarmTicks = 300;
    }

    @Nullable
    public LivingEntity alarmTarget(ServerLevel level) {
        if (alarmTicks <= 0 || alarmTarget == null) {
            return null;
        }
        return level.getEntity(alarmTarget) instanceof LivingEntity living && living.isAlive() ? living : null;
    }

    // =====================================================================
    //  Взаємодія гравця
    // =====================================================================

    public void interact(ServerLevel level, Player player) {
        if (!founded) {
            if (!tryFound(level, player)) {
                player.sendSystemMessage(Component.translatable("info.antcolony.unfounded"));
            }
            return;
        }
        if (player.isShiftKeyDown()) {
            focus = focus.next();
            setChanged();
            player.displayClientMessage(Component.translatable("message.antcolony.focus", focus.displayName()), true);
            return;
        }
        census(level);
        sendInfo(player);
    }

    public void sendInfo(Player player) {
        player.sendSystemMessage(Component.translatable("info.antcolony.header", colonyLevel())
                .withStyle(ChatFormatting.GOLD));
        if (!founded) {
            player.sendSystemMessage(Component.translatable("info.antcolony.unfounded"));
            return;
        }
        player.sendSystemMessage(Component.translatable(queenAlive ? "info.antcolony.queen_alive" : "info.antcolony.queen_missing",
                queenHunger >= 60 ? Component.translatable("info.antcolony.hungry") : Component.empty()));
        player.sendSystemMessage(Component.translatable("info.antcolony.food", food, totalFood));
        player.sendSystemMessage(Component.translatable("info.antcolony.population", workers, soldiers, capacity()));
        player.sendSystemMessage(Component.translatable("info.antcolony.brood",
                broodWorkers + broodSoldiers + broodPrincess));
        player.sendSystemMessage(Component.translatable("info.antcolony.focus", focus.displayName()));
    }

    // =====================================================================
    //  Збереження
    // =====================================================================

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putBoolean("Founded", founded);
        tag.putInt("Food", food);
        tag.putInt("TotalFood", totalFood);
        tag.putInt("FreeEggs", freeEggs);
        tag.putInt("EggTimer", eggTimer);
        tag.putInt("UpkeepTimer", upkeepTimer);
        tag.putInt("QueenHunger", queenHunger);
        tag.putInt("Headless", headless);
        tag.putInt("NuptialCooldown", nuptialCooldown);
        tag.putInt("Focus", focus.ordinal());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        founded = tag.getBoolean("Founded");
        food = tag.getInt("Food");
        totalFood = tag.getInt("TotalFood");
        freeEggs = tag.getInt("FreeEggs");
        eggTimer = tag.getInt("EggTimer");
        upkeepTimer = tag.getInt("UpkeepTimer");
        queenHunger = tag.getInt("QueenHunger");
        headless = tag.getInt("Headless");
        nuptialCooldown = tag.getInt("NuptialCooldown");
        focus = CasteFocus.byOrdinal(tag.getInt("Focus"));
    }
}
