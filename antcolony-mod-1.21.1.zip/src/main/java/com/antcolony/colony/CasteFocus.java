package com.antcolony.colony;

import com.antcolony.ColonyConfig;
import net.minecraft.network.chat.Component;

/** На кого колонія робить наголос при виборі касти нових мурах (перемикається Shift + ПКМ по мурашнику). */
public enum CasteFocus {
    BALANCED("balanced"),
    WORKERS("workers"),
    SOLDIERS("soldiers");

    private final String id;

    CasteFocus(String id) {
        this.id = id;
    }

    public Component displayName() {
        return Component.translatable("focus.antcolony." + id);
    }

    public CasteFocus next() {
        CasteFocus[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    /** Бажана частка солдатів серед дорослих. */
    public double soldierRatio() {
        return switch (this) {
            case BALANCED -> ColonyConfig.SOLDIER_RATIO.get();
            case WORKERS -> Math.min(0.10D, ColonyConfig.SOLDIER_RATIO.get());
            case SOLDIERS -> Math.max(0.55D, ColonyConfig.SOLDIER_RATIO.get());
        };
    }

    public static CasteFocus byOrdinal(int ordinal) {
        CasteFocus[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : BALANCED;
    }
}
