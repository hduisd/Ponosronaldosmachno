package com.antcolony.colony;

import net.minecraft.network.chat.Component;

/** Накази гравця мурахам (ПКМ порожньою рукою по робітниці або солдату). */
public enum AntOrder {
    WORK("work"),
    FOLLOW("follow"),
    STAY("stay");

    private final String id;

    AntOrder(String id) {
        this.id = id;
    }

    public Component displayName() {
        return Component.translatable("order.antcolony." + id);
    }

    public AntOrder next() {
        AntOrder[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    public static AntOrder byOrdinal(int ordinal) {
        AntOrder[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : WORK;
    }
}
