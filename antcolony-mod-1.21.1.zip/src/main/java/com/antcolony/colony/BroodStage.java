package com.antcolony.colony;

import net.minecraft.network.chat.Component;

/** Стадії розвитку виводку: яйце → личинка → лялечка → доросла мураха. */
public enum BroodStage {
    EGG("egg"),
    LARVA("larva"),
    PUPA("pupa");

    private final String id;

    BroodStage(String id) {
        this.id = id;
    }

    public Component displayName() {
        return Component.translatable("stage.antcolony." + id);
    }

    public boolean isLast() {
        return this == PUPA;
    }

    public BroodStage next() {
        return isLast() ? this : values()[ordinal() + 1];
    }

    public static BroodStage byOrdinal(int ordinal) {
        BroodStage[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : EGG;
    }
}
