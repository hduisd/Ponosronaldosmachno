package com.antcolony.entity;

import com.antcolony.ColonyConfig;
import com.antcolony.colony.AntCaste;
import com.antcolony.colony.AntOrder;
import com.antcolony.entity.goal.FollowOrderGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * Принцеса — молода крилата королева. Може стати королевою нової колонії:
 * підгодуй її цукром (піде за тобою), приведи на місце й постав Мурашник поруч.
 * Принцеси, народжені колонією, через кілька хвилин відлітають у шлюбний виліт.
 */
public class AntPrincess extends AbstractAnt {
    /** Скільки тіків лишилось до шлюбного вильоту (-1 — не відлітає). */
    private int flightTicks = -1;

    public AntPrincess(EntityType<? extends AntPrincess> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 18.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D);
    }

    @Override
    public AntCaste caste() {
        return AntCaste.PRINCESS;
    }

    @Override
    protected boolean takesOrders() {
        return false;
    }

    public void startNuptialFlight(int ticks) {
        this.flightTicks = ticks;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.5D));
        this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Monster.class, 8.0F, 1.0D, 1.3D));
        this.goalSelector.addGoal(3, new FollowOrderGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.SUGAR)) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                setOrder(AntOrder.FOLLOW);
                setFollowId(player.getUUID());
                flightTicks = -1;
                if (level() instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.8D, getZ(), 5, 0.3D, 0.3D, 0.3D, 0.02D);
                }
                player.displayClientMessage(Component.translatable("message.antcolony.princess_follow"), true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (hand == InteractionHand.MAIN_HAND && held.isEmpty()) {
            if (!level().isClientSide) {
                player.sendSystemMessage(Component.translatable("message.antcolony.princess_hint"));
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (flightTicks > 0 && getOrder() != AntOrder.FOLLOW && --flightTicks == 0) {
            takeOff();
        }
    }

    private void takeOff() {
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.0D, getZ(), 20, 0.4D, 0.6D, 0.4D, 0.05D);
            for (Player player : server.players()) {
                if (player.distanceToSqr(this) < 48.0D * 48.0D) {
                    player.displayClientMessage(Component.translatable("message.antcolony.princess_flew"), false);
                }
            }
        }
        discard();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("FlightTicks", flightTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        flightTicks = tag.contains("FlightTicks") ? tag.getInt("FlightTicks") : -1;
    }

    /** Умови природної появи дикої принцеси: трава/земля, світло. */
    public static boolean checkSpawnRules(EntityType<AntPrincess> type, ServerLevelAccessor level, MobSpawnType spawnType,
                                          BlockPos pos, RandomSource random) {
        if (!ColonyConfig.WILD_PRINCESS_SPAWN.get()
                && (spawnType == MobSpawnType.NATURAL || spawnType == MobSpawnType.CHUNK_GENERATION)) {
            return false;
        }
        return level.getBlockState(pos.below()).is(BlockTags.DIRT) && level.getRawBrightness(pos, 0) > 8;
    }
}
