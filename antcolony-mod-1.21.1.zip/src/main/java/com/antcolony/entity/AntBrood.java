package com.antcolony.entity;

import com.antcolony.ColonyConfig;
import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntCaste;
import com.antcolony.colony.BroodStage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Виводок: яйце → личинка (її годують із запасів колонії) → лялечка → доросла мураха.
 * Касту майбутньої мурахи визначає мурашник у момент відкладання яйця.
 */
public class AntBrood extends Entity {
    private static final EntityDataAccessor<Integer> DATA_STAGE =
            SynchedEntityData.defineId(AntBrood.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_CASTE =
            SynchedEntityData.defineId(AntBrood.class, EntityDataSerializers.INT);

    @Nullable
    private BlockPos nestPos;
    private int stageTicks;
    private int fed;
    private int starveTicks;
    private int orphanTicks;

    public AntBrood(EntityType<? extends AntBrood> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_STAGE, BroodStage.EGG.ordinal());
        builder.define(DATA_CASTE, AntCaste.WORKER.ordinal());
    }

    // ------------------------------------------------------------ дані

    public BroodStage getStage() {
        return BroodStage.byOrdinal(this.entityData.get(DATA_STAGE));
    }

    private void setStage(BroodStage stage) {
        this.entityData.set(DATA_STAGE, stage.ordinal());
    }

    public AntCaste getCaste() {
        return AntCaste.byOrdinal(this.entityData.get(DATA_CASTE));
    }

    public void setCaste(AntCaste caste) {
        this.entityData.set(DATA_CASTE, caste.ordinal());
    }

    @Nullable
    public BlockPos getNestPos() {
        return nestPos;
    }

    public void setNestPos(@Nullable BlockPos pos) {
        this.nestPos = pos == null ? null : pos.immutable();
    }

    @Nullable
    public AnthillBlockEntity getNest() {
        if (nestPos == null || !level().hasChunkAt(nestPos)) {
            return null;
        }
        return level().getBlockEntity(nestPos) instanceof AnthillBlockEntity anthill ? anthill : null;
    }

    /** Множник розміру моделі: майбутні принцеси й солдати трохи більші. */
    public float sizeScale() {
        return switch (getCaste()) {
            case PRINCESS, QUEEN -> 1.5F;
            case SOLDIER -> 1.2F;
            default -> 1.0F;
        };
    }

    // ------------------------------------------------------------ розвиток

    @Override
    public void tick() {
        super.tick();
        Level lvl = level();
        if (lvl.isClientSide || !(lvl instanceof ServerLevel server)) {
            return;
        }
        AnthillBlockEntity anthill = getNest();
        if (anthill == null || !anthill.isFounded()) {
            if (nestPos != null && !server.hasChunkAt(nestPos)) {
                return;
            }
            if (++orphanTicks > 200) {
                perish(server);
            }
            return;
        }
        orphanTicks = 0;
        stageTicks++;
        switch (getStage()) {
            case EGG -> {
                if (stageTicks >= ColonyConfig.EGG_SECONDS.get() * 20) {
                    advance(server);
                }
            }
            case LARVA -> tickLarva(server, anthill);
            case PUPA -> {
                if (stageTicks >= ColonyConfig.PUPA_SECONDS.get() * 20) {
                    hatch(server, anthill);
                }
            }
        }
    }

    private void tickLarva(ServerLevel server, AnthillBlockEntity anthill) {
        int needed = ColonyConfig.LARVA_FEEDINGS.get();
        if (stageTicks % 100 == 0 && fed < needed) {
            if (anthill.consumeFood(1)) {
                fed++;
                starveTicks = 0;
            } else {
                starveTicks += 100;
            }
        }
        if (starveTicks >= 2400) {
            perish(server);
            return;
        }
        if (fed >= needed && stageTicks >= ColonyConfig.LARVA_SECONDS.get() * 20) {
            advance(server);
        }
    }

    private void advance(ServerLevel server) {
        setStage(getStage().next());
        stageTicks = 0;
        server.playSound(null, blockPosition(), SoundEvents.TURTLE_EGG_CRACK, SoundSource.NEUTRAL, 0.5F, 1.1F);
        server.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.2D, getZ(), 3, 0.1D, 0.05D, 0.1D, 0.0D);
    }

    private void hatch(ServerLevel server, AnthillBlockEntity anthill) {
        anthill.spawnAdult(server, getCaste(), getX(), getY(), getZ());
        server.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 0.5D, getZ(), 6, 0.3D, 0.3D, 0.3D, 0.0D);
        discard();
    }

    private void perish(ServerLevel server) {
        server.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 0.2D, getZ(), 5, 0.15D, 0.05D, 0.15D, 0.01D);
        discard();
    }

    // ------------------------------------------------------------ взаємодія

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (isInvulnerableTo(source)) {
            return false;
        }
        if (level() instanceof ServerLevel server) {
            AnthillBlockEntity anthill = getNest();
            if (anthill != null && source.getEntity() instanceof LivingEntity attacker
                    && !(attacker instanceof AbstractAnt) && !(attacker instanceof Player)) {
                anthill.raiseAlarm(attacker);
            }
            perish(server);
        }
        return true;
    }

    // ------------------------------------------------------------ збереження

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Stage", getStage().ordinal());
        tag.putInt("Caste", getCaste().ordinal());
        tag.putInt("StageTicks", stageTicks);
        tag.putInt("Fed", fed);
        tag.putInt("Starve", starveTicks);
        if (nestPos != null) {
            tag.putLong("NestPos", nestPos.asLong());
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setStage(BroodStage.byOrdinal(tag.getInt("Stage")));
        setCaste(AntCaste.byOrdinal(tag.getInt("Caste")));
        stageTicks = tag.getInt("StageTicks");
        fed = tag.getInt("Fed");
        starveTicks = tag.getInt("Starve");
        nestPos = tag.contains("NestPos") ? BlockPos.of(tag.getLong("NestPos")) : null;
    }
}
