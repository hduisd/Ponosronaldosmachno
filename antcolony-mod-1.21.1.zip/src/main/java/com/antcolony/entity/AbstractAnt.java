package com.antcolony.entity;

import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntCaste;
import com.antcolony.colony.AntOrder;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Спільна основа всіх мурах-дівчат: належність до колонії (позиція мурашника), накази гравця, звуки.
 * Моделі — як у гравця (див. клієнтський AntRenderer).
 */
public abstract class AbstractAnt extends PathfinderMob {
    @Nullable
    private BlockPos nestPos;
    private AntOrder order = AntOrder.WORK;
    @Nullable
    private UUID followId;

    protected AbstractAnt(EntityType<? extends AbstractAnt> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder baseAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D)
                // Мурахи вміють залазити на повний блок (наприклад, на мурашник).
                .add(Attributes.STEP_HEIGHT, 1.0D);
    }

    public abstract AntCaste caste();

    // ------------------------------------------------------------ колонія

    @Nullable
    public BlockPos getNestPos() {
        return nestPos;
    }

    public boolean hasNest() {
        return nestPos != null;
    }

    public void setNestPos(@Nullable BlockPos pos) {
        this.nestPos = pos == null ? null : pos.immutable();
    }

    @Nullable
    public AnthillBlockEntity getNest() {
        if (nestPos == null || !level().hasChunkAt(nestPos)) {
            return null;
        }
        return level().getBlockEntity(nestPos) instanceof AnthillBlockEntity anthill ? anthill : null;
    }

    // ------------------------------------------------------------ накази

    public AntOrder getOrder() {
        return order;
    }

    public void setOrder(AntOrder order) {
        this.order = order;
    }

    @Nullable
    public UUID getFollowId() {
        return followId;
    }

    public void setFollowId(@Nullable UUID followId) {
        this.followId = followId;
    }

    /** Чи слухається ця мураха наказів гравця (робітниці й солдати — так). */
    protected boolean takesOrders() {
        return true;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND || !takesOrders() || !player.getItemInHand(hand).isEmpty()) {
            return super.mobInteract(player, hand);
        }
        if (!level().isClientSide) {
            AntOrder next = order.next();
            order = next;
            if (next == AntOrder.FOLLOW) {
                followId = player.getUUID();
            }
            getNavigation().stop();
            player.displayClientMessage(Component.translatable("message.antcolony.order", getDisplayName(),
                    next.displayName()), true);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    // ------------------------------------------------------------ життя

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && !level().isClientSide
                && source.getEntity() instanceof LivingEntity attacker
                && !(attacker instanceof AbstractAnt)
                && !(attacker instanceof Player)) {
            AnthillBlockEntity anthill = getNest();
            if (anthill != null) {
                anthill.raiseAlarm(attacker);
            }
        }
        return result;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        // Якщо мурашник зруйновано — мураха стає «безхатьком» і може приєднатися до нової колонії.
        if (nestPos != null && tickCount % 100 == 0 && level().hasChunkAt(nestPos)
                && !(level().getBlockEntity(nestPos) instanceof AnthillBlockEntity)) {
            nestPos = null;
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (nestPos != null) {
            tag.putLong("NestPos", nestPos.asLong());
        }
        tag.putInt("Order", order.ordinal());
        if (followId != null) {
            tag.putUUID("FollowId", followId);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        nestPos = tag.contains("NestPos") ? BlockPos.of(tag.getLong("NestPos")) : null;
        order = AntOrder.byOrdinal(tag.getInt("Order"));
        followId = tag.hasUUID("FollowId") ? tag.getUUID("FollowId") : null;
    }

    // ------------------------------------------------------------ звуки (комашині)

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.SILVERFISH_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SILVERFISH_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SILVERFISH_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.SILVERFISH_STEP, 0.12F, 1.0F);
    }
}
