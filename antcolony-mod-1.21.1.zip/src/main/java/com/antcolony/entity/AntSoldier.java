package com.antcolony.entity;

import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntCaste;
import com.antcolony.entity.goal.FollowOrderGoal;
import com.antcolony.entity.goal.GuardTargetGoal;
import com.antcolony.entity.goal.NestStrollGoal;
import com.antcolony.entity.goal.ReturnToNestGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/** Солдат: охороняє колонію від ворожих мобів і відповідає на напад. */
public class AntSoldier extends AbstractAnt {
    public AntSoldier(EntityType<? extends AntSoldier> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 26.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.29D)
                .add(Attributes.ARMOR, 4.0D);
    }

    @Override
    public AntCaste caste() {
        return AntCaste.SOLDIER;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(2, new FollowOrderGoal(this));
        this.goalSelector.addGoal(3, new ReturnToNestGoal(this, 1.0D, 30));
        this.goalSelector.addGoal(4, new NestStrollGoal(this, 0.7D, 14));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new GuardTargetGoal(this));
    }

    /** Загроза для колонії: об'єкт тривоги або найближчий ворожий моб поблизу мурашника. */
    @Nullable
    public LivingEntity findThreat() {
        BlockPos nest = getNestPos();
        BlockPos home = nest != null ? nest : blockPosition();
        if (level() instanceof ServerLevel server) {
            AnthillBlockEntity anthill = getNest();
            if (anthill != null) {
                LivingEntity alarm = anthill.alarmTarget(server);
                if (alarm != null && alarm != this && !(alarm instanceof AbstractAnt)) {
                    return alarm;
                }
            }
        }
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity candidate : level().getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().inflate(14.0D, 6.0D, 14.0D),
                c -> c instanceof Enemy && c.isAlive() && c != this
                        && c.blockPosition().distSqr(home) <= 40.0D * 40.0D)) {
            double d = distanceToSqr(candidate);
            if (d < bestDist) {
                bestDist = d;
                best = candidate;
            }
        }
        return best;
    }
}
