package com.antcolony.entity;

import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntCaste;
import com.antcolony.colony.AntFood;
import com.antcolony.entity.goal.DepositFoodGoal;
import com.antcolony.entity.goal.FollowOrderGoal;
import com.antcolony.entity.goal.ForageFoodGoal;
import com.antcolony.entity.goal.NestStrollGoal;
import com.antcolony.entity.goal.ReturnToNestGoal;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Робітниця: збирає їжу, носить її в мурашник, ходить за гравцем за наказом. */
public class AntWorker extends AbstractAnt {
    public AntWorker(EntityType<? extends AntWorker> type, Level level) {
        super(type, level);
        // Якщо робітниця загине з їжею в руках — їжа випаде (шанс > 1 означає «випадає завжди»).
        this.setDropChance(EquipmentSlot.MAINHAND, 2.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes().add(Attributes.MAX_HEALTH, 14.0D);
    }

    @Override
    public AntCaste caste() {
        return AntCaste.WORKER;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new DepositFoodGoal(this));
        this.goalSelector.addGoal(3, new FollowOrderGoal(this));
        this.goalSelector.addGoal(4, new ForageFoodGoal(this));
        this.goalSelector.addGoal(5, new ReturnToNestGoal(this, 1.0D, 28));
        this.goalSelector.addGoal(6, new NestStrollGoal(this, 0.8D, 12));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    public boolean isCarrying() {
        return !getMainHandItem().isEmpty();
    }

    public void setCarried(ItemStack stack) {
        setItemSlot(EquipmentSlot.MAINHAND, stack);
    }

    /** Віднести їжу до мурашника: вона йде на склад колонії. */
    public void depositCarried(AnthillBlockEntity anthill) {
        ItemStack carried = getMainHandItem();
        if (AntFood.isFood(carried)) {
            anthill.deposit(AntFood.totalValue(carried));
            playSound(SoundEvents.ITEM_PICKUP, 0.25F, 1.3F);
        }
        setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }
}
