package com.antcolony.entity;

import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntCaste;
import com.antcolony.entity.goal.NestStrollGoal;
import com.antcolony.entity.goal.ReturnToNestGoal;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Королева — одна на колонію. Живе біля мурашника, відкладає яйця (це робить мурашник),
 * їсть із запасів. Загине — колонія розпадеться. Гравцем королева бути не може.
 */
public class AntQueen extends AbstractAnt {
    public AntQueen(EntityType<? extends AntQueen> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes()
                .add(Attributes.MAX_HEALTH, 60.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.ARMOR, 4.0D);
    }

    @Override
    public AntCaste caste() {
        return AntCaste.QUEEN;
    }

    @Override
    protected boolean takesOrders() {
        return false;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ReturnToNestGoal(this, 0.8D, 5));
        this.goalSelector.addGoal(2, new NestStrollGoal(this, 0.6D, 4));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (!level().isClientSide) {
            AnthillBlockEntity anthill = getNest();
            if (anthill != null) {
                anthill.sendInfo(player);
            } else {
                player.sendSystemMessage(Component.translatable("message.antcolony.queen_homeless"));
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }
}
