package com.antcolony.entity.goal;

import com.antcolony.colony.AntOrder;
import com.antcolony.entity.AbstractAnt;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

/** Мураха, що забрела далеко від мурашника, повертається додому. */
public class ReturnToNestGoal extends Goal {
    private final AbstractAnt ant;
    private final double speed;
    private final int maxDistance;
    private int repath;

    public ReturnToNestGoal(AbstractAnt ant, double speed, int maxDistance) {
        this.ant = ant;
        this.speed = speed;
        this.maxDistance = maxDistance;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        BlockPos home = ant.getNestPos();
        if (home == null || ant.getOrder() != AntOrder.WORK) {
            return false;
        }
        return ant.blockPosition().distSqr(home) > (double) maxDistance * maxDistance;
    }

    @Override
    public boolean canContinueToUse() {
        BlockPos home = ant.getNestPos();
        if (home == null || ant.getOrder() != AntOrder.WORK) {
            return false;
        }
        double half = maxDistance * 0.5D;
        return ant.blockPosition().distSqr(home) > half * half;
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        ant.getNavigation().stop();
    }

    @Override
    public void tick() {
        BlockPos home = ant.getNestPos();
        if (home == null) {
            return;
        }
        if (--repath <= 0) {
            repath = 15;
            ant.getNavigation().moveTo(home.getX() + 0.5D, home.getY() + 1.0D, home.getZ() + 0.5D, speed);
        }
    }
}
