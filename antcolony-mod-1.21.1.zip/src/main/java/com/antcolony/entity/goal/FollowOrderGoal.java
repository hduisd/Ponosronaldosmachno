package com.antcolony.entity.goal;

import com.antcolony.colony.AntOrder;
import com.antcolony.entity.AbstractAnt;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

/** Наказ «Йти за мною»: мураха супроводжує гравця, який дав наказ. */
public class FollowOrderGoal extends Goal {
    private final AbstractAnt ant;
    @Nullable
    private Player player;
    private int repath;

    public FollowOrderGoal(AbstractAnt ant) {
        this.ant = ant;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        UUID id = ant.getFollowId();
        if (ant.getOrder() != AntOrder.FOLLOW || id == null) {
            return false;
        }
        Player found = ant.level().getPlayerByUUID(id);
        if (found == null || found.isSpectator() || !found.isAlive()) {
            return false;
        }
        if (ant.distanceToSqr(found) < 9.0D) {
            return false;
        }
        player = found;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return ant.getOrder() == AntOrder.FOLLOW
                && player != null && player.isAlive() && !player.isSpectator()
                && ant.distanceToSqr(player) > 4.0D;
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        player = null;
        ant.getNavigation().stop();
    }

    @Override
    public void tick() {
        Player target = player;
        if (target == null) {
            return;
        }
        ant.getLookControl().setLookAt(target, 10.0F, (float) ant.getMaxHeadXRot());
        if (--repath > 0) {
            return;
        }
        repath = 10;
        if (ant.distanceToSqr(target) > 28.0D * 28.0D) {
            ant.getNavigation().stop();
            ant.moveTo(target.getX(), target.getY(), target.getZ(), ant.getYRot(), ant.getXRot());
        } else {
            ant.getNavigation().moveTo(target, 1.2D);
        }
    }
}
