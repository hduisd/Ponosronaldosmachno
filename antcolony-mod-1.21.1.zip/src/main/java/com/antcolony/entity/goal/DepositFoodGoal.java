package com.antcolony.entity.goal;

import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntOrder;
import com.antcolony.entity.AntWorker;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/** Робітниця з їжею в руках несе її до мурашника й здає на склад колонії. */
public class DepositFoodGoal extends Goal {
    private final AntWorker ant;
    private int repath;

    public DepositFoodGoal(AntWorker ant) {
        this.ant = ant;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (ant.getOrder() == AntOrder.STAY || !ant.isCarrying()) {
            return false;
        }
        AnthillBlockEntity anthill = ant.getNest();
        return anthill != null && anthill.isFounded();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        ant.getNavigation().stop();
    }

    @Override
    public void tick() {
        BlockPos home = ant.getNestPos();
        if (home == null) {
            return;
        }
        if (ant.distanceToSqr(Vec3.atCenterOf(home)) <= 9.0D) {
            AnthillBlockEntity anthill = ant.getNest();
            if (anthill != null) {
                ant.depositCarried(anthill);
            }
            ant.getNavigation().stop();
            return;
        }
        if (--repath <= 0) {
            repath = 10;
            ant.getNavigation().moveTo(home.getX() + 0.5D, home.getY() + 1.0D, home.getZ() + 0.5D, 1.15D);
        }
    }
}
