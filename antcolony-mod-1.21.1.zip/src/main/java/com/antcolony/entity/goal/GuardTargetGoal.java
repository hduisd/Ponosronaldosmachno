package com.antcolony.entity.goal;

import com.antcolony.entity.AntSoldier;
import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import org.jetbrains.annotations.Nullable;

/** Солдат вибирає ціль: загрозу, про яку просигналізувала колонія, або ворожого моба поблизу. */
public class GuardTargetGoal extends TargetGoal {
    private final AntSoldier soldier;
    @Nullable
    private LivingEntity candidate;

    public GuardTargetGoal(AntSoldier soldier) {
        super(soldier, false);
        this.soldier = soldier;
        this.setFlags(EnumSet.of(Goal.Flag.TARGET));
    }

    @Override
    public boolean canUse() {
        if (soldier.getRandom().nextInt(4) != 0) {
            return false;
        }
        candidate = soldier.findThreat();
        return candidate != null;
    }

    @Override
    public void start() {
        soldier.setTarget(candidate);
        super.start();
    }
}
