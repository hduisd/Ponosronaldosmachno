package com.antcolony.entity.goal;

import com.antcolony.ColonyConfig;
import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.colony.AntFood;
import com.antcolony.colony.AntOrder;
import com.antcolony.entity.AntWorker;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

/** Вільна робітниця шукає їжу, що лежить на землі поблизу мурашника, і підбирає її. */
public class ForageFoodGoal extends Goal {
    private final AntWorker ant;
    @Nullable
    private ItemEntity target;
    private int cooldown;
    private int repath;

    public ForageFoodGoal(AntWorker ant) {
        this.ant = ant;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (ant.getOrder() != AntOrder.WORK || ant.isCarrying()) {
            return false;
        }
        if (--cooldown > 0) {
            return false;
        }
        cooldown = 10;
        AnthillBlockEntity anthill = ant.getNest();
        BlockPos home = ant.getNestPos();
        if (anthill == null || home == null || !anthill.isFounded()) {
            return false;
        }
        double radius = ColonyConfig.FORAGING_RADIUS.get();
        double radiusSq = radius * radius;
        ItemEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (ItemEntity item : ant.level().getEntitiesOfClass(ItemEntity.class,
                ant.getBoundingBox().inflate(16.0D, 6.0D, 16.0D),
                e -> e.isAlive() && AntFood.isFood(e.getItem()) && e.blockPosition().distSqr(home) <= radiusSq)) {
            double d = ant.distanceToSqr(item);
            if (d < bestDist) {
                bestDist = d;
                best = item;
            }
        }
        target = best;
        return best != null;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && !ant.isCarrying() && ant.getOrder() == AntOrder.WORK;
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        target = null;
        ant.getNavigation().stop();
    }

    @Override
    public void tick() {
        ItemEntity item = target;
        if (item == null) {
            return;
        }
        ant.getLookControl().setLookAt(item, 30.0F, 30.0F);
        if (ant.distanceToSqr(item) < 2.5D) {
            pickUp(item);
            return;
        }
        if (--repath <= 0) {
            repath = 10;
            ant.getNavigation().moveTo(item, 1.1D);
        }
    }

    private void pickUp(ItemEntity item) {
        ItemStack stack = item.getItem();
        int take = Math.min(stack.getCount(), ColonyConfig.CARRY_AMOUNT.get());
        ant.setCarried(stack.copyWithCount(take));
        if (stack.getCount() <= take) {
            item.discard();
        } else {
            item.setItem(stack.copyWithCount(stack.getCount() - take));
        }
        ant.playSound(SoundEvents.ITEM_PICKUP, 0.2F, 1.4F);
        target = null;
    }
}
