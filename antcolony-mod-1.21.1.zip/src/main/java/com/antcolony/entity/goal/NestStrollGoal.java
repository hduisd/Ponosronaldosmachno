package com.antcolony.entity.goal;

import com.antcolony.colony.AntOrder;
import com.antcolony.entity.AbstractAnt;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** Неквапливо гуляє поблизу мурашника (не далі за radius блоків). Не діє, якщо мурасі наказано стояти чи йти за гравцем. */
public class NestStrollGoal extends RandomStrollGoal {
    private final AbstractAnt ant;
    private final int radius;

    public NestStrollGoal(AbstractAnt ant, double speed, int radius) {
        super(ant, speed, 90);
        this.ant = ant;
        this.radius = radius;
    }

    @Override
    public boolean canUse() {
        return ant.getOrder() == AntOrder.WORK && super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        return ant.getOrder() == AntOrder.WORK && super.canContinueToUse();
    }

    @Nullable
    @Override
    protected Vec3 getPosition() {
        BlockPos home = ant.getNestPos();
        if (home != null) {
            Vec3 center = Vec3.atBottomCenterOf(home);
            if (ant.position().distanceToSqr(center) > (double) radius * radius) {
                Vec3 back = LandRandomPos.getPosTowards(ant, 8, 5, center);
                if (back != null) {
                    return back;
                }
            }
        }
        return super.getPosition();
    }
}
