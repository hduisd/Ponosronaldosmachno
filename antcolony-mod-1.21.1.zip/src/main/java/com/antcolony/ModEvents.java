package com.antcolony;

import com.antcolony.entity.AntPrincess;
import com.antcolony.entity.AntQueen;
import com.antcolony.entity.AntSoldier;
import com.antcolony.entity.AntWorker;
import com.antcolony.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

/** Події шини мода (спільні для клієнта й сервера): атрибути істот і правила появи принцес. */
@EventBusSubscriber(modid = AntColonyMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void onEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ANT_WORKER.get(), AntWorker.createAttributes().build());
        event.put(ModEntities.ANT_SOLDIER.get(), AntSoldier.createAttributes().build());
        event.put(ModEntities.ANT_PRINCESS.get(), AntPrincess.createAttributes().build());
        event.put(ModEntities.ANT_QUEEN.get(), AntQueen.createAttributes().build());
    }

    @SubscribeEvent
    public static void onSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(ModEntities.ANT_PRINCESS.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, AntPrincess::checkSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.OR);
    }
}
