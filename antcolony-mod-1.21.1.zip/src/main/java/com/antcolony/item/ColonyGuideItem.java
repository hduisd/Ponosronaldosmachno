package com.antcolony.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** «Мурашиний довідник»: ПКМ — короткі правила гри в чат. */
public class ColonyGuideItem extends Item {
    private static final int LINES = 9;

    public ColonyGuideItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            sendGuide(player);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    public static void sendGuide(Player player) {
        player.sendSystemMessage(Component.translatable("guide.antcolony.title"));
        for (int i = 1; i <= LINES; i++) {
            player.sendSystemMessage(Component.translatable("guide.antcolony.line" + i));
        }
    }
}
