package com.antcolony;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Налаштування мода. Файли: config/antcolony-common.toml та config/antcolony-client.toml
 */
public final class ColonyConfig {
    private ColonyConfig() {}

    public enum PlayerLook {
        /** Гравець виглядає як мураха-дівчина (скін мурахи + вусики, черевце). */
        ANT,
        /** Власний скін гравця, але з вусиками та черевцем мурахи. */
        EXTRAS_ONLY,
        /** Звичайний вигляд гравця. */
        VANILLA
    }

    // ---------------------------------------------------------------- COMMON
    private static final ModConfigSpec.Builder COMMON = new ModConfigSpec.Builder();

    static {
        COMMON.push("breeding");
    }
    public static final ModConfigSpec.IntValue EGG_INTERVAL = COMMON
            .comment("Скільки секунд між яйцями, які відкладає королева (на вищих рівнях колонії швидше).")
            .defineInRange("eggIntervalSeconds", 40, 5, 3600);
    public static final ModConfigSpec.IntValue FREE_EGGS = COMMON
            .comment("Скільки перших яєць королева-засновниця відкладає безкоштовно (за рахунок власних запасів).")
            .defineInRange("freeStartingEggs", 4, 0, 100);
    public static final ModConfigSpec.IntValue EGG_FOOD_COST = COMMON
            .comment("Скільки одиниць їжі колонії коштує одне яйце.")
            .defineInRange("eggFoodCost", 3, 0, 100);
    public static final ModConfigSpec.IntValue EGG_SECONDS = COMMON
            .comment("Тривалість стадії яйця (секунди).")
            .defineInRange("eggSeconds", 40, 1, 3600);
    public static final ModConfigSpec.IntValue LARVA_SECONDS = COMMON
            .comment("Мінімальна тривалість стадії личинки (секунди). Личинку треба годувати.")
            .defineInRange("larvaSeconds", 70, 1, 3600);
    public static final ModConfigSpec.IntValue LARVA_FEEDINGS = COMMON
            .comment("Скільки разів (по 1 одиниці їжі) треба нагодувати личинку, щоб вона стала лялечкою.")
            .defineInRange("larvaFeedings", 3, 0, 50);
    public static final ModConfigSpec.IntValue PUPA_SECONDS = COMMON
            .comment("Тривалість стадії лялечки (секунди).")
            .defineInRange("pupaSeconds", 50, 1, 3600);
    public static final ModConfigSpec.DoubleValue SOLDIER_RATIO = COMMON
            .comment("Бажана частка солдатів серед дорослих мурах у режимі «Збалансовано».")
            .defineInRange("soldierRatio", 0.25D, 0.0D, 1.0D);
    static {
        COMMON.pop();
        COMMON.push("colony");
    }
    public static final ModConfigSpec.IntValue BASE_CAPACITY = COMMON
            .comment("Базова місткість колонії (дорослі + виводок), без королеви та принцес.")
            .defineInRange("baseCapacity", 8, 1, 500);
    public static final ModConfigSpec.IntValue CAPACITY_PER_LEVEL = COMMON
            .comment("На скільки зростає місткість з кожним рівнем колонії.")
            .defineInRange("capacityPerLevel", 4, 0, 100);
    public static final ModConfigSpec.IntValue QUEEN_FOOD_PER_MINUTE = COMMON
            .comment("Скільки їжі на хвилину з'їдає королева.")
            .defineInRange("queenFoodPerMinute", 2, 0, 100);
    public static final ModConfigSpec.IntValue ANTS_PER_FOOD = COMMON
            .comment("Скільки дорослих робітниць/солдатів годує 1 одиниця їжі на хвилину.")
            .defineInRange("antsPerFoodUnit", 4, 1, 100);
    public static final ModConfigSpec.BooleanValue QUEEN_LOSS_COLLAPSES = COMMON
            .comment("Якщо королева загинула і не з'явилась за відведений час — колонія розпадається.")
            .define("queenLossCollapses", true);
    public static final ModConfigSpec.IntValue QUEEN_LOSS_GRACE = COMMON
            .comment("Скільки секунд колонія чекає без королеви, перш ніж розпастися.")
            .defineInRange("queenLossGraceSeconds", 150, 5, 36000);
    public static final ModConfigSpec.IntValue COLONY_RADIUS = COMMON
            .comment("Радіус (блоки), у якому мурашник рахує мешканців колонії.")
            .defineInRange("colonyRadius", 48, 8, 128);
    public static final ModConfigSpec.IntValue FORAGING_RADIUS = COMMON
            .comment("Радіус (блоки) від мурашника, у якому робітниці шукають їжу.")
            .defineInRange("foragingRadius", 24, 4, 96);
    public static final ModConfigSpec.IntValue FOUNDING_RADIUS = COMMON
            .comment("У якому радіусі від мурашника має стояти принцеса/королева, щоб заснувати колонію.")
            .defineInRange("foundingRadius", 12, 2, 48);
    public static final ModConfigSpec.IntValue CARRY_AMOUNT = COMMON
            .comment("Скільки предметів їжі робітниця несе за один раз.")
            .defineInRange("workerCarryAmount", 4, 1, 64);
    public static final ModConfigSpec.BooleanValue DEPOSIT_BOOST = COMMON
            .comment("Давати гравцю-робітниці коротке прискорення, коли він приносить їжу в мурашник.")
            .define("depositSpeedBoost", true);
    static {
        COMMON.pop();
        COMMON.push("nuptialFlight");
    }
    public static final ModConfigSpec.BooleanValue NUPTIAL_ENABLED = COMMON
            .comment("Чи може сильна колонія вирощувати нових принцес (шлюбний виліт).")
            .define("enabled", true);
    public static final ModConfigSpec.IntValue NUPTIAL_MIN_LEVEL = COMMON
            .comment("З якого рівня колонії з'являються принцеси.")
            .defineInRange("minLevel", 3, 1, 20);
    public static final ModConfigSpec.IntValue NUPTIAL_FOOD = COMMON
            .comment("Скільки їжі має бути на складі, щоб колонія виростила принцесу.")
            .defineInRange("foodThreshold", 60, 0, 10000);
    public static final ModConfigSpec.IntValue NUPTIAL_COOLDOWN = COMMON
            .comment("Пауза між принцесами (секунди).")
            .defineInRange("cooldownSeconds", 480, 1, 86400);
    public static final ModConfigSpec.IntValue PRINCESS_FLIGHT_MINUTES = COMMON
            .comment("Через скільки хвилин народжена колонією принцеса відлітає (якщо її не взяти під опіку).")
            .defineInRange("princessFlightMinutes", 10, 1, 600);
    public static final ModConfigSpec.BooleanValue WILD_PRINCESS_SPAWN = COMMON
            .comment("Чи можуть дикі принцеси з'являтися в світі природно (потрібні для старту колонії).")
            .define("wildPrincessSpawn", true);
    static {
        COMMON.pop();
    }
    public static final ModConfigSpec COMMON_SPEC = COMMON.build();

    // ---------------------------------------------------------------- CLIENT
    private static final ModConfigSpec.Builder CLIENT = new ModConfigSpec.Builder();

    public static final ModConfigSpec.EnumValue<PlayerLook> PLAYER_LOOK = CLIENT
            .comment("Як виглядають гравці: ANT (мураха-дівчина), EXTRAS_ONLY (свій скін + вусики), VANILLA (як зазвичай).")
            .defineEnum("playerLook", PlayerLook.ANT);

    public static final ModConfigSpec CLIENT_SPEC = CLIENT.build();
}
