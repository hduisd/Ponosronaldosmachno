package com.antcolony;

import com.antcolony.registry.ModBlockEntities;
import com.antcolony.registry.ModBlocks;
import com.antcolony.registry.ModEntities;
import com.antcolony.registry.ModItems;
import com.antcolony.registry.ModTabs;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

/**
 * Колонія (Ant Colony): ти — мураха-робітниця, королева засновує колонію.
 */
@Mod(AntColonyMod.MODID)
public class AntColonyMod {
    public static final String MODID = "antcolony";

    public AntColonyMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModTabs.TABS.register(modEventBus);

        modContainer.registerConfig(ModConfig.Type.COMMON, ColonyConfig.COMMON_SPEC);
        modContainer.registerConfig(ModConfig.Type.CLIENT, ColonyConfig.CLIENT_SPEC);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
