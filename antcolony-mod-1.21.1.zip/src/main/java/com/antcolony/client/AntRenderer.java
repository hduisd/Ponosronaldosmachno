package com.antcolony.client;

import com.antcolony.colony.AntCaste;
import com.antcolony.entity.AbstractAnt;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * Рендерер мурах-дівчат: модель гравця (тонкі руки, розкладка 64x64) + мурашині деталі + предмет у руці.
 * Королева на 20% більша за інших.
 */
public class AntRenderer<T extends AbstractAnt> extends MobRenderer<T, PlayerModel<T>> {
    public AntRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM), true), 0.45F);
        this.addLayer(new AntExtrasLayer<>(this, new AntExtrasModel(context.bakeLayer(AntExtrasModel.LAYER))));
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(T ant) {
        return AntTextures.skin(ant.caste());
    }

    @Override
    protected void scale(T ant, PoseStack poseStack, float partialTick) {
        // 0.9375 — той самий множник, що й у гравця, щоб модель збігалася з хітбоксом
        float scale = 0.9375F * (ant.caste() == AntCaste.QUEEN ? 1.2F : 1.0F);
        poseStack.scale(scale, scale, scale);
    }

    @Override
    public void render(T ant, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        PlayerModel<T> playerModel = this.getModel();
        playerModel.rightArmPose = ant.getMainHandItem().isEmpty()
                ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM;
        playerModel.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        super.render(ant, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}
