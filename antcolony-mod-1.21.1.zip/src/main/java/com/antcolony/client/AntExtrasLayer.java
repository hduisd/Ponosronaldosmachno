package com.antcolony.client;

import com.antcolony.ColonyConfig;
import com.antcolony.colony.AntCaste;
import com.antcolony.entity.AbstractAnt;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Шар, що малює на гуманоїдній моделі мурашині деталі: вусики, щелепи, черевце, крила, корону.
 * Працює і для мурах-NPC, і для гравців (гравець завжди — робітниця).
 */
public class AntExtrasLayer<T extends LivingEntity, M extends PlayerModel<T>> extends RenderLayer<T, M> {
    private final AntExtrasModel model;

    public AntExtrasLayer(RenderLayerParent<T, M> parent, AntExtrasModel model) {
        super(parent);
        this.model = model;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) {
            return;
        }
        AntCaste caste;
        if (entity instanceof AbstractAnt ant) {
            caste = ant.caste();
        } else if (entity instanceof Player) {
            if (ColonyConfig.PLAYER_LOOK.get() == ColonyConfig.PlayerLook.VANILLA) {
                return;
            }
            caste = AntCaste.WORKER;
        } else {
            return;
        }

        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(AntTextures.extras(caste)));
        int overlay = LivingEntityRenderer.getOverlayCoords(entity, 0.0F);
        boolean flying = !entity.onGround() && !entity.isInWaterOrBubble();

        poseStack.pushPose();
        this.getParentModel().head.translateAndRotate(poseStack);
        model.renderHead(caste, poseStack, consumer, packedLight, overlay);
        poseStack.popPose();

        poseStack.pushPose();
        this.getParentModel().body.translateAndRotate(poseStack);
        model.renderBody(caste, ageInTicks, flying, poseStack, consumer, packedLight, overlay);
        poseStack.popPose();
    }
}
