package com.antcolony.client;

import com.antcolony.colony.AntCaste;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Гравець-мураха: звичайний PlayerRenderer (тонкі руки), але зі скіном мурахи-робітниці
 * та мурашиними деталями. Гравець завжди робітниця — королевою гравець бути не може.
 */
public class AntPlayerRenderer extends PlayerRenderer {
    public AntPlayerRenderer(EntityRendererProvider.Context context, AntExtrasModel extras) {
        super(context, true);
        this.addLayer(new AntExtrasLayer<>(this, extras));
    }

    @Override
    public ResourceLocation getTextureLocation(AbstractClientPlayer player) {
        return AntTextures.skin(AntCaste.WORKER);
    }
}
