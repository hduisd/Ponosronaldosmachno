package com.antcolony.client;

import com.antcolony.AntColonyMod;
import com.antcolony.colony.AntCaste;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Деталі, що роблять гуманоїда мурахою: вусики, щелепи (солдат), черевце, крила (принцеса), корона (королева).
 * Малюються поверх моделі гравця: голова-частини — у системі координат голови, решта — тулуба.
 * UV-розкладка (текстура 64x64) описана в tools/gen_textures.py.
 */
public class AntExtrasModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(AntColonyMod.id("ant_extras"), "main");
    private static final int WHITE = 0xFFFFFFFF;

    private final ModelPart antennaLeft;
    private final ModelPart antennaRight;
    private final ModelPart mandibleLeft;
    private final ModelPart mandibleRight;
    private final ModelPart crown;
    private final ModelPart abdomen;
    private final ModelPart abdomenQueen;
    private final ModelPart wingLeft;
    private final ModelPart wingRight;

    public AntExtrasModel(ModelPart root) {
        this.antennaLeft = root.getChild("antenna_left");
        this.antennaRight = root.getChild("antenna_right");
        this.mandibleLeft = root.getChild("mandible_left");
        this.mandibleRight = root.getChild("mandible_right");
        this.crown = root.getChild("crown");
        this.abdomen = root.getChild("abdomen");
        this.abdomenQueen = root.getChild("abdomen_queen");
        this.wingLeft = root.getChild("wing_left");
        this.wingRight = root.getChild("wing_right");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // ---- голова: вусики (дві ланки), нахилені вперед і назовні
        addAntenna(root, "antenna_left", 2.0F, 0.30F);
        addAntenna(root, "antenna_right", -2.0F, -0.30F);

        // ---- голова: великі щелепи (у солдата)
        root.addOrReplaceChild("mandible_left",
                CubeListBuilder.create().texOffs(8, 0).addBox(-0.5F, -0.5F, -3.0F, 1.0F, 1.0F, 3.0F),
                PartPose.offsetAndRotation(1.5F, -2.0F, -4.0F, 0.0F, 0.4F, 0.0F));
        root.addOrReplaceChild("mandible_right",
                CubeListBuilder.create().texOffs(8, 0).addBox(-0.5F, -0.5F, -3.0F, 1.0F, 1.0F, 3.0F),
                PartPose.offsetAndRotation(-1.5F, -2.0F, -4.0F, 0.0F, -0.4F, 0.0F));

        // ---- голова: корона королеви (5 зубців)
        PartDefinition crown = root.addOrReplaceChild("crown", CubeListBuilder.create(), PartPose.ZERO);
        float[][] spikes = {{-3.0F, -3.0F}, {3.0F, -3.0F}, {-3.0F, 3.0F}, {3.0F, 3.0F}, {0.0F, -3.5F}};
        for (int i = 0; i < spikes.length; i++) {
            crown.addOrReplaceChild("spike_" + i,
                    CubeListBuilder.create().texOffs(24, 56).addBox(-0.5F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F),
                    PartPose.offset(spikes[i][0], -8.5F, spikes[i][1]));
        }

        // ---- тулуб: черевце робітниці/солдата/принцеси (талія + черевце + жало)
        PartDefinition abd = root.addOrReplaceChild("abdomen",
                CubeListBuilder.create().texOffs(0, 8).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 10.0F, 2.0F));
        PartDefinition gaster = abd.addOrReplaceChild("gaster",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -3.0F, 0.0F, 6.0F, 6.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, 2.0F, 0.2F, 0.0F, 0.0F));
        gaster.addOrReplaceChild("stinger",
                CubeListBuilder.create().texOffs(30, 16).addBox(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 2.0F),
                PartPose.offset(0.0F, 0.0F, 8.0F));

        // ---- тулуб: велике черевце королеви
        PartDefinition abdQueen = root.addOrReplaceChild("abdomen_queen",
                CubeListBuilder.create().texOffs(0, 8).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 10.0F, 2.0F));
        abdQueen.addOrReplaceChild("gaster",
                CubeListBuilder.create().texOffs(0, 32).addBox(-4.0F, -4.0F, 0.0F, 8.0F, 8.0F, 12.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, 2.0F, 0.15F, 0.0F, 0.0F));

        // ---- тулуб: крила принцеси
        root.addOrReplaceChild("wing_left",
                CubeListBuilder.create().texOffs(40, 32).addBox(0.0F, -13.0F, 0.0F, 8.0F, 13.0F, 1.0F),
                PartPose.offsetAndRotation(1.5F, 2.0F, 2.5F, 0.0F, -0.3F, 0.35F));
        root.addOrReplaceChild("wing_right",
                CubeListBuilder.create().texOffs(40, 46).addBox(-8.0F, -13.0F, 0.0F, 8.0F, 13.0F, 1.0F),
                PartPose.offsetAndRotation(-1.5F, 2.0F, 2.5F, 0.0F, 0.3F, -0.35F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addAntenna(PartDefinition root, String name, float x, float roll) {
        PartDefinition base = root.addOrReplaceChild(name,
                CubeListBuilder.create().texOffs(0, 0).addBox(-0.5F, -5.0F, -0.5F, 1.0F, 5.0F, 1.0F),
                PartPose.offsetAndRotation(x, -8.0F, -3.0F, 0.45F, 0.0F, roll));
        base.addOrReplaceChild("tip",
                CubeListBuilder.create().texOffs(4, 0).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, -5.0F, 0.0F, 0.55F, 0.0F, 0.0F));
    }

    /** Деталі в системі координат голови. */
    public void renderHead(AntCaste caste, PoseStack poseStack, VertexConsumer consumer, int light, int overlay) {
        antennaLeft.render(poseStack, consumer, light, overlay, WHITE);
        antennaRight.render(poseStack, consumer, light, overlay, WHITE);
        if (caste == AntCaste.SOLDIER) {
            mandibleLeft.render(poseStack, consumer, light, overlay, WHITE);
            mandibleRight.render(poseStack, consumer, light, overlay, WHITE);
        }
        if (caste == AntCaste.QUEEN) {
            crown.render(poseStack, consumer, light, overlay, WHITE);
        }
    }

    /** Деталі в системі координат тулуба. */
    public void renderBody(AntCaste caste, float ageInTicks, boolean flying, PoseStack poseStack,
                           VertexConsumer consumer, int light, int overlay) {
        ModelPart tail = caste == AntCaste.QUEEN ? abdomenQueen : abdomen;
        tail.yRot = Mth.sin(ageInTicks * 0.07F) * 0.08F;
        tail.render(poseStack, consumer, light, overlay, WHITE);
        if (caste == AntCaste.PRINCESS) {
            float flap = flying ? Mth.sin(ageInTicks * 1.6F) * 0.45F : Mth.sin(ageInTicks * 0.1F) * 0.05F;
            wingLeft.zRot = 0.35F + flap;
            wingRight.zRot = -0.35F - flap;
            wingLeft.render(poseStack, consumer, light, overlay, WHITE);
            wingRight.render(poseStack, consumer, light, overlay, WHITE);
        }
    }
}
