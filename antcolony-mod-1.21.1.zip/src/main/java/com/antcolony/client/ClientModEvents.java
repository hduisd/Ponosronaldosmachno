package com.antcolony.client;

import com.antcolony.AntColonyMod;
import com.antcolony.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerSkin;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import org.jetbrains.annotations.Nullable;

/** Клієнтські події шини мода: шари моделей, рендерери істот, рендерер гравця-мурахи. */
@EventBusSubscriber(modid = AntColonyMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @Nullable
    private static AntPlayerRenderer antPlayerRenderer;

    /** Рендерер гравця-мурахи (створюється при кожному перезавантаженні ресурсів). */
    @Nullable
    public static AntPlayerRenderer antPlayerRenderer() {
        return antPlayerRenderer;
    }

    @SubscribeEvent
    public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(AntExtrasModel.LAYER, AntExtrasModel::createLayer);
        event.registerLayerDefinition(BroodModel.LAYER, BroodModel::createLayer);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ANT_WORKER.get(), AntRenderer::new);
        event.registerEntityRenderer(ModEntities.ANT_SOLDIER.get(), AntRenderer::new);
        event.registerEntityRenderer(ModEntities.ANT_PRINCESS.get(), AntRenderer::new);
        event.registerEntityRenderer(ModEntities.ANT_QUEEN.get(), AntRenderer::new);
        event.registerEntityRenderer(ModEntities.ANT_BROOD.get(), BroodRenderer::new);
    }

    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        // Окремий рендерер для гравців-мурах (скін мурахи + деталі).
        antPlayerRenderer = new AntPlayerRenderer(event.getContext(),
                new AntExtrasModel(event.getEntityModels().bakeLayer(AntExtrasModel.LAYER)));

        // Звичайні рендерери гравців теж отримують мурашині деталі (режим EXTRAS_ONLY: власний скін + вусики).
        for (PlayerSkin.Model skinModel : event.getSkins()) {
            EntityRenderer<? extends Player> renderer = event.getSkin(skinModel);
            if (renderer instanceof PlayerRenderer playerRenderer) {
                playerRenderer.addLayer(new AntExtrasLayer<>(playerRenderer,
                        new AntExtrasModel(event.getEntityModels().bakeLayer(AntExtrasModel.LAYER))));
            }
        }
    }
}
