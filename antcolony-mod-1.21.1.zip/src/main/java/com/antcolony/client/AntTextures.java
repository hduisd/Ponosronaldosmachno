package com.antcolony.client;

import com.antcolony.AntColonyMod;
import com.antcolony.colony.AntCaste;
import net.minecraft.resources.ResourceLocation;

/** Шляхи до текстур мурах (assets/antcolony/textures/entity/ant/). */
public final class AntTextures {
    private AntTextures() {}

    private static final ResourceLocation[] SKINS = new ResourceLocation[AntCaste.values().length];
    private static final ResourceLocation[] EXTRAS = new ResourceLocation[AntCaste.values().length];

    static {
        for (AntCaste caste : AntCaste.values()) {
            SKINS[caste.ordinal()] = AntColonyMod.id("textures/entity/ant/" + caste.id() + ".png");
            EXTRAS[caste.ordinal()] = AntColonyMod.id("textures/entity/ant/" + caste.id() + "_extras.png");
        }
    }

    public static final ResourceLocation BROOD = AntColonyMod.id("textures/entity/ant/brood.png");

    /** Скін-«шкіра» мурахи-дівчини (розкладка 64x64, тонкі руки). */
    public static ResourceLocation skin(AntCaste caste) {
        return SKINS[caste.ordinal()];
    }

    /** Текстура додаткових деталей: вусики, щелепи, черевце, крила, корона. */
    public static ResourceLocation extras(AntCaste caste) {
        return EXTRAS[caste.ordinal()];
    }
}
