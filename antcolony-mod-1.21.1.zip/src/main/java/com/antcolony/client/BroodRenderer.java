package com.antcolony.client;

import com.antcolony.entity.AntBrood;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Малює яйце, личинку або лялечку залежно від стадії. */
public class BroodRenderer extends EntityRenderer<AntBrood> {
    private final BroodModel model;

    public BroodRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new BroodModel(context.bakeLayer(BroodModel.LAYER));
        this.shadowRadius = 0.12F;
    }

    @Override
    public ResourceLocation getTextureLocation(AntBrood brood) {
        return AntTextures.BROOD;
    }

    @Override
    public void render(AntBrood brood, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float scale = brood.sizeScale();
        poseStack.scale(-scale, -scale, scale);
        poseStack.translate(0.0F, -1.501F, 0.0F);
        poseStack.mulPose(Axis.YP.rotationDegrees(brood.getYRot()));
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(brood)));
        model.render(brood.getStage(), brood.tickCount + partialTick, poseStack, consumer, packedLight,
                OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
        super.render(brood, entityYaw, partialTick, poseStack, buffer, packedLight);
    }
}
