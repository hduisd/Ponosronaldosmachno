package com.antcolony.client;

import com.antcolony.AntColonyMod;
import com.antcolony.ColonyConfig;
import com.antcolony.colony.AntCaste;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;

/**
 * Підміна вигляду гравця на мураху-робітницю (режим ANT у клієнтському конфігу):
 * третя особа — через окремий рендерер, перша особа — через власну руку з текстурою мурахи.
 */
@EventBusSubscriber(modid = AntColonyMod.MODID, value = Dist.CLIENT)
public final class ClientGameEvents {
    private ClientGameEvents() {}

    /** Захист від повторного входу: наш рендерер сам викликає RenderPlayerEvent. */
    private static boolean rendering;

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        if (rendering || ColonyConfig.PLAYER_LOOK.get() != ColonyConfig.PlayerLook.ANT) {
            return;
        }
        AntPlayerRenderer renderer = ClientModEvents.antPlayerRenderer();
        if (renderer == null || !(event.getEntity() instanceof AbstractClientPlayer player)) {
            return;
        }
        event.setCanceled(true);
        rendering = true;
        try {
            renderer.render(player, player.getYRot(), event.getPartialTick(), event.getPoseStack(),
                    event.getMultiBufferSource(), event.getPackedLight());
        } finally {
            rendering = false;
        }
    }

    @SubscribeEvent
    public static void onRenderArm(RenderArmEvent event) {
        if (ColonyConfig.PLAYER_LOOK.get() != ColonyConfig.PlayerLook.ANT) {
            return;
        }
        AntPlayerRenderer renderer = ClientModEvents.antPlayerRenderer();
        if (renderer == null) {
            return;
        }
        event.setCanceled(true);

        AbstractClientPlayer player = event.getPlayer();
        PlayerModel<AbstractClientPlayer> model = renderer.getModel();
        model.setAllVisible(true);
        model.attackTime = 0.0F;
        model.crouching = false;
        model.swimAmount = 0.0F;
        model.setupAnim(player, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);

        boolean right = event.getArm() == HumanoidArm.RIGHT;
        ModelPart arm = right ? model.rightArm : model.leftArm;
        ModelPart sleeve = right ? model.rightSleeve : model.leftSleeve;
        arm.xRot = 0.0F;
        sleeve.xRot = 0.0F;

        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource buffer = event.getMultiBufferSource();
        ResourceLocation texture = AntTextures.skin(AntCaste.WORKER);
        arm.render(poseStack, buffer.getBuffer(RenderType.entitySolid(texture)), event.getPackedLight(),
                OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
        sleeve.render(poseStack, buffer.getBuffer(RenderType.entityTranslucent(texture)), event.getPackedLight(),
                OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
    }
}
