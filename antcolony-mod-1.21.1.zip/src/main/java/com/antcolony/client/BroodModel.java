package com.antcolony.client;

import com.antcolony.AntColonyMod;
import com.antcolony.colony.BroodStage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Прості моделі виводку: яйце, личинка (з трьох сегментів), лялечка (кокон). Текстура 64x32. */
public class BroodModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(AntColonyMod.id("ant_brood"), "main");
    private static final int WHITE = 0xFFFFFFFF;

    private final ModelPart egg;
    private final ModelPart larva;
    private final ModelPart pupa;

    public BroodModel(ModelPart root) {
        this.egg = root.getChild("egg");
        this.larva = root.getChild("larva");
        this.pupa = root.getChild("pupa");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Усі моделі «стоять» на y = 24 (так само, як моделі живих істот).
        PartDefinition egg = root.addOrReplaceChild("egg",
                CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, 19.0F, -2.0F, 4.0F, 5.0F, 4.0F),
                PartPose.ZERO);
        egg.addOrReplaceChild("cap",
                CubeListBuilder.create().texOffs(0, 9).addBox(-1.5F, 18.0F, -1.5F, 3.0F, 1.0F, 3.0F),
                PartPose.ZERO);

        PartDefinition larva = root.addOrReplaceChild("larva",
                CubeListBuilder.create().texOffs(0, 14).addBox(-1.5F, 21.0F, -4.0F, 3.0F, 3.0F, 2.0F),
                PartPose.ZERO);
        larva.addOrReplaceChild("middle",
                CubeListBuilder.create().texOffs(0, 19).addBox(-2.0F, 20.0F, -2.0F, 4.0F, 4.0F, 3.0F),
                PartPose.ZERO);
        larva.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(16, 14).addBox(-1.5F, 21.0F, 1.0F, 3.0F, 3.0F, 2.0F),
                PartPose.ZERO);

        root.addOrReplaceChild("pupa",
                CubeListBuilder.create().texOffs(32, 0).addBox(-2.0F, 20.0F, -4.0F, 4.0F, 4.0F, 8.0F),
                PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 32);
    }

    public void render(BroodStage stage, float ageInTicks, PoseStack poseStack, VertexConsumer consumer,
                       int light, int overlay) {
        switch (stage) {
            case EGG -> egg.render(poseStack, consumer, light, overlay, WHITE);
            case LARVA -> {
                larva.yRot = Mth.sin(ageInTicks * 0.15F) * 0.25F;
                larva.render(poseStack, consumer, light, overlay, WHITE);
            }
            case PUPA -> pupa.render(poseStack, consumer, light, overlay, WHITE);
        }
    }
}
