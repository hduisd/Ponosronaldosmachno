package com.antcolony.command;

import com.antcolony.AntColonyMod;
import com.antcolony.colony.AnthillBlockEntity;
import com.antcolony.entity.AbstractAnt;
import com.antcolony.item.ColonyGuideItem;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** /colony help — правила гри, /colony info — стан найближчої колонії. */
@EventBusSubscriber(modid = AntColonyMod.MODID)
public final class ColonyCommands {
    private ColonyCommands() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("colony")
                .then(Commands.literal("help").executes(ctx -> help(ctx.getSource())))
                .then(Commands.literal("info").executes(ctx -> info(ctx.getSource()))));
    }

    private static int help(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ColonyGuideItem.sendGuide(player);
        return 1;
    }

    private static int info(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        AbstractAnt nearest = null;
        double best = Double.MAX_VALUE;
        for (AbstractAnt ant : level.getEntitiesOfClass(AbstractAnt.class, player.getBoundingBox().inflate(96.0D),
                a -> a.hasNest())) {
            double d = ant.distanceToSqr(player);
            if (d < best) {
                best = d;
                nearest = ant;
            }
        }
        AnthillBlockEntity anthill = nearest != null ? nearest.getNest() : null;
        if (anthill == null) {
            source.sendFailure(Component.translatable("command.antcolony.no_colony"));
            return 0;
        }
        anthill.sendInfo(player);
        return 1;
    }
}
