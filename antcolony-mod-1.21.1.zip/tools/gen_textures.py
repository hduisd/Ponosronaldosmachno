#!/usr/bin/env python3
"""Генерує всі текстури мода в src/main/resources/assets/antcolony/textures/.
Запуск (з кореня проєкту):  python3 tools/gen_textures.py
Потрібен Pillow:  pip install pillow"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tex_skin import paint_skin, PALETTES
from tex_misc import extras_sheet, brood_sheet, anthill_top, anthill_side, guide_icon

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main',
                                     'resources', 'assets', 'antcolony', 'textures'))


def main():
    ant = os.path.join(ROOT, 'entity', 'ant')
    for name in PALETTES:
        paint_skin(name).save(os.path.join(ant, name + '.png'))
        extras_sheet(name).save(os.path.join(ant, name + '_extras.png'))
    brood_sheet().save(os.path.join(ant, 'brood.png'))
    anthill_top().save(os.path.join(ROOT, 'block', 'anthill_top.png'))
    anthill_side().save(os.path.join(ROOT, 'block', 'anthill_side.png'))
    guide_icon().save(os.path.join(ROOT, 'item', 'colony_guide.png'))
    print('textures written to', ROOT)


if __name__ == '__main__':
    main()
