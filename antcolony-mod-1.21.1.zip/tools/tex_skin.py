"""Скіни мурах-дівчат (64x64, тонкі руки): голова, тулуб, руки, ноги та оверлеї."""
from tex_common import *

PALETTES = {
    'worker': dict(chitin=hexc('9A5A2A'), dark=hexc('5E3416'), light=hexc('C98446'), accent=hexc('E0A040'),
                   skin=hexc('E8C4A0'), skin_sh=hexc('D2A982'), hair=hexc('3A2418'), hair_hi=hexc('5C3B27'),
                   eye=hexc('E89A20'), blush=hexc('E39A86'), style='bob'),
    'soldier': dict(chitin=hexc('7A1E1E'), dark=hexc('2B0F0F'), light=hexc('B03838'), accent=hexc('D8D0C0'),
                    skin=hexc('E2B9A0'), skin_sh=hexc('C99C82'), hair=hexc('1E1010'), hair_hi=hexc('4A1A1A'),
                    eye=hexc('E02020'), blush=hexc('D98C80'), style='short'),
    'princess': dict(chitin=hexc('C9B3EA'), dark=hexc('8A74B8'), light=hexc('EDE3FA'), accent=hexc('E0B84A'),
                     skin=hexc('F4D6C0'), skin_sh=hexc('DDB9A0'), hair=hexc('EAD890'), hair_hi=hexc('FFF4C8'),
                     eye=hexc('8A4AD8'), blush=hexc('F0A8A0'), style='long'),
    'queen': dict(chitin=hexc('4A2A6E'), dark=hexc('241236'), light=hexc('7A4AA8'), accent=hexc('E0B84A'),
                  skin=hexc('EBC8A8'), skin_sh=hexc('D2AB8A'), hair=hexc('1A0E26'), hair_hi=hexc('3E2260'),
                  eye=hexc('FFC830'), blush=hexc('E09A8C'), style='long'),
}
for _name, _p in PALETTES.items():
    _p['name'] = _name

# Обличчя 8x8: H волосся, S шкіра, E вії, W/I око (біле/райдужка), B рум'янець, M рот
FACES = {
    'worker': ['HHHHHHHH', 'HHHHHHHH', 'HHHSSHHH', 'HSSSSSSH', 'HEESSEEH', 'SWISSIWS', 'SBSMMSBS', 'SSSSSSSS'],
    'soldier': ['HHHHHHHH', 'HHHHHHHH', 'HHSHHSHH', 'SSSSSSSS', 'SEESSEES', 'SWISSIWS', 'SSSMMSSS', 'SSSSSSSS'],
    'princess': ['HHHHHHHH', 'HHHHHHHH', 'HHHSSHHH', 'HSSSSSSH', 'HEESSEEH', 'HWISSIWH', 'SBSMMSBS', 'SSSSSSSS'],
    'queen': ['HHHHHHHH', 'HHHHHHHH', 'HHSHHSHH', 'HSSSSSSH', 'HEESSEEH', 'HWISSIWH', 'SSSMMSSS', 'SSSSSSSS'],
}
BACK_ROWS = {'bob': 7, 'short': 6, 'long': 8}


def hair_px(p, i, j, seed):
    n = noise(i, j, seed)
    if n > 0.84:
        return p['hair_hi']
    if n < 0.12:
        return shade(p['hair'], 0.85)
    return p['hair']


def head_cell(p, face, i, j, fw):
    """-> ('hair' | 'skin', колір) для пікселя грані голови."""
    if face == 'top':
        c = hair_px(p, i, j, 3)
        if i in (3, 4) and j < 6:
            c = mix(c, p['hair_hi'], 0.5)
        return 'hair', c
    if face == 'bottom':
        return 'skin', p['skin_sh']
    if face == 'front':
        ch = FACES[p['name']][j][i]
        if ch == 'H':
            return 'hair', hair_px(p, i, j, 9)
        eyes = {'W': (246, 244, 240), 'I': p['eye'], 'E': shade(p['hair'], 0.6), 'B': p['blush'],
                'M': mix(p['skin'], (200, 70, 80), 0.75), 'S': p['skin']}
        return 'skin', eyes[ch]
    rows = BACK_ROWS[p['style']]
    if face == 'back':
        return ('hair', hair_px(p, i, j, 5)) if j < rows else ('skin', p['skin_sh'])
    back = i if face == 'right' else fw - 1 - i  # 0 — задній край голови
    if j <= 2 or (back <= 4 and j < rows):
        return 'hair', hair_px(p, i, j, 7)
    if back == 5 and j in (4, 5):
        return 'skin', p['skin_sh']
    return 'skin', p['skin']


def paint_head(s, p):
    paint_box(s, 0, 0, 8, 8, 8, lambda f, i, j, fw, fh: head_cell(p, f, i, j, fw)[1])

    def overlay(f, i, j, fw, fh):
        if p['name'] == 'soldier' and j == 3 and f != 'top' and f != 'bottom':
            return p['accent'] if (f == 'front' and i in (3, 4)) else p['dark']  # пов'язка солдата
        kind, c = head_cell(p, f, i, j, fw)
        return mix(c, p['hair_hi'], 0.15) if kind == 'hair' else None

    paint_box(s, 32, 0, 8, 8, 8, overlay)


def torso_px(p, face, i, j, fw, fh):
    if face == 'top':
        return p['light']
    if face == 'bottom':
        return p['dark']
    if face == 'front' and ((j == 0 and 2 <= i <= 5) or (j == 1 and 3 <= i <= 4)):
        return p['skin']  # декольте / шия
    if j == 6:
        return p['light'] if (face == 'front' and i in (3, 4)) else p['accent']  # пояс
    if j > 6:
        q = dict(p, chitin=mix(p['chitin'], p['dark'], 0.35))
        return chitin(q, i, j - 7, seg=3, seed=2)
    c = chitin(p, i, j - 2 if j >= 2 else j, seg=4, seed=1)
    if face in ('front', 'back') and i in (3, 4) and j >= 2:
        c = shade(c, 0.85)  # центральна канавка грудної пластини
    return c


def jacket_px(p, face, i, j, fw, fh):
    if face in ('top', 'bottom'):
        return None
    if j == 11:
        return p['accent']  # золота облямівка подолу
    if face == 'back' and p['style'] == 'long' and j <= 9 and 1 <= i <= 6 and not (j >= 8 and i in (1, 6)):
        return hair_px(p, i, j, 11)  # довге волосся на спині
    if face == 'front' and p['style'] == 'long' and j in (2, 3) and i in (3, 4):
        return p['accent'] if j == 2 else p['light']  # медальйон
    return None


def arm_px(p, face, i, j, fw, fh):
    if face == 'top':
        return p['light']
    if face == 'bottom':
        return p['skin']
    if j >= 10:
        return p['skin'] if j == 10 else p['skin_sh']  # кисть
    if j == 5:
        return p['dark']  # лікоть
    if j < 5:
        return chitin(p, i, j, seg=3, seed=4)
    return chitin(p, i, j - 6, seg=4, seed=5)


def sleeve_px(p, face, i, j, fw, fh):
    if face == 'top':
        return p['light']
    if face == 'bottom':
        return None
    return p['light'] if j == 0 else (p['accent'] if j == 1 else None)  # наплічник


def leg_px(p, face, i, j, fw, fh):
    if face == 'top':
        return p['light']
    if face == 'bottom':
        return p['dark']
    if j == 6:
        return p['dark']  # коліно
    if j >= 10:
        return mix(p['dark'], p['chitin'], 0.25) if j == 11 else p['chitin']  # чобіток
    if j < 6:
        return chitin(p, i, j, seg=3, seed=6)
    return chitin(p, i, j - 7, seg=3, seed=7)


def pants_px(p, face, i, j, fw, fh):
    if face in ('top', 'bottom'):
        return None
    if j == 9:
        return p['accent']  # браслет на щиколотці
    if face == 'front' and j in (5, 6) and i in (1, 2):
        return p['light'] if j == 5 else p['accent']  # наколінник
    return None


def paint_skin(name):
    p = PALETTES[name]
    s = Sheet(64, 64)
    paint_head(s, p)
    paint_box(s, 16, 16, 8, 12, 4, lambda *a: torso_px(p, *a))
    paint_box(s, 16, 32, 8, 12, 4, lambda *a: jacket_px(p, *a))
    for (u, v) in ((40, 16), (32, 48)):
        paint_box(s, u, v, 3, 12, 4, lambda *a: arm_px(p, *a))
    for (u, v) in ((40, 32), (48, 48)):
        paint_box(s, u, v, 3, 12, 4, lambda *a: sleeve_px(p, *a))
    for (u, v) in ((0, 16), (16, 48)):
        paint_box(s, u, v, 4, 12, 4, lambda *a: leg_px(p, *a))
    for (u, v) in ((0, 32), (0, 48)):
        paint_box(s, u, v, 4, 12, 4, lambda *a: pants_px(p, *a))
    return s
