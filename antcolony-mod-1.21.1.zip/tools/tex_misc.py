"""Деталі мурах (вусики, черевце, крила, корона), виводок, блок «Мурашник» та іконка довідника."""
from tex_common import *
from tex_skin import PALETTES


def ringed(p, k, ring, seed, accent_every=0):
    """Колір сегмента черевця: k — позиція вздовж осі, шов кожен ring-й піксель."""
    if accent_every and k % accent_every == accent_every - 1:
        return p['accent']
    if k % ring == ring - 1:
        return p['dark']
    c = mix(p['chitin'], p['light'], 0.4) if k % ring == 0 else p['chitin']
    n = noise(k, seed, seed)
    return shade(c, 0.92) if n < 0.15 else c


def axis_pos(face, i, j):
    """Позиція вздовж довгої осі (z) для граней куба."""
    if face in ('top', 'bottom'):
        return j
    if face in ('left', 'right'):
        return i
    return 0


def extras_sheet(name):
    p = PALETTES[name]
    s = Sheet(64, 64)
    mid = mix(p['dark'], p['chitin'], 0.3)
    paint_box(s, 0, 0, 1, 5, 1, lambda f, i, j, fw, fh: p['chitin'] if j == 0 else mid)           # вусик
    paint_box(s, 4, 0, 1, 4, 1, lambda f, i, j, fw, fh: p['accent'] if j == fh - 1 else p['chitin'])  # кінчик
    paint_box(s, 8, 0, 1, 1, 3, lambda f, i, j, fw, fh:
              p['accent'] if axis_pos(f, i, j) == 0 else p['dark'])                                   # щелепа
    paint_box(s, 0, 8, 3, 3, 2, lambda f, i, j, fw, fh: chitin(p, i, j, seg=3, seed=3))              # талія
    paint_box(s, 0, 16, 6, 6, 8, lambda f, i, j, fw, fh:
              shade(p['chitin'], 0.9) if f in ('front', 'back') else ringed(p, axis_pos(f, i, j), 3, 5))
    paint_box(s, 30, 16, 1, 1, 2, lambda f, i, j, fw, fh: p['dark'])                                  # жало
    paint_box(s, 0, 32, 8, 8, 12, lambda f, i, j, fw, fh:
              shade(p['chitin'], 0.9) if f in ('front', 'back') else ringed(p, axis_pos(f, i, j), 4, 6, 4))
    paint_box(s, 24, 56, 1, 2, 1, lambda f, i, j, fw, fh:
              mix(p['accent'], (255, 240, 170), 0.5) if j == 0 else p['accent'])                      # зубець корони
    if name == 'princess':
        glass = mix(p['light'], (255, 255, 255), 0.5)
        vein = mix(p['dark'], p['light'], 0.4)

        def wing(f, i, j, fw, fh):
            is_vein = f in ('front', 'back') and (i == 0 or j == 0 or (i + j // 2) % 4 == 0)
            return (vein + (215,)) if is_vein else (glass + (120,))

        paint_box(s, 40, 32, 8, 13, 1, wing)
        paint_box(s, 40, 46, 8, 13, 1, wing)
    return s


def brood_sheet():
    s = Sheet(64, 32)
    cream, shell = hexc('F2EBD8'), hexc('E0D4B6')
    body, ring = hexc('F2E6B0'), hexc('D2BE82')
    head, dot = hexc('D8BE86'), hexc('3A2A1A')
    cocoon, ridge = hexc('E4D3A4'), hexc('BFA874')
    paint_box(s, 0, 0, 4, 5, 4, lambda f, i, j, fw, fh: mix(cream, shell, noise(i, j, 21) * 0.7))
    paint_box(s, 0, 9, 3, 1, 3, lambda f, i, j, fw, fh: shade(cream, 0.92))

    def head_px(f, i, j, fw, fh):
        if f == 'front' and j == 1 and i in (0, 2):
            return dot
        return dot if (f == 'front' and j == 2 and i == 1) else head

    paint_box(s, 0, 14, 3, 3, 2, head_px)
    seg = lambda f, i, j, fw, fh: ring if axis_pos(f, i, j) % 2 == 1 else body
    paint_box(s, 0, 19, 4, 4, 3, seg)
    paint_box(s, 16, 14, 3, 3, 2, seg)
    paint_box(s, 32, 0, 4, 4, 8, lambda f, i, j, fw, fh: ridge if axis_pos(f, i, j) % 3 == 2 else (
        mix(cocoon, (255, 250, 230), 0.3) if axis_pos(f, i, j) % 3 == 0 else cocoon))
    return s


def anthill_top():
    s = Sheet(16, 16)
    base = hexc('8B5E3C')
    for y in range(16):
        for x in range(16):
            n = noise(x, y, 31)
            c = shade(base, 0.85) if n < 0.2 else shade(base, 1.12) if n > 0.85 else base
            r = ((x - 7.5) ** 2 + (y - 7.5) ** 2) ** 0.5
            if r < 2.3:
                c = hexc('1E120A')
            elif r < 3.3:
                c = hexc('3A2415')
            elif r < 4.6:
                c = shade(base, 1.2 if n > 0.4 else 1.08)
            s.put(x, y, c)
    return s


def anthill_side():
    s = Sheet(16, 16)
    base = hexc('8B5E3C')
    for y in range(16):
        for x in range(16):
            n = noise(x, y, 41)
            c = shade(base, 0.85) if n < 0.2 else shade(base, 1.12) if n > 0.85 else base
            if y < 2:
                c = shade(base, 1.18 if n > 0.3 else 1.05)  # верх горбка
            s.put(x, y, c)
    for (x, y) in ((2, 5), (3, 5), (11, 4), (12, 4), (12, 5), (4, 9), (13, 10), (1, 12), (14, 7)):
        s.put(x, y, hexc('B9A58E'))  # камінці
    arch = ((6, 11), (7, 11), (8, 11), (9, 11), (5, 12), (6, 12), (7, 12), (8, 12), (9, 12), (10, 12))
    for (x, y) in arch:
        s.put(x, y, hexc('3A2415'))
    s.rect(5, 13, 11, 16, hexc('1E120A'))  # вхід у тунель
    s.rect(6, 12, 10, 13, hexc('1E120A'))
    return s


def guide_icon():
    s = Sheet(16, 16)
    cover, dark, light = hexc('7A4A2A'), hexc('3E2412'), hexc('A8693A')
    page, gold = hexc('F2E8CC'), hexc('E0B84A')
    s.rect(2, 1, 14, 15, dark)
    s.rect(3, 2, 13, 14, cover)
    s.rect(3, 2, 5, 14, light)
    s.rect(4, 14, 13, 15, page)
    s.rect(13, 3, 14, 14, page)
    # золота мураха (вигляд зверху, головою вгору)
    ant = [(6, 3), (7, 4), (11, 3), (10, 4),                       # вусики
           (8, 4), (9, 4), (8, 5), (9, 5),                         # голова
           (8, 6), (9, 6), (8, 7), (9, 7), (8, 8), (9, 8),         # груди
           (7, 6), (6, 5), (10, 6), (11, 5),                       # передні лапки
           (7, 7), (6, 7), (10, 7), (11, 7),                       # середні лапки
           (7, 8), (6, 9), (10, 8), (11, 9),                       # задні лапки
           (8, 9), (9, 9), (7, 10), (8, 10), (9, 10), (10, 10),    # черевце
           (7, 11), (8, 11), (9, 11), (10, 11), (8, 12), (9, 12)]
    for (x, y) in ant:
        s.put(x, y, gold)
    for (x, y) in ((8, 4), (8, 5), (8, 9), (7, 10)):
        s.put(x, y, mix(gold, (255, 255, 255), 0.35))               # блік
    return s
