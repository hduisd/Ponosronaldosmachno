"""Спільні помічники для генерації текстур мода (піксель-арт на PIL)."""
import os
from PIL import Image


def hexc(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def shade(c, f):
    """f < 1 — темніше, f > 1 — світліше."""
    return tuple(max(0, min(255, int(round(x * f)))) for x in c[:3])


def mix(a, b, t):
    return tuple(int(round(a[k] + (b[k] - a[k]) * t)) for k in range(3))


def noise(x, y, seed=0):
    """Детермінований «шум» 0..1 (щоб текстури збирались однаково щоразу)."""
    n = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


class Sheet:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.img = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        self.px = self.img.load()

    def put(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h and c is not None:
            self.px[x, y] = tuple(c) if len(c) == 4 else (c[0], c[1], c[2], 255)

    def get(self, x, y):
        return self.px[x, y]

    def rect(self, x0, y0, x1, y1, c):
        """Заливка [x0, x1) x [y0, y1)."""
        for y in range(y0, y1):
            for x in range(x0, x1):
                self.put(x, y, c)

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.img.save(path)


def box_faces(u, v, w, h, d):
    """Розкладка куба Minecraft: {грань: (x0, y0, ширина, висота)}."""
    return {
        'top': (u + d, v, w, d),
        'bottom': (u + d + w, v, w, d),
        'right': (u, v + d, d, h),
        'front': (u + d, v + d, w, h),
        'left': (u + d + w, v + d, d, h),
        'back': (u + 2 * d + w, v + d, w, h),
    }


def paint_box(sheet, u, v, w, h, d, fn):
    """fn(грань, i, j, ширина_грані, висота_грані) -> колір або None."""
    for face, (x0, y0, fw, fh) in box_faces(u, v, w, h, d).items():
        for j in range(fh):
            for i in range(fw):
                sheet.put(x0 + i, y0 + j, fn(face, i, j, fw, fh))


def chitin(p, i, j, seg=4, seed=0):
    """Колір хітинової пластини: сегменти по seg пікселів, шов унизу, блік зверху."""
    c = p['chitin']
    r = j % seg
    if r == seg - 1:
        return p['dark']
    if r == 0:
        c = mix(c, p['light'], 0.5)
    n = noise(i, j, seed)
    if n < 0.14:
        c = shade(c, 0.9)
    elif n > 0.88:
        c = shade(c, 1.1)
    return c
