#!/usr/bin/env python3
"""Генерує JSON-ресурси мода (мови, моделі, блокстейт, лут, рецепт, теги, біомний модифікатор).
Запуск: python3 tools/gen_resources.py   (з кореня проєкту)"""
import json, os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
MOD = "antcolony"


def write(rel, data):
    path = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


# ------------------------------------------------------------------ мови
uk = {
    "itemGroup.antcolony": "Колонія",
    "block.antcolony.anthill": "Мурашник",
    "item.antcolony.colony_guide": "Мурашиний довідник",
    "item.antcolony.ant_worker_spawn_egg": "Яйце виклику: мураха-робітниця",
    "item.antcolony.ant_soldier_spawn_egg": "Яйце виклику: мураха-солдат",
    "item.antcolony.ant_princess_spawn_egg": "Яйце виклику: принцеса мурах",
    "entity.antcolony.ant_worker": "Мураха-робітниця",
    "entity.antcolony.ant_soldier": "Мураха-солдат",
    "entity.antcolony.ant_princess": "Принцеса мурах",
    "entity.antcolony.ant_queen": "Королева мурах",
    "entity.antcolony.ant_brood": "Виводок мурах",
    "caste.antcolony.queen": "королева",
    "caste.antcolony.princess": "принцеса",
    "caste.antcolony.worker": "робітниця",
    "caste.antcolony.soldier": "солдат",
    "stage.antcolony.egg": "яйце",
    "stage.antcolony.larva": "личинка",
    "stage.antcolony.pupa": "лялечка",
    "focus.antcolony.balanced": "збалансовано",
    "focus.antcolony.workers": "більше робітниць",
    "focus.antcolony.soldiers": "більше солдатів",
    "order.antcolony.work": "працювати",
    "order.antcolony.follow": "іти за тобою",
    "order.antcolony.stay": "стояти на місці",
    "message.antcolony.order": "%1$s: наказ — %2$s",
    "message.antcolony.fed": "Їжа в мурашнику: +%1$s (запас: %2$s)",
    "message.antcolony.focus": "Колонія росте: %s",
    "message.antcolony.need_queen": "Колонії потрібна королева! Приведи принцесу (підгодуй її цукром) і натисни ПКМ по Мурашнику.",
    "message.antcolony.founded": "Принцеса стала королевою! Колонію засновано. Приноси їжу в Мурашник!",
    "message.antcolony.collapsed": "Королеви немає вже надто довго — колонія розпалася...",
    "message.antcolony.princess_born": "У колонії вилупилась принцеса! Підгодуй її цукром, щоб заснувати нову колонію.",
    "message.antcolony.princess_flew": "Принцеса злетіла у шлюбний виліт.",
    "message.antcolony.princess_follow": "Принцеса йде за тобою.",
    "message.antcolony.princess_hint": "Королевою може стати лише принцеса, а ти — робоча мураха. Дай їй цукор, щоб вона йшла за тобою, і постав Мурашник поруч.",
    "message.antcolony.queen_homeless": "Королева без Мурашника. Постав Мурашник поруч, щоб відновити колонію.",
    "info.antcolony.header": "Колонія — рівень %s",
    "info.antcolony.unfounded": "Мурашник порожній. Приведи принцесу (підгодуй цукром, щоб йшла за тобою) і натисни ПКМ по Мурашнику.",
    "info.antcolony.queen_alive": "Королева жива%s",
    "info.antcolony.queen_missing": "Королеви немає!%s",
    "info.antcolony.hungry": " — голодна!",
    "info.antcolony.food": "Запаси їжі: %1$s (всього принесено: %2$s)",
    "info.antcolony.population": "Робітниць: %1$s, солдатів: %2$s (місткість: %3$s)",
    "info.antcolony.brood": "Виводок (яйця, личинки, лялечки): %s",
    "info.antcolony.focus": "Наголос: %s (Shift+ПКМ порожніми руками по Мурашнику — змінити)",
    "command.antcolony.no_colony": "Поруч немає колонії.",
    "guide.antcolony.title": "§6=== Мурашиний довідник ===",
    "guide.antcolony.line1": "1. Ти — мураха-робітниця. Королевою гравець бути не може.",
    "guide.antcolony.line2": "2. Щоб почати колонію, потрібна королева: знайди принцесу (молоду крилату королеву) — вона іноді зустрічається на галявинах.",
    "guide.antcolony.line3": "3. Дай принцесі цукор (ПКМ) — вона піде за тобою. Постав Мурашник поруч із нею (або натисни ПКМ по Мурашнику) — принцеса скине крила й стане королевою.",
    "guide.antcolony.line4": "4. У колонії лише одна королева. Загине королева — колонія розпадеться, тож охороняй її.",
    "guide.antcolony.line5": "5. Королева відкладає яйця: яйце → личинка (її годують із запасів) → лялечка → доросла мураха (робітниця або солдат).",
    "guide.antcolony.line6": "6. Їжа (цукор, насіння, хліб, ягоди, м'ясо...) — запаси колонії. Клацни їжею по Мурашнику (вся їжа з руки піде на склад) або кинь її на землю: робітниці віднесуть.",
    "guide.antcolony.line7": "7. ПКМ порожньою рукою по Мурашнику — стан колонії. Shift+ПКМ (з порожніми руками) — наголос: більше робітниць чи солдатів.",
    "guide.antcolony.line8": "8. ПКМ порожньою рукою по робітниці чи солдату — наказ: працювати / іти за тобою / стояти. Солдати б'ють ворожих мобів.",
    "guide.antcolony.line9": "9. Сильна колонія (рівень 3+) вирощує нових принцес для шлюбного вильоту: підгодуй принцесу цукром і засновуй нову колонію! Команди: /colony help, /colony info.",
}

en = {
    "itemGroup.antcolony": "Ant Colony",
    "block.antcolony.anthill": "Anthill",
    "item.antcolony.colony_guide": "Ant Colony Guide",
    "item.antcolony.ant_worker_spawn_egg": "Worker Ant Spawn Egg",
    "item.antcolony.ant_soldier_spawn_egg": "Soldier Ant Spawn Egg",
    "item.antcolony.ant_princess_spawn_egg": "Ant Princess Spawn Egg",
    "entity.antcolony.ant_worker": "Worker Ant",
    "entity.antcolony.ant_soldier": "Soldier Ant",
    "entity.antcolony.ant_princess": "Ant Princess",
    "entity.antcolony.ant_queen": "Ant Queen",
    "entity.antcolony.ant_brood": "Ant Brood",
    "caste.antcolony.queen": "queen",
    "caste.antcolony.princess": "princess",
    "caste.antcolony.worker": "worker",
    "caste.antcolony.soldier": "soldier",
    "stage.antcolony.egg": "egg",
    "stage.antcolony.larva": "larva",
    "stage.antcolony.pupa": "pupa",
    "focus.antcolony.balanced": "balanced",
    "focus.antcolony.workers": "more workers",
    "focus.antcolony.soldiers": "more soldiers",
    "order.antcolony.work": "work",
    "order.antcolony.follow": "follow you",
    "order.antcolony.stay": "stay here",
    "message.antcolony.order": "%1$s: order - %2$s",
    "message.antcolony.fed": "Food delivered: +%1$s (stock: %2$s)",
    "message.antcolony.focus": "The colony now grows: %s",
    "message.antcolony.need_queen": "The colony needs a queen! Bring a princess (feed her sugar) and right-click the Anthill.",
    "message.antcolony.founded": "The princess became the queen! The colony is founded. Bring food to the Anthill!",
    "message.antcolony.collapsed": "The queen has been gone too long - the colony has collapsed...",
    "message.antcolony.princess_born": "A princess hatched in the colony! Feed her sugar to found a new colony.",
    "message.antcolony.princess_flew": "The princess took off on her nuptial flight.",
    "message.antcolony.princess_follow": "The princess follows you.",
    "message.antcolony.princess_hint": "Only a princess can become a queen - you are a worker ant. Give her sugar so she follows you, then place an Anthill nearby.",
    "message.antcolony.queen_homeless": "A queen without an Anthill. Place an Anthill nearby to restore the colony.",
    "info.antcolony.header": "Colony - level %s",
    "info.antcolony.unfounded": "The Anthill is empty. Bring a princess (feed her sugar so she follows you) and right-click the Anthill.",
    "info.antcolony.queen_alive": "The queen is alive%s",
    "info.antcolony.queen_missing": "No queen!%s",
    "info.antcolony.hungry": " - hungry!",
    "info.antcolony.food": "Food stock: %1$s (total delivered: %2$s)",
    "info.antcolony.population": "Workers: %1$s, soldiers: %2$s (capacity: %3$s)",
    "info.antcolony.brood": "Brood (eggs, larvae, pupae): %s",
    "info.antcolony.focus": "Focus: %s (Shift+right-click the Anthill with empty hands to change)",
    "command.antcolony.no_colony": "There is no colony nearby.",
    "guide.antcolony.title": "§6=== Ant Colony Guide ===",
    "guide.antcolony.line1": "1. You are a worker ant. A player can never be the queen.",
    "guide.antcolony.line2": "2. To start a colony you need a queen: find a princess (a young winged queen) - she sometimes appears in meadows.",
    "guide.antcolony.line3": "3. Give the princess sugar (right-click) so she follows you. Place an Anthill next to her (or right-click the Anthill) - she sheds her wings and becomes the queen.",
    "guide.antcolony.line4": "4. A colony has exactly one queen. If she dies the colony collapses, so protect her.",
    "guide.antcolony.line5": "5. The queen lays eggs: egg -> larva (fed from the food stock) -> pupa -> adult ant (worker or soldier).",
    "guide.antcolony.line6": "6. Food (sugar, seeds, bread, berries, meat...) is the colony stock. Right-click the Anthill with food (everything in your hand goes into the stock) or drop it on the ground: workers carry it home.",
    "guide.antcolony.line7": "7. Right-click the Anthill with an empty hand for colony status. Shift+right-click (empty hands) to change the focus: more workers or more soldiers.",
    "guide.antcolony.line8": "8. Right-click a worker or soldier with an empty hand to give an order: work / follow you / stay. Soldiers fight hostile mobs.",
    "guide.antcolony.line9": "9. A strong colony (level 3+) raises new princesses for the nuptial flight: feed one sugar and found a new colony! Commands: /colony help, /colony info.",
}
write("assets/%s/lang/uk_ua.json" % MOD, uk)
write("assets/%s/lang/en_us.json" % MOD, en)

# ------------------------------------------------------------------ блок / предмети
write("assets/%s/blockstates/anthill.json" % MOD, {"variants": {"": {"model": "%s:block/anthill" % MOD}}})
write("assets/%s/models/block/anthill.json" % MOD, {
    "parent": "minecraft:block/cube_bottom_top",
    "textures": {
        "top": "%s:block/anthill_top" % MOD,
        "side": "%s:block/anthill_side" % MOD,
        "bottom": "minecraft:block/dirt",
    },
})
write("assets/%s/models/item/anthill.json" % MOD, {"parent": "%s:block/anthill" % MOD})
write("assets/%s/models/item/colony_guide.json" % MOD, {
    "parent": "minecraft:item/generated",
    "textures": {"layer0": "%s:item/colony_guide" % MOD},
})
for egg in ("ant_worker", "ant_soldier", "ant_princess"):
    write("assets/%s/models/item/%s_spawn_egg.json" % (MOD, egg), {"parent": "minecraft:item/template_spawn_egg"})

# ------------------------------------------------------------------ дані
write("data/%s/loot_table/blocks/anthill.json" % MOD, {
    "type": "minecraft:block",
    "pools": [{
        "rolls": 1.0,
        "bonus_rolls": 0.0,
        "conditions": [{"condition": "minecraft:survives_explosion"}],
        "entries": [{"type": "minecraft:item", "name": "%s:anthill" % MOD}],
    }],
    "random_sequence": "%s:blocks/anthill" % MOD,
})
write("data/%s/recipe/anthill.json" % MOD, {
    "type": "minecraft:crafting_shapeless",
    "category": "misc",
    "ingredients": [
        {"item": "minecraft:dirt"}, {"item": "minecraft:dirt"},
        {"item": "minecraft:dirt"}, {"item": "minecraft:dirt"},
        {"item": "minecraft:sugar"}, {"item": "minecraft:wheat_seeds"},
    ],
    "result": {"id": "%s:anthill" % MOD, "count": 1},
})
food = [
    "sugar", "honey_bottle", "wheat_seeds", "beetroot_seeds", "melon_seeds", "pumpkin_seeds",
    "torchflower_seeds", "pitcher_pod", "bread", "apple", "golden_apple", "sweet_berries", "glow_berries",
    "melon_slice", "carrot", "golden_carrot", "potato", "baked_potato", "beetroot", "cookie", "pumpkin_pie",
    "cake", "dried_kelp", "beef", "cooked_beef", "porkchop", "cooked_porkchop", "mutton", "cooked_mutton",
    "chicken", "cooked_chicken", "rabbit", "cooked_rabbit", "cod", "cooked_cod", "salmon", "cooked_salmon",
    "rotten_flesh", "spider_eye", "egg", "wheat", "chorus_fruit",
]
write("data/%s/tags/item/ant_food.json" % MOD, {"replace": False, "values": ["minecraft:" + f for f in food]})
write("data/minecraft/tags/block/mineable/shovel.json", {"replace": False, "values": ["%s:anthill" % MOD]})
write("data/%s/neoforge/biome_modifier/princess_spawns.json" % MOD, {
    "type": "neoforge:add_spawns",
    "biomes": "#minecraft:is_overworld",
    "spawners": {"type": "%s:ant_princess" % MOD, "weight": 3, "minCount": 1, "maxCount": 1},
})
print("resources written to", os.path.normpath(ROOT))
