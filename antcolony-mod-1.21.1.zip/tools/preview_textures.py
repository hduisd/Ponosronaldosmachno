#!/usr/bin/env python3
"""Збирає контактний лист із «ляльок» (вигляд спереду/ззаду) для перегляду текстур.
Запуск:  python3 tools/preview_textures.py <вихідний.png>"""
import os
import sys
from PIL import Image

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main',
                                     'resources', 'assets', 'antcolony', 'textures'))
SCALE = 10

# (джерело x, y, ширина, висота, куди x, y) — вигляд спереду
FRONT = [((8, 8, 8, 8), (4, 0)), ((20, 20, 8, 12), (4, 8)), ((44, 20, 3, 12), (1, 8)), ((36, 52, 3, 12), (12, 8)),
         ((4, 20, 4, 12), (4, 20)), ((20, 52, 4, 12), (8, 20)),
         ((20, 36, 8, 12), (4, 8)), ((44, 36, 3, 12), (1, 8)), ((52, 52, 3, 12), (12, 8)),
         ((4, 36, 4, 12), (4, 20)), ((4, 52, 4, 12), (8, 20)), ((40, 8, 8, 8), (4, 0))]
BACK = [((24, 8, 8, 8), (4, 0)), ((32, 20, 8, 12), (4, 8)), ((51, 20, 3, 12), (12, 8)), ((43, 52, 3, 12), (1, 8)),
        ((12, 20, 4, 12), (8, 20)), ((28, 52, 4, 12), (4, 20)),
        ((32, 36, 8, 12), (4, 8)), ((51, 36, 3, 12), (12, 8)), ((59, 52, 3, 12), (1, 8)),
        ((12, 36, 4, 12), (8, 20)), ((12, 52, 4, 12), (4, 20)), ((56, 8, 8, 8), (4, 0))]


def doll(skin, parts):
    img = Image.new('RGBA', (16, 32), (0, 0, 0, 0))
    for (x, y, w, h), (dx, dy) in parts:
        piece = skin.crop((x, y, x + w, y + h))
        img.alpha_composite(piece, (dx, dy))
    return img.resize((16 * SCALE, 32 * SCALE), Image.NEAREST)


def main(out):
    names = ['worker', 'soldier', 'princess', 'queen']
    sheet = Image.new('RGBA', (len(names) * 2 * 16 * SCALE + 20 * (len(names) * 2 + 1), 32 * SCALE + 40), (70, 70, 80, 255))
    x = 20
    for n in names:
        skin = Image.open(os.path.join(ROOT, 'entity', 'ant', n + '.png')).convert('RGBA')
        for parts in (FRONT, BACK):
            sheet.alpha_composite(doll(skin, parts), (x, 20))
            x += 16 * SCALE + 20
    sheet.save(out)
    # другий лист: сирі текстури x4
    raw = Image.new('RGBA', (4 * 64 * 4 + 50, 2 * 64 * 4 + 30), (70, 70, 80, 255))
    for k, n in enumerate(names):
        for r, suffix in enumerate(('', '_extras')):
            im = Image.open(os.path.join(ROOT, 'entity', 'ant', n + suffix + '.png')).convert('RGBA')
            raw.alpha_composite(im.resize((256, 256), Image.NEAREST), (10 + k * 266, 10 + r * 266))
    raw.save(out.replace('.png', '_raw.png'))
    # третій лист: виводок + блок + іконка x10
    misc = Image.new('RGBA', (900, 340), (70, 70, 80, 255))
    brood = Image.open(os.path.join(ROOT, 'entity', 'ant', 'brood.png')).convert('RGBA').resize((512, 256), Image.NEAREST)
    misc.alpha_composite(brood, (10, 10))
    for k, p in enumerate(('block/anthill_top.png', 'block/anthill_side.png', 'item/colony_guide.png')):
        im = Image.open(os.path.join(ROOT, p)).convert('RGBA').resize((160, 160), Image.NEAREST)
        misc.alpha_composite(im, (540 + (k % 2) * 170, 10 + (k // 2) * 170))
    misc.save(out.replace('.png', '_misc.png'))


if __name__ == '__main__':
    main(sys.argv[1])
