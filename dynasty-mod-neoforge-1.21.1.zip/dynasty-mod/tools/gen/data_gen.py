# -*- coding: utf-8 -*-
"""Blockstates, models, recipes, loot tables, tags, advancement and language files."""
import json
import os

import lang_data
from pix import RESOURCES

ASSETS = os.path.join(RESOURCES, "assets", "dynasty")
DATA = os.path.join(RESOURCES, "data")

BUILDINGS = ["town_hall", "house", "farm", "lumber_camp", "quarry", "market", "academy", "tavern", "barracks",
             "garage", "watchtower", "refinery"]
STONE = ["town_hall", "quarry", "academy", "barracks", "garage", "watchtower", "refinery"]
WOOD = ["house", "farm", "lumber_camp", "market", "tavern"]
FLAT_ITEMS = ["coin", "ring", "fuel_canister", "royal_scroll", "musket_ball", "cartridge", "rocket", "shell", "grenade",
              "cart", "jeep", "truck", "tank"]
HANDHELD = ["flintlock_pistol", "musket", "rifle", "smg", "bazooka", "halberd", "command_banner"]
EGGS = ["citizen_spawn_egg", "soldier_spawn_egg", "bandit_spawn_egg"]


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


def models():
    for b in BUILDINGS:
        write_json(os.path.join(ASSETS, "blockstates", b + ".json"), {"variants": {"": {"model": "dynasty:block/" + b}}})
        write_json(os.path.join(ASSETS, "models", "block", b + ".json"), {
            "parent": "minecraft:block/cube_column",
            "textures": {"end": "dynasty:block/%s_top" % b, "side": "dynasty:block/%s_side" % b},
        })
        write_json(os.path.join(ASSETS, "models", "item", b + ".json"), {"parent": "dynasty:block/" + b})
    for i in FLAT_ITEMS:
        write_json(os.path.join(ASSETS, "models", "item", i + ".json"),
                   {"parent": "minecraft:item/generated", "textures": {"layer0": "dynasty:item/" + i}})
    for i in HANDHELD:
        write_json(os.path.join(ASSETS, "models", "item", i + ".json"),
                   {"parent": "minecraft:item/handheld", "textures": {"layer0": "dynasty:item/" + i}})
    for i in EGGS:
        write_json(os.path.join(ASSETS, "models", "item", i + ".json"), {"parent": "minecraft:item/template_spawn_egg"})


def lang():
    for idx, code in ((0, "uk_ua"), (1, "en_us")):
        data = {k: v[idx] for k, v in sorted(lang_data.T.items())}
        write_json(os.path.join(ASSETS, "lang", code + ".json"), data)


# ------------------------------------------------------------------------------------------------------------------
# recipes
# ------------------------------------------------------------------------------------------------------------------

def item(i):
    return {"item": i}


def tag(t):
    return {"tag": t}


RECIPES = {}


def shaped(name, pattern, key, result, count=1, category="misc"):
    RECIPES[name] = {
        "type": "minecraft:crafting_shaped",
        "category": category,
        "key": key,
        "pattern": pattern,
        "result": {"id": result, "count": count},
    }


def shapeless(name, ingredients, result, count=1, category="misc"):
    RECIPES[name] = {
        "type": "minecraft:crafting_shapeless",
        "category": category,
        "ingredients": ingredients,
        "result": {"id": result, "count": count},
    }


def recipes():
    d = "dynasty:"
    m = "minecraft:"
    # --- currency & small items
    shapeless("coins_from_gold", [item(m + "gold_ingot")], d + "coin", 9)
    shapeless("gold_from_coins", [item(d + "coin")] * 9, m + "gold_ingot", 1)
    shaped("ring", [" D ", "G G", " G "], {"G": item(m + "gold_ingot"), "D": item(m + "diamond")}, d + "ring")
    shaped("fuel_canister", ["I I", "CCC", "III"], {"I": item(m + "iron_ingot"), "C": item(m + "coal")}, d + "fuel_canister")
    shapeless("royal_scroll", [item(m + "paper"), item(m + "gold_ingot"), item(m + "red_dye")], d + "royal_scroll")
    shaped("command_banner", ["WWW", "WGW", " S "],
           {"W": item(m + "red_wool"), "G": item(m + "gold_ingot"), "S": item(m + "stick")}, d + "command_banner")

    # --- ammunition
    shapeless("musket_ball", [item(m + "iron_ingot"), item(m + "gunpowder")], d + "musket_ball", 6)
    shapeless("cartridge", [item(m + "copper_ingot"), item(m + "gunpowder"), item(m + "iron_nugget")], d + "cartridge", 16)
    shaped("rocket", ["I", "G", "G"], {"I": item(m + "iron_ingot"), "G": item(m + "gunpowder")}, d + "rocket", 2)
    shapeless("shell", [item(m + "iron_ingot"), item(m + "copper_ingot"), item(m + "gunpowder"), item(m + "gunpowder"),
                        item(m + "gunpowder")], d + "shell", 2)
    shaped("grenade", [" N ", "IGI", " I "],
           {"N": item(m + "iron_nugget"), "I": item(m + "iron_ingot"), "G": item(m + "gunpowder")}, d + "grenade", 2)

    # --- weapons
    shaped("flintlock_pistol", ["II ", "IF ", " S "],
           {"I": item(m + "iron_ingot"), "F": item(m + "flint"), "S": item(m + "stick")}, d + "flintlock_pistol")
    shaped("musket", ["IIF", " S ", " W "],
           {"I": item(m + "iron_ingot"), "F": item(m + "flint"), "S": item(m + "stick"), "W": tag("minecraft:planks")},
           d + "musket")
    shaped("rifle", ["III", "IFS", " WS"],
           {"I": item(m + "iron_ingot"), "F": item(m + "flint_and_steel"), "S": item(m + "stick"), "W": tag("minecraft:planks")},
           d + "rifle")
    shaped("smg", ["III", "BRI", " BG"],
           {"I": item(m + "iron_ingot"), "B": item(m + "iron_block"), "R": item(m + "redstone"), "G": item(m + "gunpowder")},
           d + "smg")
    shaped("bazooka", ["IIB", "GTI", "IIB"],
           {"I": item(m + "iron_ingot"), "B": item(m + "iron_block"), "G": item(m + "gunpowder"), "T": item(m + "tnt")},
           d + "bazooka")
    shaped("halberd", ["  I", " SI", "S  "], {"I": item(m + "iron_ingot"), "S": item(m + "stick")}, d + "halberd")

    # --- buildings
    shaped("town_hall", ["GBG", "BDB", "BBB"],
           {"G": item(m + "gold_ingot"), "B": item(m + "stone_bricks"), "D": tag("minecraft:wooden_doors")}, d + "town_hall")
    shaped("house", ["PPP", "PWP", "PDP"],
           {"P": tag("minecraft:planks"), "W": item(m + "glass_pane"), "D": tag("minecraft:wooden_doors")}, d + "house")
    shaped("farm", ["WWW", "PPP", "DDD"],
           {"W": item(m + "wheat"), "P": tag("minecraft:planks"), "D": item(m + "dirt")}, d + "farm")
    shaped("lumber_camp", ["LLL", "LAL", "PPP"],
           {"L": tag("minecraft:logs"), "A": item(m + "iron_axe"), "P": tag("minecraft:planks")}, d + "lumber_camp")
    shaped("quarry", ["CCC", "CPC", "III"],
           {"C": item(m + "cobblestone"), "P": item(m + "iron_pickaxe"), "I": item(m + "iron_ingot")}, d + "quarry")
    shaped("market", ["RWR", "PPP", "CCC"],
           {"R": item(m + "red_wool"), "W": item(m + "white_wool"), "P": tag("minecraft:planks"), "C": item(d + "coin")},
           d + "market")
    shaped("academy", ["BBB", "SLS", "SSS"],
           {"B": item(m + "book"), "L": item(m + "lectern"), "S": item(m + "stone_bricks")}, d + "academy")
    shaped("tavern", ["PPP", "BDB", "PPP"],
           {"P": tag("minecraft:planks"), "B": item(m + "barrel"), "D": tag("minecraft:wooden_doors")}, d + "tavern")
    shaped("barracks", ["BIB", "RSR", "BDB"],
           {"B": item(m + "stone_bricks"), "I": item(m + "iron_ingot"), "R": item(m + "red_wool"),
            "S": item(m + "iron_sword"), "D": tag("minecraft:wooden_doors")}, d + "barracks")
    shaped("garage", ["III", "IDI", "SSS"],
           {"I": item(m + "iron_ingot"), "D": item(m + "iron_door"), "S": item(m + "stone")}, d + "garage")
    shaped("watchtower", ["BBB", "BLB", "BBB"], {"B": item(m + "stone_bricks"), "L": item(m + "ladder")}, d + "watchtower")
    shaped("refinery", ["III", "FCF", "III"],
           {"I": item(m + "iron_ingot"), "F": item(m + "furnace"), "C": item(m + "cauldron")}, d + "refinery")

    # --- vehicles
    shaped("cart", ["S S", "PPP", "I I"],
           {"S": item(m + "stick"), "P": tag("minecraft:planks"), "I": item(m + "iron_ingot")}, d + "cart")
    shaped("jeep", ["IGI", "ICI", "LIL"],
           {"I": item(m + "iron_ingot"), "G": item(m + "glass_pane"), "C": item(d + "fuel_canister"), "L": item(m + "leather")},
           d + "jeep")
    shaped("truck", ["BBB", "IGC", "LIL"],
           {"B": item(m + "iron_block"), "I": item(m + "iron_ingot"), "G": item(m + "glass_pane"),
            "C": item(d + "fuel_canister"), "L": item(m + "leather")}, d + "truck")
    shaped("tank", ["BBB", "BEC", "LLL"],
           {"B": item(m + "iron_block"), "E": item(m + "blast_furnace"), "C": item(d + "fuel_canister"),
            "L": item(m + "chain")}, d + "tank")

    for name, obj in RECIPES.items():
        write_json(os.path.join(DATA, "dynasty", "recipe", name + ".json"), obj)

    # unlock every recipe of the mod on the first tick so they all appear in the recipe book
    write_json(os.path.join(DATA, "dynasty", "advancement", "unlock_recipes.json"), {
        "criteria": {"tick": {"trigger": "minecraft:tick"}},
        "requirements": [["tick"]],
        "rewards": {"recipes": ["dynasty:" + n for n in sorted(RECIPES)]},
    })


# ------------------------------------------------------------------------------------------------------------------
# loot tables and tags
# ------------------------------------------------------------------------------------------------------------------

def loot_and_tags():
    for b in BUILDINGS:
        write_json(os.path.join(DATA, "dynasty", "loot_table", "blocks", b + ".json"), {
            "type": "minecraft:block",
            "pools": [{
                "bonus_rolls": 0.0,
                "conditions": [{"condition": "minecraft:survives_explosion"}],
                "entries": [{"type": "minecraft:item", "name": "dynasty:" + b}],
                "rolls": 1.0,
            }],
            "random_sequence": "dynasty:blocks/" + b,
        })
    write_json(os.path.join(DATA, "dynasty", "loot_table", "entities", "bandit.json"), {
        "type": "minecraft:entity",
        "pools": [
            {
                "bonus_rolls": 0.0,
                "entries": [{
                    "type": "minecraft:item", "name": "dynasty:coin",
                    "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 0.0, "max": 3.0}}],
                }],
                "rolls": 1.0,
            },
            {
                "bonus_rolls": 0.0,
                "conditions": [{"condition": "minecraft:random_chance", "chance": 0.4}],
                "entries": [{
                    "type": "minecraft:item", "name": "dynasty:musket_ball",
                    "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 1.0, "max": 3.0}}],
                }],
                "rolls": 1.0,
            },
        ],
        "random_sequence": "dynasty:entities/bandit",
    })
    write_json(os.path.join(DATA, "minecraft", "tags", "block", "mineable", "pickaxe.json"),
               {"replace": False, "values": ["dynasty:" + b for b in STONE]})
    write_json(os.path.join(DATA, "minecraft", "tags", "block", "mineable", "axe.json"),
               {"replace": False, "values": ["dynasty:" + b for b in WOOD]})


def generate():
    models()
    lang()
    recipes()
    loot_and_tags()
    return len(RECIPES)


if __name__ == "__main__":
    print(generate(), "recipes")
