# -*- coding: utf-8 -*-
"""64x64 player-layout skins for citizens, soldiers and bandits."""
import os

from pix import *  # noqa: F401,F403

SKIN_TONES = [rgb("f1c9a0"), rgb("b87a55")]
SKIN_TONES_D = [rgb("e0b088"), rgb("9b6342")]


def regions(u, v, dx, dy, dz):
    return {
        "top": (u + dz, v, dx, dz),
        "bottom": (u + dz + dx, v, dx, dz),
        "right": (u, v + dz, dz, dy),
        "front": (u + dz, v + dz, dx, dy),
        "left": (u + dz + dx, v + dz, dz, dy),
        "back": (u + 2 * dz + dx, v + dz, dx, dy),
    }


HEAD = (0, 0, 8, 8, 8)
HAT = (32, 0, 8, 8, 8)
BODY = (16, 16, 8, 12, 4)
JACKET = (16, 32, 8, 12, 4)
R_ARM = (40, 16, 4, 12, 4)
R_SLEEVE = (40, 32, 4, 12, 4)
L_ARM = (32, 48, 4, 12, 4)
L_SLEEVE = (48, 48, 4, 12, 4)
R_LEG = (0, 16, 4, 12, 4)
R_PANTS = (0, 32, 4, 12, 4)
L_LEG = (16, 48, 4, 12, 4)
L_PANTS = (0, 48, 4, 12, 4)


def paint(img, box, fn):
    """fn(face, i, j, w, h) -> colour or None."""
    for face, (x, y, w, h) in regions(*box).items():
        for j in range(h):
            for i in range(w):
                c = fn(face, i, j, w, h)
                if c is not None:
                    img.putpixel((x + i, y + j), c)


def jitter(c, rng, amp=0.035):
    return shade(c, 1.0 + rng.uniform(-amp, amp))


class Spec(dict):
    def __getattr__(self, k):
        return self.get(k)


# ------------------------------------------------------------------------------------------------------------
# heads
# ------------------------------------------------------------------------------------------------------------

def head_painter(s, rng):
    skin = s.skin
    skin_d = shade(skin, 0.88)
    hair = s.hair
    hair_d = shade(hair, 0.78) if hair else None
    style = s.hair_style
    eye = s.eye or rgb("4a3524")
    brow = shade(hair, 0.7) if hair else shade(skin, 0.6)

    def fn(face, i, j, w, h):
        c = jitter(skin, rng, 0.025)
        if face == "bottom":
            return shade(skin, 0.75)
        if style and style != "bald" and hair:
            hc = jitter(hair, rng, 0.07)
            if face == "top":
                return hc
            if face == "back":
                lim = 8 if style == "long" else 6
                if j < lim:
                    return hc
            if face == "front":
                if j <= 1:
                    return hc
                if style == "long" and j <= 5 and (i <= 0 or i >= 7):
                    return hc
                if style != "long" and j == 2 and (i == 0 or i == 7):
                    return hc
                if style == "messy" and j == 2 and i in (2, 5):
                    return hc
            if face in ("right", "left"):
                back_half = (i <= 3) if face == "right" else (i >= 4)
                if style == "long":
                    if j <= 1 or (back_half or i in ((4,) if face == "right" else (3,))) and j <= 7:
                        return hc
                else:
                    if j <= 1 or (back_half and j <= 4):
                        return hc
        if face == "front":
            # brows
            if j == 3 and (i in (1, 2, 5, 6)):
                return brow
            # eyes
            if j == 4:
                if i in (1, 6):
                    return rgb("f4f4f4")
                if i in (2, 5):
                    return eye
            if j == 5 and i in (3, 4):
                return shade(skin, 0.93)
            if j == 6 and i in (3, 4):
                return s.lips if s.lips else shade(skin, 0.78)
            if s.blush and j == 5 and i in (1, 6):
                return mix(skin, rgb("e8808a"), 0.35)
        return c

    return fn


def head_extras(img, s, rng):
    """Beards, glasses, soot and bandages drawn straight onto the head front face."""
    x, y, w, h = regions(*HEAD)["front"]
    if s.beard:
        b = s.beard
        for j in range(5, 8):
            for i in range(0, 8):
                if j == 5 and i not in (0, 1, 6, 7):
                    continue
                if j == 6 and i in (3, 4):
                    img.putpixel((x + i, y + j), s.lips if s.lips else shade(s.skin, 0.78))
                    continue
                if j == 7 and i in (0, 7):
                    continue
                img.putpixel((x + i, y + j), jitter(b, rng, 0.09))
    if s.mustache:
        for i in (2, 3, 4, 5):
            img.putpixel((x + i, y + 5), jitter(s.mustache, rng, 0.08))
    if s.glasses:
        g = rgb("23252b")
        for i in (0, 1, 2, 3, 4, 5, 6, 7):
            if i in (3, 4):
                img.putpixel((x + i, y + 4), g)
        for i in (1, 2, 5, 6):
            img.putpixel((x + i, y + 3), g)
            img.putpixel((x + i, y + 5), g)
        img.putpixel((x + 0, y + 4), g)
        img.putpixel((x + 7, y + 4), g)
    if s.soot:
        for p in [(1, 6), (6, 2), (5, 6), (2, 5), (7, 5), (0, 2)]:
            img.putpixel((x + p[0], y + p[1]), mix(img.getpixel((x + p[0], y + p[1])), rgb("2b2622"), 0.55))
    if s.scar:
        for p in [(5, 3), (5, 4), (6, 5)]:
            img.putpixel((x + p[0], y + p[1]), rgb("c26a6a"))


# ------------------------------------------------------------------------------------------------------------
# hats (overlay layer of the head)
# ------------------------------------------------------------------------------------------------------------

def hat_painter(s, rng):
    kind = s.hat
    if not kind:
        return None
    base = s.hat_color or rgb("808080")
    trim = s.hat_trim or shade(base, 0.7)

    def band(face, i, j, rows, c):
        return c if j < rows else None

    def fn(face, i, j, w, h):
        hc = jitter(base, rng, 0.05)
        if kind == "straw":
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2:
                return trim
            if j == 3 and face in ("front", "left", "right", "back") and (i % 2 == 0):
                return shade(base, 0.85)
            return None
        if kind == "cap":  # flat cap / beanie
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2:
                return trim
            return None
        if kind == "visor":  # peaked cap
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2 and face == "front":
                return trim
            if j == 2:
                return hc
            return None
        if kind == "helmet":  # kettle hat / steel pot
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 2:
                return hc
            if j == 3:
                return trim
            if j == 4 and face == "front" and i in (3, 4):
                return trim
            return None
        if kind == "miner":
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 2:
                return hc
            if j == 3:
                return trim
            if face == "front" and j == 1 and i in (3, 4):
                return rgb("fff7c2")
            if face == "front" and j == 2 and i in (3, 4):
                return rgb("ffd23a")
            return None
        if kind == "tricorne":
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2:
                return trim
            if j == 3 and face == "front" and i in (0, 7):
                return hc
            return None
        if kind == "wide":
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2:
                return trim
            if j == 3:
                return shade(base, 0.8)
            return None
        if kind == "hood":
            if face == "top" or face == "back":
                return hc
            if face == "bottom":
                return None
            if face == "front":
                if j <= 1 or i in (0, 7):
                    return hc
                return None
            if face in ("left", "right"):
                return hc
            return None
        if kind == "greathelm":
            if face == "bottom":
                return None
            if face == "front":
                if j == 4 and 1 <= i <= 6:
                    return rgb("14161a")
                if j in (5, 6) and i in (2, 5):
                    return rgb("14161a")
                if i == 3 or i == 4:
                    return shade(base, 1.12) if j <= 3 else hc
                return hc
            if j == 0 and face == "top":
                return trim
            return hc
        if kind == "feather":  # small cap with a feather
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2:
                return trim
            if face == "left" and j == 0 and i < 3:
                return rgb("f2f2f2")
            if face == "left" and j == 1 and i < 2:
                return rgb("dcdcdc")
            return None
        if kind == "scholar":
            if face == "top":
                return hc
            if face == "bottom":
                return None
            if j <= 1:
                return hc
            if j == 2:
                return rgb("e6b93c") if (i % 2 == 0) else trim
            return None
        return None

    return fn


def mask_painter(s, rng):
    """Cloth over the lower face (bandits)."""
    if not s.mask:
        return None
    base = s.mask

    def fn(face, i, j, w, h):
        if face in ("top", "bottom"):
            return None
        if face == "front":
            if j == 4 and i in (0, 7):
                return jitter(base, rng, 0.05)
            if j >= 5:
                return jitter(base, rng, 0.05)
            return None
        if face in ("left", "right"):
            front_side = (i >= 4) if face == "right" else (i <= 3)
            if front_side and j >= 5:
                return jitter(base, rng, 0.05)
            return None
        if face == "back":
            if j in (4, 5):
                return shade(base, 0.8)
        return None

    return fn


# ------------------------------------------------------------------------------------------------------------
# bodies
# ------------------------------------------------------------------------------------------------------------

def torso_painter(s, rng):
    base = s.shirt
    pat = s.pattern
    acc = s.shirt2 or shade(base, 0.7)

    def fn(face, i, j, w, h):
        c = jitter(base, rng, 0.04)
        if face == "bottom":
            return shade(base, 0.7)
        if pat == "plaid":
            if (j % 4 < 2) ^ (i % 4 < 2):
                c = jitter(acc, rng, 0.05)
            elif j % 4 == 0 or i % 4 == 0:
                c = shade(base, 0.85)
        elif pat == "overalls":
            if face == "front":
                if 2 <= i <= 5 and j >= 3:
                    c = jitter(acc, rng, 0.04)
                    if j == 6 and i in (3, 4):
                        c = shade(acc, 0.75)
                if i in (2, 5) and j <= 2:
                    c = jitter(acc, rng, 0.04)
                if j >= 3 and i in (2, 5):
                    c = shade(acc, 0.9)
                if (i, j) in ((2, 3), (5, 3)):
                    c = rgb("e8c13b")
            elif face == "back":
                if 1 <= i <= 6 and j >= 4:
                    c = jitter(acc, rng, 0.04)
                if i in (2, 5) and j <= 3:
                    c = jitter(acc, rng, 0.04)
            else:
                if j >= 4:
                    c = jitter(acc, rng, 0.04)
        elif pat == "tunic":
            if j == 8 and face != "top":
                c = rgb("5a4228")
            if face == "front" and j <= 1 and i in (3, 4):
                c = shade(s.skin, 0.95)
            if j >= 9:
                c = shade(base, 0.92)
        elif pat == "robe":
            if face in ("front", "back"):
                if i in (3, 4):
                    c = jitter(acc, rng, 0.05)
            if j == 8 and face != "top":
                c = rgb("e6b93c")
            if face == "front" and j <= 1 and i in (3, 4):
                c = shade(s.skin, 0.95)
        elif pat == "coat":
            if face == "front":
                if i in (3, 4) and j >= 1:
                    c = rgb("efe6d0")
                if i in (3, 4) and j in (2, 5, 8):
                    c = rgb("e6b93c")
                if i in (1, 6) and 0 <= j <= 2:
                    c = shade(base, 1.25)
            if j == 9 and face != "top":
                c = rgb("e6b93c")
        elif pat == "gambeson":
            if (i + j) % 4 == 0:
                c = shade(base, 0.82)
            if j == 8 and face != "top":
                c = rgb("4a3a28")
        elif pat == "leather":
            if face == "front" and i in (0, 1, 6, 7):
                c = rgb("5a3c22")
            if j == 8 and face != "top":
                c = rgb("3a281a")
            if face == "front" and j <= 1 and i in (3, 4):
                c = shade(s.skin, 0.95)
        elif pat == "plate":
            c = jitter(base, rng, 0.05)
            if face == "front":
                if i in (3, 4):
                    c = shade(base, 1.15)
                if j in (3, 7):
                    c = shade(base, 0.8)
            if j == 9 and face != "top":
                c = rgb("2c2e33")
        elif pat == "uniform":
            if face == "front" and i in (3, 4) and j in (1, 3, 5, 7):
                c = rgb("e6b93c")
            if j == 8 and face != "top":
                c = rgb("3a2a1c")
            if face == "front" and i == 2 and j in (3, 4):
                c = shade(base, 0.7)
        elif pat == "belts":
            if face == "front":
                for k in range(10):
                    if i == 1 + (k * 6) // 10 and j == k:
                        c = rgb("ece8dc")
                    if i == 6 - (k * 6) // 10 and j == k:
                        c = rgb("ece8dc")
            if face == "back":
                if i in (3, 4):
                    c = shade(base, 0.9)
            if j == 9 and face != "top":
                c = rgb("2a211a")
        elif pat == "camo":
            n = ((i * 7 + j * 13) % 11)
            if n < 3:
                c = rgb("2f3a22")
            elif n < 5:
                c = rgb("8b8a5a")
            if face == "front" and j in (1, 2) and i in (1, 2, 5, 6):
                c = rgb("2a2d24")
        elif pat == "rags":
            if (i * 5 + j * 3) % 7 == 0:
                c = shade(base, 0.7)
            if j >= 10 and i % 2 == 0:
                c = shade(base, 0.8)
            if j == 8 and face != "top":
                c = rgb("2a211a")
        elif pat == "longcoat":
            if face == "front" and i in (3, 4):
                c = shade(base, 0.75)
            if j == 8 and face != "top":
                c = rgb("1a1410")
        return c

    return fn


def arm_painter(s, rng, left):
    base = s.sleeve or s.shirt
    length = s.sleeve_rows if s.sleeve_rows is not None else 12
    glove = s.gloves
    skin = s.skin
    pat = s.pattern
    acc = s.shirt2 or shade(base, 0.7)

    def fn(face, i, j, w, h):
        if face == "bottom":
            return jitter(glove or skin, rng, 0.03)
        if j < length:
            c = jitter(base, rng, 0.04)
            if pat == "plaid":
                if (j % 4 < 2) ^ (i % 4 < 2):
                    c = jitter(acc, rng, 0.05)
            if pat == "plate" and j in (3, 7):
                c = shade(base, 0.8)
            if pat == "plate" and j <= 1:
                c = shade(base, 1.15)
            if pat == "camo":
                n = ((i * 5 + j * 9) % 11)
                c = rgb("2f3a22") if n < 3 else (rgb("8b8a5a") if n < 5 else c)
            if j == length - 1 and s.cuff and face != "top":
                c = s.cuff
            return c
        if glove and j >= h - 2:
            return jitter(glove, rng, 0.04)
        return jitter(skin, rng, 0.03)

    return fn


def leg_painter(s, rng, left):
    base = s.pants
    boots = s.boots
    pat = s.pattern
    boot_rows = s.boot_rows if s.boot_rows is not None else 3

    def fn(face, i, j, w, h):
        if face == "top":
            return shade(base, 0.9)
        if face == "bottom":
            return jitter(boots or base, rng, 0.03)
        if boots and j >= h - boot_rows:
            c = jitter(boots, rng, 0.04)
            if j == h - boot_rows:
                c = shade(boots, 1.2)
            return c
        c = jitter(base, rng, 0.04)
        if pat == "camo":
            n = ((i * 3 + j * 7) % 11)
            c = rgb("2f3a22") if n < 3 else (rgb("8b8a5a") if n < 5 else c)
        if pat == "plate" and j in (3, 6):
            c = shade(base, 0.82)
        if s.pants_stripe and i == (3 if left else 0) and face in ("front", "back"):
            c = s.pants_stripe
        if s.knee_patch and j in (5, 6) and face == "front" and i in (1, 2):
            c = shade(base, 0.8)
        return c

    return fn


# ------------------------------------------------------------------------------------------------------------
# overlay layers (jacket / pants): robes, dresses, tabards, long hair
# ------------------------------------------------------------------------------------------------------------

def overlay_body(img, s, rng):
    box = JACKET
    kind = s.over
    if kind == "tabard":
        main = s.over_color
        trim = s.over_trim or rgb("e6b93c")

        def fn(face, i, j, w, h):
            if face in ("front", "back") and 2 <= i <= 5 and 1 <= j <= 10:
                c = jitter(main, rng, 0.04)
                if face == "front":
                    if i in (3, 4) and 3 <= j <= 7:
                        c = trim
                    if j == 4 and i in (2, 5):
                        c = trim
                if j == 10:
                    c = trim if i in (2, 5) else shade(main, 0.8)
                return c
            return None

        paint(img, box, fn)
    elif kind == "coattails":
        main = s.over_color

        def fn(face, i, j, w, h):
            if j >= 8 and face in ("front", "back", "left", "right"):
                if face == "front" and i in (3, 4):
                    return None
                return jitter(main, rng, 0.04)
            return None

        paint(img, box, fn)
    elif kind == "cape":
        main = s.over_color

        def fn(face, i, j, w, h):
            if face == "back" and j >= 0:
                return jitter(main, rng, 0.05)
            if face in ("left", "right") and j >= 0 and (i >= 2 if face == "left" else i <= 1):
                return jitter(shade(main, 0.9), rng, 0.05)
            return None

        paint(img, box, fn)


def overlay_legs(img, s, rng):
    kind = s.legs_over
    if not kind:
        return
    main = s.legs_over_color
    trim = s.legs_over_trim or rgb("e6b93c")
    rows = s.legs_over_rows or 10
    for box in (R_PANTS, L_PANTS):
        def fn(face, i, j, w, h):
            if face in ("top", "bottom"):
                return None
            if j < rows:
                c = jitter(main, rng, 0.04)
                if j == rows - 1:
                    c = trim
                return c
            return None

        paint(img, box, fn)


def long_hair_on_back(img, s, rng):
    if s.hair_style != "long" or not s.hair:
        return
    x, y, w, h = regions(*JACKET)["back"]
    for j in range(0, 5):
        for i in range(1, 7):
            if j >= 3 and i in (1, 6):
                continue
            img.putpixel((x + i, y + j), jitter(s.hair, rng, 0.07))
    # a few strands over the shoulders (front)
    x, y, w, h = regions(*JACKET)["front"]
    for j in range(0, 4):
        for i in (0, 7):
            img.putpixel((x + i, y + j), jitter(s.hair, rng, 0.07))


# ------------------------------------------------------------------------------------------------------------

def make_skin(spec, seed):
    s = Spec(spec)
    rng = rng_for(seed)
    img = new(64, 64)
    paint(img, HEAD, head_painter(s, rng))
    head_extras(img, s, rng)
    paint(img, BODY, torso_painter(s, rng))
    paint(img, R_ARM, arm_painter(s, rng, False))
    paint(img, L_ARM, arm_painter(s, rng, True))
    paint(img, R_LEG, leg_painter(s, rng, False))
    paint(img, L_LEG, leg_painter(s, rng, True))
    hp = hat_painter(s, rng)
    if hp:
        paint(img, HAT, hp)
    mp = mask_painter(s, rng)
    if mp:
        paint(img, HAT, mp)
    overlay_body(img, s, rng)
    overlay_legs(img, s, rng)
    long_hair_on_back(img, s, rng)
    return img


def doll(img):
    """Front and back view for reviewing a skin."""
    out = new(34, 32)
    comp = {}

    def grab(box, face):
        x, y, w, h = regions(*box)[face]
        return img.crop((x, y, x + w, y + h))

    def stamp(dst, src, pos):
        dst.alpha_composite(src, pos)

    for ox, view in ((0, "front"), (18, "back")):
        sub = new(16, 32)
        if view == "front":
            stamp(sub, grab(HEAD, "front"), (4, 0)); stamp(sub, grab(HAT, "front"), (4, 0))
            stamp(sub, grab(BODY, "front"), (4, 8)); stamp(sub, grab(JACKET, "front"), (4, 8))
            stamp(sub, grab(R_ARM, "front"), (0, 8)); stamp(sub, grab(R_SLEEVE, "front"), (0, 8))
            stamp(sub, grab(L_ARM, "front"), (12, 8)); stamp(sub, grab(L_SLEEVE, "front"), (12, 8))
            stamp(sub, grab(R_LEG, "front"), (4, 20)); stamp(sub, grab(R_PANTS, "front"), (4, 20))
            stamp(sub, grab(L_LEG, "front"), (8, 20)); stamp(sub, grab(L_PANTS, "front"), (8, 20))
        else:
            stamp(sub, grab(HEAD, "back"), (4, 0)); stamp(sub, grab(HAT, "back"), (4, 0))
            stamp(sub, grab(BODY, "back"), (4, 8)); stamp(sub, grab(JACKET, "back"), (4, 8))
            stamp(sub, grab(R_ARM, "back"), (12, 8)); stamp(sub, grab(R_SLEEVE, "back"), (12, 8))
            stamp(sub, grab(L_ARM, "back"), (0, 8)); stamp(sub, grab(L_SLEEVE, "back"), (0, 8))
            stamp(sub, grab(R_LEG, "back"), (8, 20)); stamp(sub, grab(R_PANTS, "back"), (8, 20))
            stamp(sub, grab(L_LEG, "back"), (4, 20)); stamp(sub, grab(L_PANTS, "back"), (4, 20))
        out.alpha_composite(sub, (ox, 0))
    return out


# ------------------------------------------------------------------------------------------------------------
# specs
# ------------------------------------------------------------------------------------------------------------

HAIR_LIGHT = [rgb("5a3a22"), rgb("d6b25e"), rgb("8a4b2a"), rgb("2f2118")]
HAIR_DARK = [rgb("17110d"), rgb("2b1d14")]
EYES = [rgb("4a3524"), rgb("3f6fa8"), rgb("4f8a4a"), rgb("2d2420")]


def citizen_specs():
    out = {}
    for pid in ["peasant", "farmer", "lumberjack", "miner", "merchant", "scholar"]:
        for sex in ("m", "f"):
            for tone in (0, 1):
                female = sex == "f"
                idx = ("peasant farmer lumberjack miner merchant scholar".split().index(pid)) * 4 + (2 if female else 0) + tone
                skin = SKIN_TONES[tone]
                hairs = HAIR_DARK if tone == 1 else HAIR_LIGHT
                hair = hairs[(idx + (1 if female else 0)) % len(hairs)]
                eye = EYES[(idx * 3 + 1) % len(EYES)] if tone == 0 else EYES[0 if idx % 2 else 3]
                s = dict(skin=skin, hair=hair, hair_style="long" if female else "short", eye=eye,
                         lips=rgb("c0505a") if female else None, blush=female, pants=rgb("6b4f2d"), boots=rgb("3d2a18"))
                if pid == "peasant":
                    s.update(shirt=rgb("b59a6b") if not female else rgb("8d6e4a"), pattern="tunic", sleeve_rows=12,
                             pants=rgb("6b4f2d"), boots=rgb("4a3320"), hat="cap" if not female else None,
                             hat_color=rgb("7a6a55"), hat_trim=rgb("5a4a3a"), knee_patch=True)
                    if female:
                        s.update(legs_over="dress", legs_over_color=rgb("8d6e4a"), legs_over_trim=rgb("6b4f2d"), legs_over_rows=9)
                elif pid == "farmer":
                    s.update(shirt=rgb("eadfc0"), shirt2=rgb("3e6ba8"), pattern="overalls", sleeve_rows=6, sleeve=rgb("eadfc0"),
                             pants=rgb("3e6ba8"), boots=rgb("4a3320"), hat="straw", hat_color=rgb("d9b653"), hat_trim=rgb("a67f2b"),
                             cuff=rgb("cfc3a2"))
                    if female:
                        s.update(shirt=rgb("f0e4c8"), shirt2=rgb("4a7bb8"), pants=rgb("4a7bb8"))
                elif pid == "lumberjack":
                    s.update(shirt=rgb("b5322a"), shirt2=rgb("2b2b2b"), pattern="plaid", sleeve_rows=12, pants=rgb("4d3a25"),
                             boots=rgb("1e1a16"), hat="cap", hat_color=rgb("2f5a3a"), hat_trim=rgb("224430"), gloves=rgb("5a4a3a"))
                    if not female:
                        s.update(beard=shade(hair, 0.9))
                    else:
                        s.update(shirt=rgb("c43b35"), pants=rgb("3a4a6a"))
                elif pid == "miner":
                    s.update(shirt=rgb("6e6a63"), pattern="leather", sleeve_rows=12, pants=rgb("3d3d40"), boots=rgb("2a2a2c"),
                             hat="miner", hat_color=rgb("d9a02a"), hat_trim=rgb("8a6a1a"), gloves=rgb("4a3a2a"), soot=True,
                             knee_patch=True)
                    if not female:
                        s.update(beard=rgb("6d6a66") if idx % 2 else shade(hair, 0.85))
                elif pid == "merchant":
                    s.update(shirt=rgb("6d3b8a"), pattern="coat", sleeve_rows=12, pants=rgb("2d2430"), boots=rgb("1a1414"),
                             hat="feather", hat_color=rgb("4f2a6a"), hat_trim=rgb("e6b93c"), over="coattails", over_color=rgb("6d3b8a"),
                             gloves=rgb("e6dfcf"), cuff=rgb("e6b93c"))
                    if not female:
                        s.update(mustache=shade(hair, 0.85))
                    else:
                        s.update(legs_over="dress", legs_over_color=rgb("6d3b8a"), legs_over_trim=rgb("e6b93c"), legs_over_rows=9)
                elif pid == "scholar":
                    s.update(shirt=rgb("2e4c8f"), shirt2=rgb("e6b93c"), pattern="robe", sleeve_rows=12, pants=rgb("2e4c8f"),
                             boots=rgb("3a2a22"), hat="scholar", hat_color=rgb("1f3669"), hat_trim=rgb("c99a2a"), glasses=True,
                             legs_over="robe", legs_over_color=rgb("2e4c8f"), legs_over_trim=rgb("e6b93c"), legs_over_rows=10,
                             cuff=rgb("e6b93c"))
                    if not male_flag(female):
                        pass
                out["%s_%s_%d" % (pid, sex, tone)] = s
    return out


def male_flag(female):
    return not female


def soldier_specs():
    skin = SKIN_TONES[0]
    base = dict(skin=skin, hair=rgb("4a3322"), hair_style="short", eye=rgb("3f6fa8"))
    out = {}
    out["footman"] = dict(base, shirt=rgb("6f7d8f"), pattern="gambeson", sleeve_rows=12, pants=rgb("5a4a3a"), boots=rgb("2f2418"),
                          hat="helmet", hat_color=rgb("8e949c"), hat_trim=rgb("5f646c"), gloves=rgb("4a3a2a"),
                          over="tabard", over_color=rgb("3f5f9a"), over_trim=rgb("e8e0c8"))
    out["archer"] = dict(base, shirt=rgb("4f7a3a"), pattern="leather", sleeve_rows=12, pants=rgb("5a4630"), boots=rgb("3a2a1a"),
                         hat="hood", hat_color=rgb("3f6a2f"), gloves=rgb("5a4630"), over="cape", over_color=rgb("3f6a2f"),
                         hair=rgb("5a3a22"))
    out["knight"] = dict(base, shirt=rgb("aab0b8"), pattern="plate", sleeve_rows=12, pants=rgb("8e949c"), boots=rgb("5a5f66"),
                         hat="greathelm", hat_color=rgb("aeb4bc"), hat_trim=rgb("c23a2e"), gloves=rgb("6f757c"), pants_stripe=None,
                         over="tabard", over_color=rgb("b3202a"), over_trim=rgb("e6b93c"), cuff=rgb("6f757c"))
    out["musketeer"] = dict(base, shirt=rgb("2f4e9a"), pattern="belts", sleeve_rows=12, pants=rgb("e4dfd0"), boots=rgb("1d1a18"),
                            hat="tricorne", hat_color=rgb("1c1c24"), hat_trim=rgb("e8e0c8"), gloves=rgb("e8e4d8"),
                            hair=rgb("c8c0b0"), cuff=rgb("e8e4d8"))
    out["rifleman"] = dict(base, shirt=rgb("8a8a5a"), pattern="uniform", sleeve_rows=12, pants=rgb("77774f"), boots=rgb("3a2a1a"),
                           hat="visor", hat_color=rgb("7a7a50"), hat_trim=rgb("3a3a28"), gloves=rgb("4a3a2a"),
                           mustache=rgb("4a3322"))
    out["gunner"] = dict(base, shirt=rgb("5b6b3a"), pattern="camo", sleeve_rows=12, pants=rgb("4f5f33"), boots=rgb("1d1d1d"),
                         hat="helmet", hat_color=rgb("4a5a2e"), hat_trim=rgb("2a3418"), gloves=rgb("1f1f1f"), pants_stripe=None,
                         hair=rgb("2a1d12"), over="tabard", over_color=rgb("3a4528"), over_trim=rgb("2a3418"))
    return out


def bandit_specs():
    skin = SKIN_TONES[0]
    base = dict(skin=skin, hair=rgb("2a1d12"), hair_style="messy", eye=rgb("2d2420"))
    out = {}
    out["thug"] = dict(base, shirt=rgb("5a4033"), pattern="rags", sleeve_rows=5, pants=rgb("3b3128"), boots=rgb("1f1a16"),
                       mask=rgb("b3202a"), hat="cap", hat_color=rgb("3a2a22"), hat_trim=rgb("241a14"), scar=True,
                       gloves=rgb("2a211a"), over="cape", over_color=rgb("2e2420"), cuff=rgb("3a2a22"))
    out["archer"] = dict(base, shirt=rgb("45503a"), pattern="leather", sleeve_rows=12, pants=rgb("3a3a30"), boots=rgb("2a2218"),
                         hat="hood", hat_color=rgb("3c4631"), mask=rgb("2a2a24"), gloves=rgb("3a2a1a"),
                         over="cape", over_color=rgb("3c4631"))
    out["gunman"] = dict(base, shirt=rgb("222226"), pattern="longcoat", sleeve_rows=12, pants=rgb("1b1b1f"), boots=rgb("0f0f0f"),
                         hat="wide", hat_color=rgb("2a2623"), hat_trim=rgb("6a5a3a"), mask=rgb("7a2a2a"),
                         over="coattails", over_color=rgb("222226"), gloves=rgb("151515"), mustache=None)
    return out


def generate(preview_dir=None):
    outs = []
    dolls_c, dolls_s = [], []
    for name, spec in citizen_specs().items():
        img = make_skin(spec, "citizen/" + name)
        save(img, os.path.join(TEX, "entity", "citizen", name + ".png"))
        dolls_c.append(doll(img))
    for name, spec in soldier_specs().items():
        img = make_skin(spec, "soldier/" + name)
        save(img, os.path.join(TEX, "entity", "soldier", name + ".png"))
        dolls_s.append(doll(img))
    for name, spec in bandit_specs().items():
        img = make_skin(spec, "bandit/" + name)
        save(img, os.path.join(TEX, "entity", "bandit", name + ".png"))
        dolls_s.append(doll(img))
    if preview_dir:
        sheet(dolls_c, 5, 6, os.path.join(preview_dir, "citizens.png"))
        sheet(dolls_s, 5, 5, os.path.join(preview_dir, "soldiers.png"))
    return dolls_c, dolls_s


if __name__ == "__main__":
    import sys
    generate(sys.argv[1] if len(sys.argv) > 1 else None)
