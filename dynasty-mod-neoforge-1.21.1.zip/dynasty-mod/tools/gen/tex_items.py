# -*- coding: utf-8 -*-
"""16x16 item icons."""
import os

from pix import *  # noqa: F401,F403

OUT = (28, 20, 16, 255)

GOLD = rgb("f0c43c")
GOLD_L = rgb("fff0a0")
GOLD_D = rgb("a8771a")
STEEL = rgb("a5aab2")
STEEL_L = rgb("d6dae0")
STEEL_D = rgb("5f646c")
DARK = rgb("33363c")
WOOD = rgb("9a6a36")
WOOD_L = rgb("c28d4e")
WOOD_D = rgb("63401f")
RED = rgb("c23a2e")
RED_D = rgb("86261d")
BRASS = rgb("d9a441")
BRASS_D = rgb("96691f")
COPPER = rgb("c8622e")
OLIVE = rgb("5b6b3a")
OLIVE_D = rgb("3e4a26")
OLIVE_L = rgb("7f9250")


def coin():
    i = new(16)
    disc(i, 8, 8, 6.4, GOLD_D)
    disc(i, 8, 8, 5.5, GOLD)
    ring(i, 8, 8, 4.4, 3.5, rgb("d9a822"))
    for p in [(6, 6), (6, 7), (7, 7), (8, 6), (9, 7), (10, 7), (10, 6), (6, 8), (7, 8), (8, 8), (9, 8), (10, 8), (6, 9), (7, 9), (8, 9), (9, 9), (10, 9)]:
        put(i, p[0], p[1], GOLD_D)
    for p in [(5, 4), (6, 3), (4, 5)]:
        put(i, p[0], p[1], GOLD_L)
    outline(i, OUT)
    return i


def ring_item():
    i = new(16)
    ring(i, 8, 10, 4.9, 2.7, GOLD)
    ring(i, 8, 10, 4.9, 4.0, GOLD_D)
    for p in [(5, 8), (6, 7)]:
        put(i, p[0], p[1], GOLD_L)
    for p, c in [((8, 3), rgb("ff8aa0")), ((7, 4), rgb("e0314b")), ((8, 4), rgb("ff5a73")), ((9, 4), rgb("b3173a")),
                 ((8, 5), rgb("b3173a")), ((7, 5), GOLD), ((9, 5), GOLD), ((6, 4), GOLD), ((10, 4), GOLD)]:
        put(i, p[0], p[1], c)
    outline(i, OUT)
    return i


def fuel_canister():
    i = new(16)
    rect(i, 3, 5, 13, 15, RED)
    rect(i, 3, 5, 13, 6, rgb("e5584a"))
    rect(i, 3, 5, 4, 15, rgb("e5584a"))
    rect(i, 12, 5, 13, 15, RED_D)
    rect(i, 3, 14, 13, 15, RED_D)
    # handle
    rect(i, 4, 2, 8, 5, RED_D)
    rect(i, 5, 3, 7, 5, (0, 0, 0, 0))
    # spout
    rect(i, 9, 2, 12, 5, STEEL_D)
    rect(i, 9, 2, 12, 3, GOLD)
    # ribs and drop label
    hline(i, 4, 12, 9, RED_D)
    hline(i, 4, 12, 13, RED_D)
    for p in [(8, 9), (7, 10), (8, 10), (9, 10), (7, 11), (8, 11), (9, 11), (8, 12)]:
        put(i, p[0], p[1], rgb("f6d24a"))
    outline(i, OUT)
    return i


def royal_scroll():
    i = new(16)
    rect(i, 3, 4, 13, 12, rgb("f2e4b8"))
    rect(i, 3, 4, 13, 5, rgb("d9c58f"))
    rect(i, 3, 11, 13, 12, rgb("d9c58f"))
    for x, y in [(3, 3), (4, 3), (11, 3), (12, 3), (3, 12), (4, 12), (11, 12), (12, 12)]:
        put(i, x, y, rgb("b08d4a"))
    rect(i, 2, 3, 14, 4, rgb("b08d4a"))
    rect(i, 2, 12, 14, 13, rgb("b08d4a"))
    for y in (6, 8):
        hline(i, 5, 11, y, rgb("a38a55"))
    vline(i, 7, 12, 15, rgb("2c5fb3"))
    vline(i, 9, 12, 14, rgb("2c5fb3"))
    disc(i, 8, 9.5, 2.0, rgb("b3202a"))
    put(i, 8, 9, rgb("e0525c")); put(i, 7, 9, rgb("e0525c"))
    outline(i, OUT)
    return i


def command_banner():
    i = new(16)
    vline(i, 2, 1, 16, WOOD)
    vline(i, 1, 2, 16, WOOD_D)
    poly(i, [(2, 0), (3, 0), (3, 1), (2, 2)], STEEL)
    put(i, 2, 0, STEEL_L)
    rect(i, 3, 2, 14, 10, RED)
    rect(i, 3, 2, 14, 3, GOLD)
    rect(i, 3, 9, 14, 10, GOLD)
    put(i, 13, 5, (0, 0, 0, 0)); put(i, 13, 6, (0, 0, 0, 0)); put(i, 12, 6, (0, 0, 0, 0))
    for p in [(8, 4), (7, 5), (8, 5), (9, 5), (6, 6), (7, 6), (8, 6), (9, 6), (10, 6), (7, 7), (9, 7)]:
        put(i, p[0], p[1], GOLD)
    outline(i, OUT)
    return i


def musket_ball():
    i = new(16)
    for cx, cy in [(5, 10), (11, 10), (8, 5)]:
        disc(i, cx, cy, 3.1, rgb("4b4f57"))
        disc(i, cx - 0.3, cy - 0.3, 2.3, rgb("6a6f78"))
        put(i, int(cx - 1), int(cy - 1), rgb("c9ced6"))
        put(i, int(cx - 1), int(cy - 2) + 1, rgb("a9aeb6"))
    outline(i, OUT)
    return i


def cartridge():
    i = new(16)
    for x0, top in [(3, 4), (9, 6)]:
        rect(i, x0, top + 4, x0 + 4, 14, BRASS)
        rect(i, x0, top + 4, x0 + 1, 14, rgb("f1cf7a"))
        rect(i, x0 + 3, top + 4, x0 + 4, 14, BRASS_D)
        rect(i, x0 - 1, 13, x0 + 5, 15, BRASS_D)
        rect(i, x0, top, x0 + 4, top + 4, COPPER)
        put(i, x0, top, (0, 0, 0, 0)); put(i, x0 + 3, top, (0, 0, 0, 0))
        put(i, x0 + 1, top + 1, rgb("e8956a"))
    outline(i, OUT)
    return i


def _diag_tube(i, p0, p1, w, c, hi=None, lo=None):
    line(i, p0, p1, c, w)
    if hi is not None:
        line(i, (p0[0] - 1, p0[1] - 1), (p1[0] - 1, p1[1] - 1), hi, 1)


def rocket():
    i = new(16)
    line(i, (3, 12), (11, 4), rgb("c6cad1"), 3)
    line(i, (2, 11), (10, 3), rgb("eef0f3"), 1)
    line(i, (4, 13), (12, 5), rgb("858a92"), 1)
    # nose cone
    poly(i, [(10, 2), (14, 1), (13, 5), (11, 6)], RED)
    put(i, 13, 2, rgb("ff6f5f"))
    # fins
    poly(i, [(1, 9), (4, 9), (4, 12)], rgb("a33a30"))
    poly(i, [(7, 14), (7, 11), (4, 11)], rgb("a33a30"))
    put(i, 2, 13, rgb("ffb13a")); put(i, 1, 14, rgb("ff7a1f")); put(i, 3, 14, rgb("ffd23a"))
    outline(i, OUT)
    return i


def shell():
    i = new(16)
    line(i, (3, 12), (9, 6), BRASS, 4)
    line(i, (2, 11), (8, 5), rgb("f1cf7a"), 1)
    line(i, (5, 13), (10, 8), BRASS_D, 1)
    poly(i, [(8, 4), (13, 2), (12, 7), (9, 8)], rgb("767b83"))
    poly(i, [(9, 5), (12, 3), (12, 5)], rgb("a2a7af"))
    line(i, (4, 13), (2, 11), BRASS_D, 2)
    put(i, 7, 7, RED_D); put(i, 6, 8, RED_D)
    outline(i, OUT)
    return i


def grenade():
    i = new(16)
    disc(i, 7.5, 10, 5.0, OLIVE_D)
    disc(i, 7.2, 9.6, 4.2, OLIVE)
    for p in [(5, 7), (6, 6)]:
        put(i, p[0], p[1], OLIVE_L)
    for y in (8, 11):
        hline(i, 4, 12, y, OLIVE_D)
    for x in (5, 8, 10):
        vline(i, x, 6, 14, OLIVE_D)
    rect(i, 6, 3, 10, 6, rgb("666b72"))
    rect(i, 6, 3, 10, 4, rgb("8d939b"))
    poly(i, [(9, 3), (13, 3), (13, 4), (11, 7), (10, 6)], STEEL)
    ring(i, 13, 5, 1.6, 0.9, GOLD)
    outline(i, OUT)
    return i


def _handle(i, p0, p1, w=2):
    line(i, p0, p1, WOOD, w)


def flintlock_pistol():
    i = new(16)
    line(i, (6, 9), (14, 2), STEEL, 2)
    line(i, (5, 8), (13, 1), STEEL_L, 1)
    line(i, (14, 2), (14, 2), STEEL_D, 2)
    # lock plate and grip
    poly(i, [(4, 8), (8, 8), (8, 11), (5, 11)], rgb("7e8289"))
    line(i, (6, 10), (2, 14), WOOD, 3)
    line(i, (5, 10), (1, 13), WOOD_L, 1)
    put(i, 3, 14, WOOD_D); put(i, 2, 15, WOOD_D)
    # hammer / frizzen
    poly(i, [(4, 6), (6, 6), (6, 8), (5, 8)], STEEL_D)
    put(i, 4, 5, STEEL_L)
    put(i, 7, 12, BRASS)
    outline(i, OUT)
    return i


def musket():
    i = new(16)
    line(i, (1, 14), (8, 9), WOOD, 3)
    line(i, (0, 13), (7, 8), WOOD_L, 1)
    line(i, (6, 10), (14, 2), STEEL, 2)
    line(i, (5, 9), (13, 1), STEEL_L, 1)
    for p in [(8, 8), (11, 5)]:
        rect(i, p[0], p[1], p[0] + 2, p[1] + 2, BRASS)
    poly(i, [(5, 7), (7, 7), (7, 9), (6, 10)], STEEL_D)
    put(i, 14, 2, STEEL_D)
    put(i, 2, 15, WOOD_D)
    outline(i, OUT)
    return i


def rifle():
    i = new(16)
    line(i, (1, 14), (7, 9), WOOD, 3)
    line(i, (0, 13), (6, 8), WOOD_L, 1)
    line(i, (6, 10), (14, 2), DARK, 2)
    line(i, (5, 9), (13, 1), rgb("6d727a"), 1)
    # scope
    line(i, (6, 6), (10, 2), rgb("23262b"), 2)
    put(i, 6, 6, STEEL_L); put(i, 10, 2, rgb("6fb4e8"))
    rect(i, 7, 9, 9, 11, STEEL_D)
    put(i, 4, 11, DARK); put(i, 4, 12, DARK)
    outline(i, OUT)
    return i


def smg():
    i = new(16)
    line(i, (2, 13), (5, 10), STEEL_D, 2)
    line(i, (5, 10), (11, 4), DARK, 4)
    line(i, (4, 9), (10, 3), rgb("6d727a"), 1)
    line(i, (11, 4), (14, 1), STEEL_D, 2)
    # magazine and grip
    line(i, (8, 9), (6, 14), rgb("2a2c31"), 2)
    line(i, (4, 11), (3, 14), WOOD_D, 2)
    put(i, 9, 6, STEEL_L); put(i, 8, 7, STEEL_L)
    put(i, 13, 1, rgb("ffd23a"))
    outline(i, OUT)
    return i


def bazooka():
    i = new(16)
    line(i, (3, 13), (12, 4), OLIVE, 4)
    line(i, (2, 12), (11, 3), OLIVE_L, 1)
    line(i, (5, 14), (13, 6), OLIVE_D, 1)
    # flared ends
    line(i, (2, 14), (3, 13), DARK, 3)
    line(i, (12, 4), (14, 2), DARK, 3)
    put(i, 14, 1, RED)
    # sight and grip
    line(i, (7, 6), (9, 4), STEEL, 1)
    put(i, 9, 3, STEEL_L)
    line(i, (7, 11), (6, 14), DARK, 2)
    for p in [(8, 9), (9, 8)]:
        put(i, p[0], p[1], BRASS)
    outline(i, OUT)
    return i


def halberd():
    i = new(16)
    line(i, (1, 15), (11, 5), WOOD, 2)
    line(i, (0, 14), (10, 4), WOOD_L, 1)
    # head: axe blade + spike
    poly(i, [(10, 5), (13, 2), (15, 0), (15, 3), (12, 6)], STEEL)
    poly(i, [(7, 3), (10, 4), (9, 7), (6, 8)], STEEL)
    line(i, (10, 4), (13, 1), STEEL_L, 1)
    put(i, 15, 0, STEEL_L)
    put(i, 8, 5, STEEL_L)
    line(i, (5, 11), (3, 13), BRASS_D, 1)
    outline(i, OUT)
    return i


def _wheel(i, cx, cy, r):
    disc(i, cx, cy, r, rgb("1d1d20"))
    disc(i, cx, cy, r * 0.45, rgb("9a9ea6"))


def cart():
    i = new(16)
    rect(i, 3, 5, 14, 9, WOOD)
    rect(i, 3, 5, 14, 6, WOOD_L)
    rect(i, 3, 8, 14, 9, WOOD_D)
    for x in (5, 8, 11):
        vline(i, x, 5, 9, WOOD_D)
    # hay load
    rect(i, 5, 3, 12, 5, rgb("d8b349"))
    put(i, 6, 3, rgb("f0d36a")); put(i, 9, 3, rgb("f0d36a"))
    # drawbar
    line(i, (0, 11), (3, 9), WOOD_D, 1)
    _wheel(i, 5, 11, 2.6)
    _wheel(i, 12, 11, 2.6)
    outline(i, OUT)
    return i


def jeep():
    i = new(16)
    rect(i, 1, 7, 15, 11, OLIVE)
    rect(i, 1, 7, 15, 8, OLIVE_L)
    rect(i, 1, 10, 15, 11, OLIVE_D)
    # windshield & roll bar
    rect(i, 8, 4, 9, 7, DARK)
    rect(i, 9, 5, 12, 7, rgb("8fc3e3"))
    rect(i, 12, 4, 13, 7, DARK)
    rect(i, 3, 5, 7, 7, OLIVE_D)
    put(i, 14, 8, rgb("ffe27a")); put(i, 14, 9, rgb("ffe27a"))
    _wheel(i, 4, 12, 2.8)
    _wheel(i, 12, 12, 2.8)
    outline(i, OUT)
    return i


def truck():
    i = new(16)
    rect(i, 0, 5, 9, 11, OLIVE)
    rect(i, 0, 5, 9, 6, OLIVE_L)
    rect(i, 9, 6, 15, 11, OLIVE_D)
    rect(i, 10, 7, 14, 9, rgb("8fc3e3"))
    rect(i, 14, 9, 16, 10, STEEL)
    for x in (2, 5):
        vline(i, x, 6, 11, OLIVE_D)
    _wheel(i, 3, 12, 2.6)
    _wheel(i, 7, 12, 2.6)
    _wheel(i, 12, 12, 2.6)
    outline(i, OUT)
    return i


def tank():
    i = new(16)
    rect(i, 1, 9, 15, 13, rgb("2a2c2e"))
    for x in range(2, 15, 2):
        put(i, x, 13, rgb("55585c"))
    for x in (3, 6, 9, 12):
        disc(i, x, 11, 1.4, rgb("7d8187"))
    rect(i, 2, 6, 14, 9, OLIVE)
    rect(i, 2, 6, 14, 7, OLIVE_L)
    rect(i, 5, 3, 11, 6, OLIVE_D)
    rect(i, 5, 3, 11, 4, OLIVE)
    rect(i, 11, 4, 16, 5, DARK)
    put(i, 8, 2, DARK)
    outline(i, OUT)
    return i


def spawn_egg_dummy():
    return None


BUILDERS = [
    ("coin", coin), ("ring", ring_item), ("fuel_canister", fuel_canister), ("royal_scroll", royal_scroll),
    ("command_banner", command_banner), ("musket_ball", musket_ball), ("cartridge", cartridge), ("rocket", rocket),
    ("shell", shell), ("grenade", grenade), ("flintlock_pistol", flintlock_pistol), ("musket", musket),
    ("rifle", rifle), ("smg", smg), ("bazooka", bazooka), ("halberd", halberd),
    ("cart", cart), ("jeep", jeep), ("truck", truck), ("tank", tank),
]


def generate(preview_dir=None):
    imgs = []
    for iid, fn in BUILDERS:
        im = fn()
        save(im, os.path.join(TEX, "item", iid + ".png"))
        imgs.append(im)
    if preview_dir:
        sheet(imgs, 12, 10, os.path.join(preview_dir, "items.png"))
    return imgs


if __name__ == "__main__":
    import sys
    generate(sys.argv[1] if len(sys.argv) > 1 else None)
