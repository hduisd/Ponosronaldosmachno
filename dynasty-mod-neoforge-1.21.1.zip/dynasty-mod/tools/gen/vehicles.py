# -*- coding: utf-8 -*-
"""Vehicle models: box specs -> packed texture sheets + the generated VehicleModels.java + a small software preview.

Coordinates in the specs are "natural": x grows to the vehicle's LEFT, y grows UP (0 = ground), z grows to the FRONT.
All values are whole pixels (16 px = 1 block)."""
import math
import os

from PIL import Image

from pix import *  # noqa: F401,F403


class Box:
    def __init__(self, name, x, y, z, style, color, group="body", axis="x", decals=(), **kw):
        self.name = name
        self.x0, self.x1 = x
        self.y0, self.y1 = y
        self.z0, self.z1 = z
        self.style = style
        self.color = color
        self.group = group
        self.axis = axis
        self.decals = decals
        self.kw = kw
        self.u = self.v = 0
        self.dx = self.x1 - self.x0
        self.dy = self.y1 - self.y0
        self.dz = self.z1 - self.z0
        assert self.dx > 0 and self.dy > 0 and self.dz > 0, name

    @property
    def tex_w(self):
        return 2 * self.dz + 2 * self.dx

    @property
    def tex_h(self):
        return self.dz + self.dy


# --------------------------------------------------------------------------------------------------------------
# palette
# --------------------------------------------------------------------------------------------------------------
WOOD = rgb("9a6e3a")
WOOD_L = rgb("b98d4f")
WOOD_D = rgb("6d4a27")
OLIVE = rgb("5b6b3a")
OLIVE_D = rgb("3e4a26")
OLIVE_L = rgb("76884a")
METAL = rgb("5d6168")
METAL_D = rgb("3b3e44")
GLASS = rgb("8fc3e3")
LIGHT = rgb("ffe27a")
TIRE = rgb("1f1f23")
HUB = rgb("9a9ea6")
LEATHER = rgb("7a4a2a")
STRAW = rgb("d8b349")
STEEL = rgb("494d54")


def wheel(name, x0, x1, y0, y1, z0, z1, axis="x"):
    return Box(name, (x0, x1), (y0, y1), (z0, z1), "tire", TIRE, axis=axis)


def specs():
    out = {}

    # ---------------------------------------------------------------- cart
    b = []
    b.append(Box("bed_floor", (-11, 11), (6, 8), (-16, 16), "planks", WOOD))
    b.append(Box("side_l", (10, 11), (8, 13), (-16, 16), "planks", WOOD_L))
    b.append(Box("side_r", (-11, -10), (8, 13), (-16, 16), "planks", WOOD_L))
    b.append(Box("back", (-10, 10), (8, 13), (-16, -15), "planks", WOOD_L))
    b.append(Box("front", (-10, 10), (8, 11), (15, 16), "planks", WOOD_L))
    b.append(Box("bench", (-9, 9), (8, 10), (3, 8), "planks", WOOD_D))
    b.append(Box("crate", (-8, 8), (8, 10), (-14, -4), "planks", WOOD_D))
    b.append(Box("axle_f", (-12, 12), (5, 7), (8, 10), "planks", WOOD_D))
    b.append(Box("axle_r", (-12, 12), (5, 7), (-10, -8), "planks", WOOD_D))
    b.append(Box("drawbar", (-1, 1), (6, 8), (16, 26), "planks", WOOD_D))
    for nm, x0, x1, z0, z1 in [("w_fl", 11, 14, 3, 15), ("w_fr", -14, -11, 3, 15),
                               ("w_rl", 11, 14, -15, -3), ("w_rr", -14, -11, -15, -3)]:
        b.append(wheel(nm, x0, x1, 0, 12, z0, z1))
    out["cart"] = (b, None)

    # ---------------------------------------------------------------- jeep
    b = []
    b.append(Box("chassis", (-11, 11), (5, 9), (-20, 20), "metal", METAL_D))
    b.append(Box("body_l", (10, 12), (9, 16), (-20, 6), "paint", OLIVE, decals=(("left", "star"),)))
    b.append(Box("body_r", (-12, -10), (9, 16), (-20, 6), "paint", OLIVE, decals=(("right", "star"),)))
    b.append(Box("rear", (-10, 10), (9, 18), (-21, -19), "paint", OLIVE))
    b.append(Box("hood", (-10, 10), (9, 15), (8, 22), "paint", OLIVE_L, decals=(("front", "grille"),)))
    b.append(Box("dash", (-10, 10), (9, 17), (6, 8), "paint", OLIVE_D))
    b.append(Box("cowl_l", (10, 12), (9, 17), (6, 22), "paint", OLIVE))
    b.append(Box("cowl_r", (-12, -10), (9, 17), (6, 22), "paint", OLIVE))
    b.append(Box("windshield", (-10, 10), (17, 23), (7, 8), "glass", GLASS))
    b.append(Box("post_l", (10, 12), (17, 23), (7, 8), "metal", METAL_D))
    b.append(Box("post_r", (-12, -10), (17, 23), (7, 8), "metal", METAL_D))
    b.append(Box("seat_l", (2, 9), (6, 8), (-3, 4), "leather", LEATHER))
    b.append(Box("seat_r", (-9, -2), (6, 8), (-3, 4), "leather", LEATHER))
    b.append(Box("back_l", (2, 9), (8, 15), (-5, -3), "leather", LEATHER))
    b.append(Box("back_r", (-9, -2), (8, 15), (-5, -3), "leather", LEATHER))
    b.append(Box("bumper", (-12, 12), (5, 8), (22, 24), "metal", METAL))
    b.append(Box("light_l", (7, 10), (10, 13), (22, 23), "light", LIGHT))
    b.append(Box("light_r", (-10, -7), (10, 13), (22, 23), "light", LIGHT))
    b.append(Box("spare", (-5, 5), (9, 19), (-24, -21), "tire", TIRE, axis="z"))
    for nm, x0, x1, z0, z1 in [("w_fl", 12, 15, 8, 20), ("w_fr", -15, -12, 8, 20),
                               ("w_rl", 12, 15, -20, -8), ("w_rr", -15, -12, -20, -8)]:
        b.append(wheel(nm, x0, x1, 0, 12, z0, z1))
    out["jeep"] = (b, None)

    # ---------------------------------------------------------------- truck
    b = []
    b.append(Box("chassis", (-11, 11), (6, 11), (-24, 22), "metal", METAL_D))
    b.append(Box("cab_floor", (-13, 13), (11, 12), (2, 22), "metal", METAL))
    b.append(Box("bench", (-12, 12), (12, 14), (8, 17), "leather", LEATHER))
    b.append(Box("cab_back", (-13, 13), (12, 28), (1, 3), "paint", OLIVE))
    b.append(Box("door_l", (12, 13), (12, 22), (3, 19), "paint", OLIVE, decals=(("left", "star"),)))
    b.append(Box("door_r", (-13, -12), (12, 22), (3, 19), "paint", OLIVE, decals=(("right", "star"),)))
    b.append(Box("cowl", (-13, 13), (12, 24), (19, 24), "paint", OLIVE_L, decals=(("front", "grille"),)))
    b.append(Box("windshield", (-12, 12), (24, 31), (19, 20), "glass", GLASS))
    b.append(Box("post_l", (12, 13), (24, 31), (19, 20), "metal", METAL_D))
    b.append(Box("post_r", (-13, -12), (24, 31), (19, 20), "metal", METAL_D))
    b.append(Box("bumper", (-13, 13), (7, 11), (24, 26), "metal", METAL))
    b.append(Box("light_l", (8, 11), (13, 16), (24, 25), "light", LIGHT))
    b.append(Box("light_r", (-11, -8), (13, 16), (24, 25), "light", LIGHT))
    b.append(Box("bed_floor", (-13, 13), (12, 14), (-24, 1), "planks", WOOD))
    b.append(Box("bed_l", (12, 13), (14, 22), (-24, 1), "planks", WOOD_L))
    b.append(Box("bed_r", (-13, -12), (14, 22), (-24, 1), "planks", WOOD_L))
    b.append(Box("tailgate", (-12, 12), (14, 22), (-24, -23), "planks", WOOD_L))
    b.append(Box("fuel_tank", (-15, -13), (7, 12), (-8, 0), "metal", METAL))
    for nm, x0, x1, z0, z1 in [("w_fl", 13, 17, 9, 23), ("w_fr", -17, -13, 9, 23),
                               ("w_rl", 13, 17, -23, -9), ("w_rr", -17, -13, -23, -9)]:
        b.append(wheel(nm, x0, x1, 0, 14, z0, z1))
    out["truck"] = (b, None)

    # ---------------------------------------------------------------- tank
    b = []
    b.append(Box("track_l", (14, 20), (0, 14), (-26, 26), "track", STEEL))
    b.append(Box("track_r", (-20, -14), (0, 14), (-26, 26), "track", STEEL))
    b.append(Box("hull", (-14, 14), (6, 14), (-24, 22), "paint", OLIVE))
    b.append(Box("nose", (-14, 14), (6, 11), (22, 28), "paint", OLIVE_D))
    b.append(Box("engine", (-12, 12), (14, 16), (-24, -10), "grille_top", OLIVE_D))
    b.append(Box("fender_l", (14, 20), (14, 15), (-26, 26), "paint", OLIVE_D))
    b.append(Box("fender_r", (-20, -14), (14, 15), (-26, 26), "paint", OLIVE_D))
    t = []
    t.append(Box("turret_base", (-11, 11), (14, 18), (-11, 11), "paint", OLIVE, group="turret",
                 decals=(("left", "star"), ("right", "star"))))
    t.append(Box("turret_top", (-9, 9), (18, 22), (-9, 9), "paint", OLIVE_L, group="turret", decals=(("top", "hatch"),)))
    t.append(Box("mantlet", (-5, 5), (16, 22), (11, 14), "metal", METAL_D, group="turret"))
    t.append(Box("barrel", (-2, 2), (17, 21), (14, 38), "barrel", METAL, group="turret"))
    t.append(Box("muzzle", (-3, 3), (16, 22), (38, 41), "metal", METAL_D, group="turret"))
    t.append(Box("bustle", (-9, 9), (15, 20), (-15, -11), "paint", OLIVE_D, group="turret"))
    out["tank"] = (b + t, 14)
    return out


# --------------------------------------------------------------------------------------------------------------
# painting of faces
# --------------------------------------------------------------------------------------------------------------

def nz(c, rng, amp=0.04):
    return shade(c, 1.0 + rng.uniform(-amp, amp))


STAR = ["..#..", "#####", ".###.", ".#.#.", "#...#"]


def paint_box(img, box, rng):
    regs = {
        "top": (box.u + box.dz, box.v, box.dx, box.dz),
        "bottom": (box.u + box.dz + box.dx, box.v, box.dx, box.dz),
        "right": (box.u, box.v + box.dz, box.dz, box.dy),
        "front": (box.u + box.dz, box.v + box.dz, box.dx, box.dy),
        "left": (box.u + box.dz + box.dx, box.v + box.dz, box.dz, box.dy),
        "back": (box.u + 2 * box.dz + box.dx, box.v + box.dz, box.dx, box.dy),
    }
    fn = STYLES[box.style]
    for face, (x, y, w, h) in regs.items():
        for j in range(h):
            for i in range(w):
                c = fn(box, face, i, j, w, h, rng)
                if c is None:
                    c = (0, 0, 0, 0)
                img.putpixel((x + i, y + j), c)
        for kind_face, kind in box.decals:
            if kind_face == face:
                DECALS[kind](img, x, y, w, h, box, rng)
    return regs


def st_plain(b, face, i, j, w, h, rng):
    c = nz(b.color, rng)
    if face == "bottom":
        return shade(b.color, 0.6)
    if face in ("front", "back", "left", "right") and h > 2 and j == h - 1:
        c = shade(c, 0.85)
    return c


def st_planks(b, face, i, j, w, h, rng):
    c = nz(b.color, rng, 0.05)
    if face == "bottom":
        return shade(b.color, 0.6)
    if face in ("top",):
        if b.dz >= b.dx:
            if i % 3 == 2:
                c = shade(c, 0.78)
        else:
            if j % 3 == 2:
                c = shade(c, 0.78)
    else:
        if j % 3 == 2:
            c = shade(c, 0.78)
        if (i * 7 + j * 3) % 13 == 0:
            c = shade(c, 0.9)
    return c


def st_metal(b, face, i, j, w, h, rng):
    c = nz(b.color, rng, 0.04)
    if face == "bottom":
        return shade(b.color, 0.6)
    if w >= 6 and h >= 6 and i % 5 == 1 and j % 5 == 1:
        c = shade(c, 1.3)
    if j == 0 and face in ("front", "back", "left", "right"):
        c = shade(c, 1.15)
    if j == h - 1 and face in ("front", "back", "left", "right"):
        c = shade(c, 0.8)
    return c


def st_paint(b, face, i, j, w, h, rng):
    c = nz(b.color, rng, 0.045)
    if face == "bottom":
        return shade(b.color, 0.6)
    # camouflage blotches
    n = ((i * 5 + j * 11 + b.x0 * 3 + b.z0) % 17)
    if n < 2:
        c = shade(c, 0.88)
    # panel borders
    if w >= 8 and h >= 5 and face in ("front", "back", "left", "right", "top"):
        if i in (0, w - 1) or j in (0, h - 1):
            c = shade(c, 0.82)
    return c


def st_glass(b, face, i, j, w, h, rng):
    c = b.color
    if (i + j) % 6 == 0:
        c = shade(c, 1.2)
    if i in (0, w - 1) or j in (0, h - 1):
        c = shade(c, 0.7)
    return c


def st_light(b, face, i, j, w, h, rng):
    c = b.color
    if (i == 0 or j == 0):
        c = shade(c, 1.1)
    return shade(c, 0.9) if face == "bottom" else c


def st_leather(b, face, i, j, w, h, rng):
    c = nz(b.color, rng, 0.05)
    if face == "bottom":
        return shade(b.color, 0.6)
    if (i + j) % 4 == 0:
        c = shade(c, 0.86)
    if i in (0, w - 1) or j in (0, h - 1):
        c = shade(c, 0.78)
    return c


def st_barrel(b, face, i, j, w, h, rng):
    c = nz(b.color, rng, 0.03)
    if face in ("left", "right", "top", "bottom"):
        if i % 6 == 5:
            c = shade(c, 0.7)
    if face == "front" or face == "back":
        c = shade(c, 0.5) if (i in (1, 2) and j in (1, 2)) else c
    return c


def st_grille_top(b, face, i, j, w, h, rng):
    c = nz(b.color, rng, 0.03)
    if face == "top" and j % 2 == 0:
        c = shade(c, 0.55)
    return c


def disc_faces(b):
    return ("left", "right") if b.axis == "x" else ("front", "back")


def st_tire(b, face, i, j, w, h, rng):
    if face in disc_faces(b):
        cx, cy = w / 2.0, h / 2.0
        r = min(w, h) / 2.0
        d = math.hypot(i + 0.5 - cx, j + 0.5 - cy)
        if d > r:
            return None
        if d > r - 2.0:
            return nz(TIRE, rng, 0.12)
        if d > r * 0.42:
            c = HUB
            if abs(d - (r * 0.7)) < 0.6 and ((i + j) % 3 == 0):
                c = shade(HUB, 0.7)
            return nz(c, rng, 0.05)
        return shade(HUB, 0.6) if d > r * 0.18 else rgb("c9ccd2")
    c = nz(TIRE, rng, 0.1)
    if (i + j) % 3 == 0:
        c = shade(c, 1.35)
    return c


def st_track(b, face, i, j, w, h, rng):
    if face in ("left", "right"):
        # rounded ends
        rad = 4
        for (cx, cy) in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
            if abs(i - cx) < rad and abs(j - cy) < rad:
                ox = rad if cx == 0 else w - 1 - rad
                oy = rad if cy == 0 else h - 1 - rad
                if math.hypot(i - ox, j - oy) > rad:
                    if (i < rad or i > w - 1 - rad) and (j < rad or j > h - 1 - rad):
                        return None
        base = nz(shade(b.color, 0.75), rng, 0.05)
        if i % 3 == 0:
            base = shade(b.color, 1.2)
        # road wheels
        for wx in range(5, w - 4, 7):
            d = math.hypot(i + 0.5 - (wx + 0.5), j + 0.5 - h / 2.0)
            if d < 3.4:
                base = rgb("707479") if d > 1.2 else rgb("3a3c40")
        if j <= 1 or j >= h - 2:
            base = nz(shade(b.color, 0.6), rng, 0.04) if (i % 3) else shade(b.color, 1.1)
        return base
    c = nz(shade(b.color, 0.8), rng, 0.04)
    if face in ("top", "bottom"):
        if (j % 3) == 0:
            c = shade(b.color, 1.25)
    return c


def st_dummy(b, face, i, j, w, h, rng):
    return nz(b.color, rng)


STYLES = {
    "plain": st_plain, "planks": st_planks, "metal": st_metal, "paint": st_paint, "glass": st_glass,
    "light": st_light, "leather": st_leather, "barrel": st_barrel, "grille_top": st_grille_top, "tire": st_tire,
    "track": st_track,
}


def dc_star(img, x, y, w, h, box, rng):
    if w < 7 or h < 7:
        return
    ox = x + (w - 5) // 2
    oy = y + (h - 5) // 2
    for jj, row in enumerate(STAR):
        for ii, ch in enumerate(row):
            if ch == "#":
                img.putpixel((ox + ii, oy + jj), rgb("e9e5d2"))


def dc_grille(img, x, y, w, h, box, rng):
    for i in range(1, w - 1):
        if i % 2 == 1:
            for j in range(2, h - 1):
                img.putpixel((x + i, y + j), rgb("26282c"))
    for i in range(w):
        img.putpixel((x + i, y + 1), rgb("3b3e44"))


def dc_hatch(img, x, y, w, h, box, rng):
    cx, cy = w / 2.0, h / 2.0
    for j in range(h):
        for i in range(w):
            d = math.hypot(i + 0.5 - cx, j + 0.5 - cy)
            if 3.0 < d <= 4.2:
                img.putpixel((x + i, y + j), rgb("2a3018"))
            elif d <= 3.0:
                img.putpixel((x + i, y + j), nz(rgb("4a5830"), rng, 0.05))


DECALS = {"star": dc_star, "grille": dc_grille, "hatch": dc_hatch}


# --------------------------------------------------------------------------------------------------------------
# texture packing
# --------------------------------------------------------------------------------------------------------------

def pack(boxes):
    best = None
    for width in (64, 96, 128, 160, 192, 256):
        if width < max(b.tex_w for b in boxes):
            continue
        order = sorted(boxes, key=lambda b: (-b.tex_h, -b.tex_w))
        x = y = shelf_h = 0
        pos = {}
        for b in order:
            if x + b.tex_w > width:
                y += shelf_h
                x = 0
                shelf_h = 0
            pos[id(b)] = (x, y)
            x += b.tex_w
            shelf_h = max(shelf_h, b.tex_h)
        height = y + shelf_h
        height = (height + 7) // 8 * 8
        area = width * height
        if best is None or area < best[0]:
            best = (area, width, height, pos)
    _, width, height, pos = best
    for b in boxes:
        b.u, b.v = pos[id(b)]
    return width, height


def build_texture(boxes, name):
    width, height = pack(boxes)
    img = new(width, height)
    rng = rng_for("vehicle/" + name)
    for b in boxes:
        paint_box(img, b, rng)
    return img, width, height


# --------------------------------------------------------------------------------------------------------------
# java output
# --------------------------------------------------------------------------------------------------------------

def f(v):
    return "%.1fF" % v


def java_for(name, boxes, pivot, width, height):
    lines = []
    lines.append("    private static LayerDefinition %s() {" % name)
    lines.append("        MeshDefinition mesh = new MeshDefinition();")
    lines.append("        PartDefinition root = mesh.getRoot();")
    for group in ("body", "turret"):
        gb = [b for b in boxes if b.group == group]
        if not gb:
            continue
        lines.append("        root.addOrReplaceChild(\"%s\", CubeListBuilder.create()" % group)
        py = pivot if group == "turret" else 0
        for b in gb:
            lines.append("                .texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s)" % (
                b.u, b.v, f(b.x0), f(-(b.y1 - py)), f(-b.z1), f(b.dx), f(b.dy), f(b.dz)))
        off = 24.0 - (pivot if group == "turret" else 0)
        lines.append("                , PartPose.offset(0.0F, %s, 0.0F));" % f(off))
    lines.append("        return LayerDefinition.create(mesh, %d, %d);" % (width, height))
    lines.append("    }")
    return "\n".join(lines)


JAVA_HEAD = '''package com.dynasty.client;

import com.dynasty.Dynasty;
import com.dynasty.entity.VehicleKind;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Cube models of the vehicles. GENERATED by tools/generate_assets.py together with the textures - edit the
 * vehicle specs in tools/gen/vehicles.py and run the script again instead of changing this file by hand.
 * Model space: x = towards the vehicle's left, y = down (the root is lowered by 24), -z = front.
 */
public final class VehicleModels {
    private VehicleModels() {}

    public static ModelLayerLocation layer(VehicleKind kind) {
        return new ModelLayerLocation(Dynasty.id(kind.id), "main");
    }

    public static LayerDefinition create(VehicleKind kind) {
        switch (kind) {
            case CART:
                return cart();
            case JEEP:
                return jeep();
            case TRUCK:
                return truck();
            default:
                return tank();
        }
    }

'''


# --------------------------------------------------------------------------------------------------------------
# preview renderer (orthographic, z-buffered)
# --------------------------------------------------------------------------------------------------------------

def faces_of(b, pivot_dy=0):
    """Yield (name, origin, u_vec, v_vec, normal) in natural coordinates (x left+, y up, z front+)."""
    x0, x1, y0, y1, z0, z1 = b.x0, b.x1, b.y0, b.y1, b.z0, b.z1
    return [
        # front (z1): u along +x, v down (-y)
        ("front", (x0, y1, z1), (1, 0, 0), (0, -1, 0), (0, 0, 1), b.dx, b.dy),
        # back (z0): u along -x
        ("back", (x1, y1, z0), (-1, 0, 0), (0, -1, 0), (0, 0, -1), b.dx, b.dy),
        # left (+x side): u along -z (front -> back)
        ("left", (x1, y1, z1), (0, 0, -1), (0, -1, 0), (1, 0, 0), b.dz, b.dy),
        # right (-x side): u along +z (back -> front)
        ("right", (x0, y1, z0), (0, 0, 1), (0, -1, 0), (-1, 0, 0), b.dz, b.dy),
        # top: u along +x, v from back to front (+z)
        ("top", (x0, y1, z0), (1, 0, 0), (0, 0, 1), (0, 1, 0), b.dx, b.dz),
    ]


def render_preview(boxes, img, pivot, yaw_deg, pitch_deg, turret_deg=0.0, size=220, scale=3.0):
    yaw = math.radians(yaw_deg)
    pitch = math.radians(pitch_deg)
    out = Image.new("RGBA", (size, size), (84, 96, 110, 255))
    zbuf = [[-1e9] * size for _ in range(size)]
    cy_, sy_ = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)

    def tr(p, in_turret):
        x, y, z = p
        if in_turret:
            ty = y - pivot
            a = math.radians(turret_deg)
            xr = x * math.cos(a) + z * math.sin(a)
            zr = -x * math.sin(a) + z * math.cos(a)
            x, z, y = xr, zr, ty + pivot
        # rotate around vertical axis
        xr = x * cy_ + z * sy_
        zr = -x * sy_ + z * cy_
        # tilt
        yr = y * cp - zr * sp
        zr2 = y * sp + zr * cp
        return xr, yr, zr2

    def project(q):
        return size / 2 + q[0] * scale, size * 0.78 - q[1] * scale

    for b in boxes:
        in_turret = b.group == "turret"
        for (fname, o, uv, vv, nrm, fw, fh) in faces_of(b):
            if fname == "front":
                tx, ty = b.u + b.dz, b.v + b.dz
            elif fname == "back":
                tx, ty = b.u + 2 * b.dz + b.dx, b.v + b.dz
            elif fname == "left":
                tx, ty = b.u + b.dz + b.dx, b.v + b.dz
            elif fname == "right":
                tx, ty = b.u, b.v + b.dz
            else:
                tx, ty = b.u + b.dz, b.v
            # corners
            pts = []
            for (s, t) in ((0, 0), (1, 0), (1, 1), (0, 1)):
                p = (o[0] + uv[0] * s * fw + vv[0] * t * fh,
                     o[1] + uv[1] * s * fw + vv[1] * t * fh,
                     o[2] + uv[2] * s * fw + vv[2] * t * fh)
                pts.append(tr(p, in_turret))
            nrm_t = tr(nrm, in_turret)
            o_t = tr((0, 0, 0), in_turret)
            nv = (nrm_t[0] - o_t[0], nrm_t[1] - o_t[1], nrm_t[2] - o_t[2])
            # shading by world normal (light from above-front-left)
            lum = 0.62 + 0.38 * max(0.0, (nv[1] * 0.8 + nv[0] * -0.35 + nv[2] * 0.3))
            xs = [project(p)[0] for p in pts]
            ys = [project(p)[1] for p in pts]
            minx, maxx = int(max(0, math.floor(min(xs)))), int(min(size - 1, math.ceil(max(xs))))
            miny, maxy = int(max(0, math.floor(min(ys)))), int(min(size - 1, math.ceil(max(ys))))
            p0 = project(pts[0])
            pu = project(pts[1])
            pv = project(pts[3])
            ax, ay = pu[0] - p0[0], pu[1] - p0[1]
            bx, by = pv[0] - p0[0], pv[1] - p0[1]
            det = ax * by - ay * bx
            if abs(det) < 1e-6:
                continue
            for py in range(miny, maxy + 1):
                for px in range(minx, maxx + 1):
                    dx_, dy_ = px + 0.5 - p0[0], py + 0.5 - p0[1]
                    s = (dx_ * by - dy_ * bx) / det
                    t = (ax * dy_ - ay * dx_) / det
                    if 0 <= s < 1 and 0 <= t < 1:
                        depth = pts[0][2] + (pts[1][2] - pts[0][2]) * s + (pts[3][2] - pts[0][2]) * t
                        if depth <= zbuf[py][px]:
                            continue
                        iu = min(int(s * fw), fw - 1)
                        iv = min(int(t * fh), fh - 1)
                        col = img.getpixel((tx + iu, ty + iv))
                        if col[3] < 26:
                            continue
                        zbuf[py][px] = depth
                        out.putpixel((px, py), (int(col[0] * lum), int(col[1] * lum), int(col[2] * lum), 255))
    return out


def generate(preview_dir=None):
    java = [JAVA_HEAD]
    previews = []
    for name, (boxes, pivot) in specs().items():
        img, w, h = build_texture(boxes, name)
        save(img, os.path.join(TEX, "entity", "vehicle", name + ".png"))
        java.append(java_for(name, boxes, pivot, w, h))
        java.append("")
        if preview_dir:
            for yaw, pitch in ((35, 28), (215, 28), (90, 20)):
                previews.append(render_preview(boxes, img, pivot or 0, yaw, pitch, turret_deg=25 if pivot else 0))
    java.append("}")
    path = os.path.normpath(os.path.join(RESOURCES, "..", "java", "com", "dynasty", "client", "VehicleModels.java"))
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(java).replace("\n\n}", "\n}") + "\n")
    if preview_dir:
        sheet(previews, 2, 3, os.path.join(preview_dir, "vehicles.png"))
    return path


if __name__ == "__main__":
    import sys
    print(generate(sys.argv[1] if len(sys.argv) > 1 else None))
