# -*- coding: utf-8 -*-
"""16x16 textures of the twelve building blocks (side + top)."""
import os

from pix import *  # noqa: F401,F403

C = {
    "wood_l": rgb("b98d4f"), "wood_m": rgb("9a6e3a"), "wood_d": rgb("6d4a27"), "wood_x": rgb("46301a"),
    "stone_l": rgb("b4b4ae"), "stone_m": rgb("8f8f8a"), "stone_d": rgb("6a6a67"), "mortar": rgb("585855"),
    "red": rgb("a8362c"), "red_d": rgb("7a241d"), "gold": rgb("e6b93c"), "gold_d": rgb("a77b14"),
    "glass": rgb("7fb4d6"), "glass_d": rgb("4c7fa6"), "white": rgb("ece7da"),
    "blue": rgb("31509a"), "blue_d": rgb("1f3669"), "green": rgb("4c8a3a"), "green_d": rgb("2f5c24"),
    "straw": rgb("d8b349"), "straw_d": rgb("a98622"), "soil": rgb("5b3d24"), "soil_d": rgb("43291a"),
    "metal_l": rgb("a9adb2"), "metal_m": rgb("7d8187"), "metal_d": rgb("55585d"), "copper": rgb("c27a35"),
}


def fill(img, c):
    rect(img, 0, 0, img.width, img.height, c)


def bricks(img, x0, y0, x1, y1, base, mortar, rng, bw=8, bh=4, var=0.09):
    rows = (y1 - y0 + bh - 1) // bh
    for r in range(rows):
        yy = y0 + r * bh
        off = (bw // 2) if r % 2 else 0
        xs = list(range(x0 - off, x1, bw))
        for x in xs:
            f = 1.0 + rng.uniform(-var, var)
            col = shade(base, f)
            rect(img, max(x0, x), yy, min(x1, x + bw), min(y1, yy + bh), col)
            vline(img, x, max(yy, y0), min(y1, yy + bh), mortar) if x >= x0 else None
        hline(img, x0, x1, yy, mortar)
    for y in range(y0, y1):
        for x in range(x0, x1):
            p = img.getpixel((x, y))
            if p != mortar and rng.random() < 0.15:
                img.putpixel((x, y), shade(p, 1.0 + rng.uniform(-0.05, 0.05)))


def planks(img, x0, y0, x1, y1, base, line_c, rng, ph=4):
    for r, yy in enumerate(range(y0, y1, ph)):
        col = shade(base, 1.0 + rng.uniform(-0.07, 0.07))
        rect(img, x0, yy, x1, min(y1, yy + ph), col)
        hline(img, x0, x1, yy + ph - 1, line_c) if yy + ph - 1 < y1 else None
        # staggered nails / joints
        jx = x0 + (5 if r % 2 else 11)
        vline(img, jx, yy, min(y1, yy + ph - 1), shade(col, 0.78))
    for y in range(y0, y1):
        for x in range(x0, x1):
            if rng.random() < 0.18:
                p = img.getpixel((x, y))
                img.putpixel((x, y), shade(p, 1.0 + rng.uniform(-0.06, 0.06)))


def shingles(img, base, edge, rng, rowh=3, w=4):
    for r, yy in enumerate(range(0, 16, rowh)):
        off = (w // 2) if r % 2 else 0
        for x in range(-off, 16, w):
            col = shade(base, 1.0 + rng.uniform(-0.1, 0.1))
            rect(img, max(0, x), yy, min(16, x + w), min(16, yy + rowh), col)
            vline(img, x, yy, min(16, yy + rowh), edge) if x >= 0 else None
        hline(img, 0, 16, min(15, yy + rowh - 1), edge)


def window(img, x0, y0, x1, y1, glass, frame_c, cross=True):
    rect(img, x0, y0, x1, y1, glass)
    frame(img, x0 - 1, y0 - 1, x1 + 1, y1 + 1, frame_c)
    if cross:
        mx = (x0 + x1) // 2
        my = (y0 + y1) // 2
        vline(img, mx, y0, y1, frame_c)
        hline(img, x0, x1, my, frame_c)
    put(img, x0, y0, shade(glass, 1.25))


def door(img, x0, y0, x1, y1, c, dark, knob=True, arch=True):
    rect(img, x0, y0, x1, y1, c)
    for x in range(x0, x1, 2):
        vline(img, x, y0, y1, shade(c, 0.88))
    frame(img, x0 - 1, y0 - 1, x1 + 1, y1, dark)
    if arch:
        put(img, x0, y0, dark)
        put(img, x1 - 1, y0, dark)
    if knob:
        put(img, x1 - 2, (y0 + y1) // 2 + 1, C["gold"])


def town_hall():
    rng = rng_for("town_hall")
    s = new(16, fill=C["stone_l"])
    bricks(s, 0, 0, 16, 16, C["stone_l"], C["mortar"], rng)
    rect(s, 0, 0, 16, 2, C["gold"])
    hline(s, 0, 16, 2, C["gold_d"])
    for x in range(0, 16, 4):
        put(s, x, 0, shade(C["gold"], 1.2))
    window(s, 2, 6, 4, 9, C["blue_d"], C["stone_d"])
    window(s, 11, 6, 13, 9, C["blue_d"], C["stone_d"])
    door(s, 6, 9, 10, 16, C["wood_m"], C["stone_d"])
    rect(s, 7, 4, 9, 7, C["red"])
    put(s, 7, 7, C["red"])
    put(s, 8, 5, C["gold"])
    t = new(16)
    shingles(t, C["red"], C["red_d"], rng, rowh=3, w=4)
    frame(t, 0, 0, 16, 16, C["gold_d"])
    for p in [(7, 6), (8, 6), (6, 7), (7, 7), (8, 7), (9, 7), (7, 8), (8, 8)]:
        put(t, p[0], p[1], C["gold"])
    return s, t


def house():
    rng = rng_for("house")
    s = new(16)
    planks(s, 0, 0, 16, 16, C["wood_l"], C["wood_d"], rng)
    rect(s, 0, 0, 16, 1, C["wood_d"])
    window(s, 2, 4, 6, 8, C["glass"], C["wood_x"])
    window(s, 10, 4, 14, 8, C["glass"], C["wood_x"])
    door(s, 6, 9, 10, 16, C["wood_d"], C["wood_x"])
    rect(s, 2, 9, 6, 10, C["wood_m"])
    put(s, 3, 9, C["red"]); put(s, 5, 9, rgb("e8c13b"))
    t = new(16)
    shingles(t, rgb("8b5a3c"), rgb("5a3823"), rng, rowh=4, w=4)
    hline(t, 0, 16, 7, rgb("3f2616")); hline(t, 0, 16, 8, rgb("3f2616"))
    return s, t


def farm():
    rng = rng_for("farm")
    s = new(16)
    for y in range(16):
        for x in range(16):
            put(s, x, y, shade(C["straw"], 1.0 + 0.08 * ((y % 3) - 1) + rng.uniform(-0.05, 0.05)))
    for y in range(0, 16, 3):
        for x in range(16):
            if (x + y) % 5 == 0:
                put(s, x, y, C["straw_d"])
    for x in (3, 12):
        rect(s, x, 0, x + 1, 13, C["wood_d"])
        put(s, x, 4, C["wood_x"]); put(s, x, 9, C["wood_x"])
    rect(s, 0, 13, 16, 16, C["green"])
    for x in range(0, 16, 2):
        put(s, x, 13, C["green_d"])
        put(s, x + 1, 14, C["green_d"])
    for x in (1, 7, 14):
        put(s, x, 12, C["straw_d"])
    t = new(16)
    for y in range(16):
        base = C["soil"] if (y // 2) % 2 == 0 else C["soil_d"]
        for x in range(16):
            put(t, x, y, shade(base, 1.0 + rng.uniform(-0.08, 0.08)))
    for y in (1, 5, 9, 13):
        for x in range(1, 16, 3):
            put(t, x, y, C["green"])
            put(t, x, y - 1, rgb("7bb85a"))
    return s, t


def lumber_camp():
    rng = rng_for("lumber")
    s = new(16, fill=C["wood_x"])
    for cy in (0, 8):
        for cx in (0, 8):
            ring(s, cx + 4, cy + 4, 4.2, 0, rgb("6b4a2a"))
            disc(s, cx + 4, cy + 4, 4.0, rgb("5a3e22"))
            disc(s, cx + 4, cy + 4, 3.3, rgb("c99a5b"))
            ring(s, cx + 4, cy + 4, 2.4, 1.6, rgb("a67a42"))
            put(s, cx + 3, cy + 3, rgb("8a6030")); put(s, cx + 4, cy + 4, rgb("8a6030"))
    t = new(16)
    for r in range(4):
        base = shade(rgb("6e4b2a"), 1.0 + (r % 2) * 0.1)
        rect(t, 0, r * 4, 16, r * 4 + 4, base)
        hline(t, 0, 16, r * 4 + 3, rgb("3d2915"))
        for x in range(0, 16, 3):
            vline(t, x + (r % 3), r * 4, r * 4 + 3, shade(base, 0.8))
    for y in range(16):
        for x in range(16):
            if rng.random() < 0.2:
                p = t.getpixel((x, y))
                t.putpixel((x, y), shade(p, 1.0 + rng.uniform(-0.07, 0.07)))
    return s, t


def quarry():
    rng = rng_for("quarry")
    s = new(16)
    for y in range(16):
        band = [C["stone_m"], shade(C["stone_m"], 0.9), C["stone_l"], shade(C["stone_m"], 0.82)][(y // 3) % 4]
        for x in range(16):
            put(s, x, y, shade(band, 1.0 + rng.uniform(-0.08, 0.08)))
    for p, c in [((4, 3), rgb("d9a98a")), ((5, 3), rgb("d9a98a")), ((10, 6), rgb("1d1d1f")), ((11, 6), rgb("1d1d1f")),
                 ((11, 7), rgb("1d1d1f")), ((6, 9), rgb("d9a98a")), ((5, 10), rgb("d9a98a")), ((9, 11), rgb("1d1d1f")),
                 ((10, 11), rgb("1d1d1f")), ((12, 3), rgb("e6d34a")), ((3, 7), rgb("e6d34a"))]:
        put(s, p[0], p[1], c)
    for x in (0, 14):
        rect(s, x, 0, x + 2, 16, C["wood_m"])
        vline(s, x, 0, 16, C["wood_d"])
    rect(s, 0, 0, 16, 2, C["wood_m"])
    hline(s, 0, 16, 2, C["wood_d"])
    t = new(16)
    for y in range(16):
        for x in range(16):
            put(t, x, y, shade(C["stone_m"], 1.0 + rng.uniform(-0.12, 0.12)))
    disc(t, 8, 8, 5.2, C["wood_d"])
    disc(t, 8, 8, 4.2, rgb("14110f"))
    disc(t, 8, 8, 2.2, rgb("000000"))
    for p in [(2, 2), (13, 3), (3, 13), (12, 12)]:
        put(t, p[0], p[1], rgb("d9a98a"))
    return s, t


def market():
    rng = rng_for("market")
    s = new(16, fill=C["wood_d"])
    for x in range(16):
        col = C["red"] if (x // 2) % 2 == 0 else C["white"]
        rect(s, x, 0, x + 1, 5, col)
        # scalloped bottom edge
        if x % 2 == 0:
            put(s, x, 5, col); put(s, x + 1, 5, col)
    hline(s, 0, 16, 0, shade(C["red"], 0.8))
    rect(s, 0, 6, 16, 12, rgb("3b2a1a"))
    hline(s, 0, 16, 9, C["wood_m"])
    hline(s, 0, 16, 12, C["wood_m"])
    goods = [rgb("d63b3b"), rgb("e8913a"), rgb("6bb84a"), rgb("e8d03a"), rgb("8b4bb8"), rgb("d63b3b")]
    for i, c in enumerate(goods):
        gx = 1 + i * 2 + (i // 3)
        gy = 7 if i % 2 == 0 else 7
        rect(s, gx, gy, gx + 2, gy + 2, c)
        put(s, gx, gy, shade(c, 1.35))
    for i, c in enumerate(reversed(goods)):
        gx = 1 + i * 2 + (i // 3)
        rect(s, gx, 10, gx + 2, 12, c) if i % 2 == 0 else rect(s, gx, 11, gx + 2, 12, c)
    rect(s, 0, 12, 16, 16, C["wood_m"])
    planks(s, 0, 12, 16, 16, C["wood_m"], C["wood_d"], rng, ph=2)
    for x in (3, 8, 12):
        put(s, x, 14, C["gold"])
    t = new(16)
    for x in range(16):
        col = C["red"] if (x // 2) % 2 == 0 else C["white"]
        for y in range(16):
            put(t, x, y, shade(col, 1.0 + rng.uniform(-0.04, 0.04)))
    frame(t, 0, 0, 16, 16, C["wood_d"])
    return s, t


def academy():
    rng = rng_for("academy")
    s = new(16, fill=C["wood_x"])
    rect(s, 0, 0, 16, 13, C["wood_d"])
    cols = [rgb("b33a3a"), rgb("3a62b3"), rgb("3a9a5a"), rgb("d8b13a"), rgb("8a4ab3"), rgb("c97a2e"), rgb("e8e2d0")]
    for row, y0 in enumerate((1, 5, 9)):
        x = 1
        i = row
        while x < 15:
            w = 1 + (i % 2)
            h = 3 if (i % 5) else 2
            c = cols[(i * 3 + row) % len(cols)]
            rect(s, x, y0 + (3 - h), x + w, y0 + 3, c)
            put(s, x, y0 + (3 - h), shade(c, 1.25))
            x += w
            i += 1
        hline(s, 0, 16, y0 + 3, C["wood_x"])
    rect(s, 0, 13, 16, 16, C["stone_m"])
    bricks(s, 0, 13, 16, 16, C["stone_l"], C["mortar"], rng, bw=8, bh=3)
    rect(s, 6, 14, 10, 15, C["gold"])
    t = new(16)
    shingles(t, C["blue"], C["blue_d"], rng, rowh=3, w=4)
    frame(t, 0, 0, 16, 16, C["gold_d"])
    for p in [(8, 4), (7, 6), (8, 6), (9, 6), (6, 7), (7, 7), (8, 7), (9, 7), (10, 7), (7, 8), (8, 8), (9, 8), (7, 9), (9, 9)]:
        put(t, p[0], p[1], C["gold"])
    return s, t


def tavern():
    rng = rng_for("tavern")
    s = new(16)
    planks(s, 0, 0, 16, 16, rgb("7a5230"), rgb("3d2916"), rng)
    rect(s, 1, 5, 6, 10, rgb("f1c14a"))
    frame(s, 0, 4, 7, 11, C["wood_x"])
    vline(s, 3, 5, 10, C["wood_x"]); hline(s, 1, 6, 7, C["wood_x"])
    put(s, 1, 5, rgb("fff0a8"))
    door(s, 8, 7, 12, 16, rgb("4a3019"), C["wood_x"])
    # hanging sign with a mug
    hline(s, 12, 16, 1, C["wood_x"])
    vline(s, 15, 1, 3, C["wood_x"])
    rect(s, 12, 3, 16, 7, rgb("c99a5b"))
    frame(s, 12, 3, 16, 7, C["wood_x"])
    rect(s, 13, 4, 15, 6, rgb("e8b73a"))
    put(s, 13, 4, rgb("f6f1e3")); put(s, 14, 4, rgb("f6f1e3"))
    t = new(16)
    shingles(t, rgb("6e4730"), rgb("3a2417"), rng, rowh=4, w=4)
    rect(t, 10, 2, 14, 6, C["stone_m"])
    frame(t, 10, 2, 14, 6, C["stone_d"])
    rect(t, 11, 3, 13, 5, rgb("101010"))
    return s, t


def barracks():
    rng = rng_for("barracks")
    s = new(16)
    bricks(s, 0, 0, 16, 16, rgb("747478"), rgb("46464a"), rng)
    for x in (2, 12):
        rect(s, x, 4, x + 2, 10, rgb("151518"))
    # shield with crossed swords
    for y in range(3, 12):
        w = 5 if y < 9 else max(1, 5 - (y - 8) * 2)
        x0 = 8 - w // 2 - (1 if w % 2 == 0 else 0)
        rect(s, 8 - (w + 1) // 2 + (0 if w % 2 else 0), y, 8 - (w + 1) // 2 + w, y, C["red"])
    for y in range(3, 12):
        half = 3 if y < 9 else max(0, 3 - (y - 8))
        rect(s, 8 - half, y, 8 + half, y + 1, C["red"])
    frame(s, 5, 3, 11, 4, C["gold"])
    for i in range(5):
        put(s, 6 + i, 4 + i, rgb("e8e8ee"))
        put(s, 10 - i, 4 + i, rgb("e8e8ee"))
    put(s, 8, 6, C["gold"])
    t = new(16)
    for y in range(16):
        for x in range(16):
            put(t, x, y, shade(rgb("6a6a6f"), 1.0 + rng.uniform(-0.08, 0.08)))
    rect(t, 0, 7, 16, 9, C["red"])
    rect(t, 7, 0, 9, 16, C["red"])
    frame(t, 0, 0, 16, 16, rgb("3f3f43"))
    return s, t


def garage():
    rng = rng_for("garage")
    s = new(16)
    for y in range(16):
        for x in range(16):
            put(s, x, y, shade(C["metal_l"], 1.0 + rng.uniform(-0.04, 0.04)))
    for x in range(0, 16, 5):
        vline(s, x, 0, 16, C["metal_m"])
    for x in range(16):
        c = rgb("e8c21a") if ((x + 0) // 2) % 2 == 0 else rgb("202020")
        rect(s, x, 0, x + 1, 2, c)
    rect(s, 2, 4, 14, 16, C["metal_d"])
    for y in range(5, 16, 2):
        hline(s, 2, 14, y, C["metal_m"])
    frame(s, 1, 3, 15, 16, rgb("2f3135"))
    rect(s, 7, 14, 9, 15, rgb("202020"))
    put(s, 14, 2, rgb("ff8a1f"))
    t = new(16)
    for y in range(16):
        for x in range(16):
            c = C["metal_m"] if (x // 2) % 2 == 0 else shade(C["metal_m"], 0.82)
            put(t, x, y, shade(c, 1.0 + rng.uniform(-0.03, 0.03)))
    disc(t, 8, 8, 3.2, C["metal_d"])
    disc(t, 8, 8, 2.2, rgb("202226"))
    frame(t, 0, 0, 16, 16, C["metal_d"])
    return s, t


def watchtower():
    rng = rng_for("watchtower")
    s = new(16)
    bricks(s, 0, 0, 16, 16, rgb("a9a9a4"), rgb("5f5f5c"), rng)
    for x in range(0, 16, 4):
        rect(s, x + 2, 0, x + 4, 3, rgb("4a4a48"))
    hline(s, 0, 16, 3, rgb("4a4a48"))
    rect(s, 7, 6, 9, 12, rgb("101012"))
    vline(s, 6, 6, 12, rgb("74746f")); vline(s, 9, 6, 12, rgb("74746f"))
    rect(s, 0, 13, 16, 15, C["wood_d"])
    hline(s, 0, 16, 13, C["wood_m"])
    t = new(16)
    for y in range(16):
        for x in range(16):
            put(t, x, y, shade(rgb("8f8f8a"), 1.0 + rng.uniform(-0.08, 0.08)))
    frame(t, 0, 0, 16, 16, rgb("bcbcb6"))
    frame(t, 2, 2, 14, 14, rgb("5f5f5c"))
    rect(t, 8, 4, 9, 9, C["wood_d"])
    rect(t, 9, 4, 12, 6, C["red"])
    return s, t


def refinery():
    rng = rng_for("refinery")
    s = new(16)
    for y in range(16):
        for x in range(16):
            put(s, x, y, shade(C["metal_d"], 1.0 + rng.uniform(-0.05, 0.05)))
    for y in (2, 8):
        rect(s, 0, y, 16, y + 2, C["copper"])
        hline(s, 0, 16, y, shade(C["copper"], 1.25))
        hline(s, 0, 16, y + 1, shade(C["copper"], 0.7))
    for x in (4, 11):
        rect(s, x - 1, 1, x + 2, 4, rgb("2a2a2a"))
        disc(s, x, 2.5, 1.2, rgb("d63b3b"))
        rect(s, x - 1, 7, x + 2, 10, rgb("2a2a2a"))
        disc(s, x, 8.5, 1.2, rgb("d63b3b"))
    # flame sign
    for p, c in [((8, 11), rgb("ff8a1f")), ((7, 12), rgb("ff8a1f")), ((8, 12), rgb("ffd23a")), ((9, 12), rgb("ff8a1f")),
                 ((7, 13), rgb("ff8a1f")), ((8, 13), rgb("ffd23a")), ((9, 13), rgb("ff8a1f")), ((8, 14), rgb("ff8a1f"))]:
        put(s, p[0], p[1], c)
    for p in [(1, 1), (14, 1), (1, 14), (14, 14)]:
        put(s, p[0], p[1], C["metal_l"])
    t = new(16)
    for y in range(16):
        for x in range(16):
            c = C["metal_d"] if (x + y) % 4 else shade(C["metal_d"], 0.8)
            put(t, x, y, c)
    ring(t, 8, 8, 5.5, 3.2, C["metal_l"])
    disc(t, 8, 8, 3.2, rgb("15161a"))
    for p in [(7, 7), (8, 8), (9, 9), (8, 7)]:
        put(t, p[0], p[1], rgb("ff8a1f"))
    frame(t, 0, 0, 16, 16, rgb("3a3c40"))
    return s, t


BUILDERS = [
    ("town_hall", town_hall), ("house", house), ("farm", farm), ("lumber_camp", lumber_camp),
    ("quarry", quarry), ("market", market), ("academy", academy), ("tavern", tavern),
    ("barracks", barracks), ("garage", garage), ("watchtower", watchtower), ("refinery", refinery),
]


def generate(preview_dir=None):
    imgs = []
    for bid, fn in BUILDERS:
        side, top = fn()
        save(side, os.path.join(TEX, "block", bid + "_side.png"))
        save(top, os.path.join(TEX, "block", bid + "_top.png"))
        imgs += [side, top]
    if preview_dir:
        sheet(imgs, 8, 8, os.path.join(preview_dir, "blocks.png"))
    return imgs


if __name__ == "__main__":
    import sys
    generate(sys.argv[1] if len(sys.argv) > 1 else None)
