# -*- coding: utf-8 -*-
"""Checks that every translation key used by the Java code exists in lang_data.py (and vice versa)."""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lang_data  # noqa: E402

JAVA = os.path.normpath(os.path.join(HERE, "..", "..", "src", "main", "java"))

literal = set()
for root, _, files in os.walk(JAVA):
    for f in files:
        if f.endswith(".java"):
            text = open(os.path.join(root, f), encoding="utf-8").read()
            for m in re.finditer(r'"([A-Za-z_.]*dynasty[A-Za-z_.0-9]*)"', text):
                literal.add(m.group(1))

used = {k for k in literal if not k.endswith(".") and "." in k and k != "dynasty_realms"}
prefixes = {k for k in literal if k.endswith(".")}

buildings = [b[0] for b in lang_data.BUILDINGS]
professions = ["peasant", "farmer", "lumberjack", "miner", "merchant", "scholar"]
soldiers = ["footman", "archer", "knight", "musketeer", "rifleman", "gunner"]
techs = [t[0] for t in lang_data.TECHS]
vehicles = ["cart", "jeep", "truck", "tank"]
resources = ["coins", "food", "wood", "stone", "iron", "fuel"]
factions = ["north", "east", "republic"]

dynamic = set()
for b in buildings:
    dynamic.add("block.dynasty." + b)
    dynamic.add("gui.dynasty.effect." + b)
for v in vehicles + ["citizen", "soldier", "bandit", "bullet"]:
    dynamic.add("entity.dynasty." + v)
for p in professions:
    dynamic.add("profession.dynasty." + p)
    for n in range(3):
        dynamic.add("dialogue.dynasty.%s.%d" % (p, n))
for who in ["child", "spouse", "unhappy", "love"]:
    for n in range(3):
        dynamic.add("dialogue.dynasty.%s.%d" % (who, n))
for s in soldiers:
    dynamic.add("soldier.dynasty." + s)
for t in techs:
    dynamic.add("tech.dynasty." + t)
    dynamic.add("tech.dynasty." + t + ".desc")
for r in resources:
    dynamic.add("gui.dynasty.res." + r)
    dynamic.add("gui.dynasty.short." + r)
for f in factions:
    dynamic.add("faction.dynasty." + f)
for e in ["martial_law", "free_trade", "patronage"]:
    dynamic.add("edict.dynasty." + e + ".desc")
# registered items (ModItems)
items_src = open(os.path.join(JAVA, "com", "dynasty", "registry", "ModItems.java"), encoding="utf-8").read()
item_ids = set(re.findall(r'(?:registerSimpleItem|registerItem|register)\("([a-z_]+)"', items_src))
item_ids |= set(vehicles)
for i in item_ids:
    dynamic.add("item.dynasty." + i)
dynamic |= {"itemGroup.dynasty", "key.categories.dynasty"}

everything = used | dynamic
have = set(lang_data.T)

missing = sorted(everything - have)
extra = sorted(have - everything)
print("keys used in code:", len(used), "dynamic expansions:", len(dynamic), "defined:", len(have))
print("MISSING (%d):" % len(missing))
for k in missing:
    print("  ", k)
print("UNUSED (%d):" % len(extra))
for k in extra:
    print("  ", k)
# the %s placeholder count must be identical in both languages
bad = [k for k, (uk, en) in lang_data.T.items() if uk.count("%s") != en.count("%s") or uk.count("%%") != en.count("%%")]
print("PLACEHOLDER MISMATCH (%d):" % len(bad), bad)
sys.exit(1 if missing or bad else 0)
