# -*- coding: utf-8 -*-
"""Generates README.md (Ukrainian) with tables read from the Java sources and lang data so numbers never drift."""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import data_gen  # noqa: E402
import lang_data  # noqa: E402

ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
JAVA = os.path.join(ROOT, "src", "main", "java", "com", "dynasty")
T = lang_data.T


def uk(key):
    return T[key][0]


RES_NAMES = ["монети", "їжа", "дерево", "камінь", "залізо", "паливо"]


def cost_text(arr):
    parts = ["%s %d" % (RES_NAMES[i], v) for i, v in enumerate(arr) if v]
    return ", ".join(parts) if parts else "—"


def num(x):
    f = float(x)
    return str(int(f)) if f == int(f) else str(f).replace(".", ",")


def read(path):
    return open(os.path.join(JAVA, path), encoding="utf-8").read()


# ---- buildings ---------------------------------------------------------------------------------------
def upgrade_cost(bid, level):
    l = level
    if bid == "town_hall":
        return [150 * l, 0, 60 * l, 60 * l, 10 * l, 0]
    if bid in ("garage", "refinery"):
        return [120 * l, 0, 30 * l, 40 * l, 20 * l, 0]
    if bid in ("barracks", "watchtower"):
        return [80 * l, 0, 20 * l, 40 * l, 10 * l, 0]
    return [40 * l, 0, 20 * l, 20 * l, 0, 0]


def buildings_table():
    rows = ["| Будівля | Що дає (за кожен рівень) | Покращення 1→2 | Покращення 2→3 |", "|---|---|---|---|"]
    for bid, name, en, eff, _ in lang_data.BUILDINGS:
        rows.append("| **%s** | %s | %s | %s |" % (name, eff, cost_text(upgrade_cost(bid, 1)), cost_text(upgrade_cost(bid, 2))))
    return "\n".join(rows)


# ---- techs ---------------------------------------------------------------------------------------------
def techs_table():
    src = read("realm/Tech.java")
    names = {t[0].upper(): t for t in lang_data.TECHS}
    rows = ["| Епоха | Технологія | Вартість | Потрібно | Ефект |", "|---|---|---|---|---|"]
    for m in re.finditer(r"^\s+([A-Z_]+)\((\d), (\d+)(?:, ([A-Z_, ]+))?\)[,;]", src, re.M):
        tid, era, cost, pre = m.group(1), m.group(2), m.group(3), m.group(4)
        tech = names[tid]
        pre_t = ", ".join(names[p.strip()][1] for p in pre.split(",")) if pre else "—"
        rows.append("| %s | **%s** | %s | %s | %s |" % (era, tech[1], cost, pre_t, tech[3]))
    return "\n".join(rows)


# ---- soldiers -------------------------------------------------------------------------------------------
def soldiers_table():
    src = read("realm/SoldierType.java")
    tnames = {t[0].upper(): t[1] for t in lang_data.TECHS}
    snames = {"FOOTMAN": "Піхотинець", "ARCHER": "Лучник", "KNIGHT": "Лицар", "MUSKETEER": "Мушкетер",
              "RIFLEMAN": "Стрілець", "GUNNER": "Автоматник"}
    rows = ["| Юніт | Технологія | Ціна найму | Утримання (монет/день) | Здоров'я | Шкода |", "|---|---|---|---|---|---|"]
    for m in re.finditer(r"^\s+([A-Z]+)\((null|Tech\.[A-Z_]+), new int\[\] \{([^}]*)\}, (\d+), ([\d.]+), ([\d.]+),", src, re.M):
        sid, tech, cost, upkeep, hp, dmg = m.groups()
        arr = [int(x) for x in cost.split(",")]
        t = "—" if tech == "null" else tnames[tech.split(".")[1]]
        rows.append("| **%s** | %s | %s | %s | %s | %s |" % (snames[sid], t, cost_text(arr), upkeep, num(hp), num(dmg)))
    return "\n".join(rows)


# ---- vehicles -------------------------------------------------------------------------------------------
def vehicles_table():
    src = read("entity/VehicleKind.java")
    tnames = {t[0].upper(): t[1] for t in lang_data.TECHS}
    vn = {"CART": "Візок", "JEEP": "Джип", "TRUCK": "Вантажівка", "TANK": "Танк"}
    garage = {"CART": "—", "JEEP": "1", "TRUCK": "1", "TANK": "2"}
    rows = ["| Техніка | Технологія | Гараж (сума рівнів) | Ціна | Місць | Міцність | Паливо |", "|---|---|---|---|---|---|---|"]
    for m in re.finditer(r"^\s+([A-Z]+)\((null|Tech\.[A-Z_]+), new int\[\] \{([^}]*)\}, (\d+), ([\d.]+), ([\d.]+), ([\d.]+), ([\d.]+)F, (true|false), (true|false),", src, re.M):
        kid, tech, cost, seats, hp, armor, speed, turn, fuel, cannon = m.groups()
        arr = [int(x) for x in cost.split(",")]
        t = "—" if tech == "null" else tnames[tech.split(".")[1]]
        extra = " + гармата" if cannon == "true" else ""
        rows.append("| **%s** | %s | %s | %s | %s | %s | %s%s |" % (
            vn[kid], t, garage[kid], cost_text(arr), seats, num(hp), "так" if fuel == "true" else "ні", extra))
    return "\n".join(rows)


# ---- recipes --------------------------------------------------------------------------------------------
ITEM_UK = {
    "minecraft:gold_ingot": "золотий злиток", "minecraft:diamond": "алмаз", "minecraft:iron_ingot": "залізний злиток",
    "minecraft:coal": "вугілля", "minecraft:paper": "папір", "minecraft:red_dye": "червоний барвник",
    "minecraft:red_wool": "червона вовна", "minecraft:white_wool": "біла вовна", "minecraft:stick": "паличка",
    "minecraft:iron_ingot ": "залізний злиток", "minecraft:gunpowder": "порох", "minecraft:copper_ingot": "мідний злиток",
    "minecraft:iron_nugget": "залізний самородок", "minecraft:flint": "кремінь", "minecraft:flint_and_steel": "кресало",
    "minecraft:iron_block": "залізний блок", "minecraft:redstone": "редстоун", "minecraft:tnt": "TNT",
    "minecraft:stone_bricks": "кам'яна цегла", "minecraft:glass_pane": "скляна панель", "minecraft:wheat": "пшениця",
    "minecraft:dirt": "земля", "minecraft:iron_axe": "залізна сокира", "minecraft:cobblestone": "булижник",
    "minecraft:iron_pickaxe": "залізна кирка", "minecraft:book": "книга", "minecraft:lectern": "кафедра",
    "minecraft:barrel": "бочка", "minecraft:iron_sword": "залізний меч", "minecraft:iron_door": "залізні двері",
    "minecraft:stone": "камінь", "minecraft:ladder": "драбина", "minecraft:furnace": "піч", "minecraft:cauldron": "казан",
    "minecraft:leather": "шкіра", "minecraft:blast_furnace": "доменна піч", "minecraft:chain": "ланцюг",
    "minecraft:planks": "будь-які дошки", "minecraft:wooden_doors": "будь-які дерев'яні двері", "minecraft:logs": "будь-які колоди",
}


def ing_name(obj):
    if "tag" in obj:
        key = obj["tag"]
        return ITEM_UK.get(key, key)
    key = obj["item"]
    if key.startswith("dynasty:"):
        return uk("item.dynasty." + key.split(":")[1]).lower() if key.split(":")[1] in [i[0] for i in lang_data.ITEMS] else uk("block.dynasty." + key.split(":")[1]).lower()
    return ITEM_UK.get(key, key)


def result_name(rid):
    short = rid.split(":")[1]
    if rid.startswith("dynasty:"):
        for iid, name, _ in lang_data.ITEMS:
            if iid == short:
                return name
        for bid, name, *_ in lang_data.BUILDINGS:
            if bid == short:
                return name
    name = ITEM_UK.get(rid, rid)
    return name[:1].upper() + name[1:]


def recipes_table():
    data_gen.RECIPES.clear()
    data_gen.recipes.__wrapped__ if hasattr(data_gen.recipes, "__wrapped__") else None
    # build the recipe dict without writing files twice: call the generator (it is idempotent)
    data_gen.recipes()
    groups = [
        ("Гроші й дрібні речі", ["coins_from_gold", "gold_from_coins", "ring", "fuel_canister", "royal_scroll", "command_banner"]),
        ("Боєприпаси", ["musket_ball", "cartridge", "rocket", "shell", "grenade"]),
        ("Зброя", ["flintlock_pistol", "musket", "rifle", "smg", "bazooka", "halberd"]),
        ("Будівлі", [b[0] for b in lang_data.BUILDINGS]),
        ("Техніка", ["cart", "jeep", "truck", "tank"]),
    ]
    out = []
    for title, names in groups:
        out.append("**%s**\n" % title)
        out.append("| Результат | Інгредієнти |")
        out.append("|---|---|")
        for n in names:
            r = data_gen.RECIPES[n]
            if r["type"].endswith("shapeless"):
                counts = {}
                for ing in r["ingredients"]:
                    k = ing_name(ing)
                    counts[k] = counts.get(k, 0) + 1
                ing = " + ".join(("%d× %s" % (c, k) if c > 1 else k) for k, c in counts.items())
                how = "безформний"
            else:
                counts = {}
                for ch in "".join(r["pattern"]):
                    if ch != " ":
                        counts[ch] = counts.get(ch, 0) + 1
                ing = ", ".join("%d× %s" % (c, ing_name(r["key"][ch])) for ch, c in counts.items())
                how = "за шаблоном"
            cnt = r["result"]["count"]
            out.append("| **%s**%s | %s (%s) |" % (result_name(r["result"]["id"]), (" ×%d" % cnt) if cnt > 1 else "", ing, how))
        out.append("")
    return "\n".join(out)


def guns_table():
    return "\n".join([
        "| Зброя | Технологія | Боєприпас | Шкода | Перезарядка | Примітка |",
        "|---|---|---|---|---|---|",
        "| **Кремінний пістоль** | Порох | мушкетна куля | 8 | 1,75 с | швидкий, неточний |",
        "| **Мушкет** | Порох | мушкетна куля | 12 | 3 с | точний, повільний |",
        "| **Гвинтівка** | Нарізна зброя | патрон | 10 | 1,1 с | далекобійна |",
        "| **Автомат** | Автоматична зброя | патрон | 4,5 | 0,15 с | утримуйте ПКМ — стріляє чергою |",
        "| **Базука** | Вибухівка | ракета | 14 + вибух | 2,5 с | вибух не руйнує блоки |",
        "| **Граната** | Порох | — | вибух | — | кидається ПКМ, вибух не руйнує блоки |",
        "| **Алебарда** | — | — | меч (залізо) | — | ближній бій |",
    ])


def main():
    os.chdir(ROOT)
    tpl = open(os.path.join(HERE, "readme_template.md"), encoding="utf-8").read()
    repl = {
        "{{BUILDINGS}}": buildings_table(),
        "{{TECHS}}": techs_table(),
        "{{SOLDIERS}}": soldiers_table(),
        "{{VEHICLES}}": vehicles_table(),
        "{{GUNS}}": guns_table(),
        "{{RECIPES}}": recipes_table(),
    }
    for k, v in repl.items():
        assert k in tpl, k
        tpl = tpl.replace(k, v)
    with open(os.path.join(ROOT, "README.md"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(tpl)
    print("README.md written,", len(tpl.splitlines()), "lines")


if __name__ == "__main__":
    main()
