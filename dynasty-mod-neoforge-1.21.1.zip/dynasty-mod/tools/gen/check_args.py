# -*- coding: utf-8 -*-
"""Heuristic: compares the number of arguments passed next to each translation key in the Java code with the
number of %s placeholders in the Ukrainian text. Prints every mismatch for manual review."""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lang_data  # noqa: E402

JAVA = os.path.normpath(os.path.join(HERE, "..", "..", "src", "main", "java"))


def split_args(text):
    """text starts right after the string literal; returns number of top-level args following it."""
    depth = 0
    i = 0
    args = 0
    in_str = False
    cur = ""
    n = len(text)
    while i < n:
        c = text[i]
        if in_str:
            cur += c
            if c == "\\":
                cur += text[i + 1]
                i += 1
            elif c == '"':
                in_str = False
        else:
            if c == '"':
                in_str = True
                cur += c
            elif c in "([{":
                depth += 1
                cur += c
            elif c in ")]}":
                if depth == 0:
                    if cur.strip():
                        args += 1
                    return args
                depth -= 1
                cur += c
            elif c == "," and depth == 0:
                if cur.strip():
                    args += 1
                cur = ""
            elif c == ";" and depth == 0:
                return args
            else:
                cur += c
        i += 1
    return args


bad = 0
total = 0
for root, _, files in os.walk(JAVA):
    for f in sorted(files):
        if not f.endswith(".java"):
            continue
        path = os.path.join(root, f)
        text = open(path, encoding="utf-8").read()
        for m in re.finditer(r'"([A-Za-z_.]*dynasty\.[A-Za-z_.0-9]*[A-Za-z0-9_])"\s*([,)])', text):
            key = m.group(1)
            if key not in lang_data.T:
                continue
            rest = text[m.end(1) + 1:]
            if m.group(2) == ")":
                nargs = 0
            else:
                after = text[m.end():]
                nargs = split_args(after)
            expect = lang_data.T[key][0].count("%s")
            total += 1
            if nargs != expect:
                line = text.count("\n", 0, m.start()) + 1
                print("%s:%d  %s  args=%d placeholders=%d" % (os.path.relpath(path, JAVA), line, key, nargs, expect))
                bad += 1
print("checked", total, "call sites;", bad, "to review")
