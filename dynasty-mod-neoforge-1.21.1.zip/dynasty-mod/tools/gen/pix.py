# -*- coding: utf-8 -*-
"""Tiny pixel-art helpers shared by the asset generators."""
import os
import random

from PIL import Image, ImageDraw

RESOURCES = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "src", "main", "resources"))
TEX = os.path.join(RESOURCES, "assets", "dynasty", "textures")


def rgb(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def shade(c, f):
    return (max(0, min(255, int(c[0] * f))), max(0, min(255, int(c[1] * f))), max(0, min(255, int(c[2] * f))), c[3])


def mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(4))


def new(w, h=None, fill=(0, 0, 0, 0)):
    return Image.new("RGBA", (w, h or w), fill)


def put(img, x, y, c):
    if c is not None and 0 <= x < img.width and 0 <= y < img.height:
        img.putpixel((x, y), c)


def rect(img, x0, y0, x1, y1, c):
    """Filled rectangle, x1/y1 exclusive."""
    for y in range(y0, y1):
        for x in range(x0, x1):
            put(img, x, y, c)


def hline(img, x0, x1, y, c):
    rect(img, x0, y, x1, y + 1, c)


def vline(img, x, y0, y1, c):
    rect(img, x, y0, x + 1, y1, c)


def frame(img, x0, y0, x1, y1, c):
    hline(img, x0, x1, y0, c)
    hline(img, x0, x1, y1 - 1, c)
    vline(img, x0, y0, y1, c)
    vline(img, x1 - 1, y0, y1, c)


def disc(img, cx, cy, r, c):
    """Filled disc (pixel centres), r may be fractional."""
    for y in range(int(cy - r - 1), int(cy + r + 2)):
        for x in range(int(cx - r - 1), int(cx + r + 2)):
            if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= r * r:
                put(img, x, y, c)


def ring(img, cx, cy, r_out, r_in, c):
    for y in range(int(cy - r_out - 1), int(cy + r_out + 2)):
        for x in range(int(cx - r_out - 1), int(cx + r_out + 2)):
            d = (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2
            if r_in * r_in < d <= r_out * r_out:
                put(img, x, y, c)


def line(img, p0, p1, c, width=1):
    """Bresenham-ish line with a square brush of the given width."""
    x0, y0 = p0
    x1, y1 = p1
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    off = width // 2
    for i in range(n + 1):
        x = round(x0 + (x1 - x0) * i / n)
        y = round(y0 + (y1 - y0) * i / n)
        for dy in range(width):
            for dx in range(width):
                put(img, x - off + dx, y - off + dy, c)


def poly(img, pts, c):
    ImageDraw.Draw(img).polygon(pts, fill=c)


def outline(img, c=(24, 18, 14, 255), diagonal=False):
    """Adds a one pixel outline around the opaque pixels (only into transparent pixels)."""
    src = img.copy()
    w, h = img.size
    nb = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if diagonal:
        nb += [(1, 1), (-1, 1), (1, -1), (-1, -1)]
    for y in range(h):
        for x in range(w):
            if src.getpixel((x, y))[3] > 0:
                continue
            for dx, dy in nb:
                xx, yy = x + dx, y + dy
                if 0 <= xx < w and 0 <= yy < h and src.getpixel((xx, yy))[3] > 0:
                    img.putpixel((x, y), c)
                    break


def noisy(img, box, amp, rng):
    """Random brightness variation inside box=(x0,y0,x1,y1) for the opaque pixels."""
    x0, y0, x1, y1 = box
    for y in range(y0, y1):
        for x in range(x0, x1):
            p = img.getpixel((x, y))
            if p[3] == 0:
                continue
            f = 1.0 + rng.uniform(-amp, amp)
            img.putpixel((x, y), shade(p, f))


def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def sheet(images, scale, cols, path, bg=(70, 70, 80, 255), pad=2):
    """Contact sheet for visual review (not part of the mod)."""
    if not images:
        return
    w = max(i.width for i in images)
    h = max(i.height for i in images)
    rows = (len(images) + cols - 1) // cols
    out = Image.new("RGBA", (cols * (w * scale + pad) + pad, rows * (h * scale + pad) + pad), bg)
    for n, im in enumerate(images):
        big = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
        x = pad + (n % cols) * (w * scale + pad)
        y = pad + (n // cols) * (h * scale + pad)
        out.alpha_composite(big, (x, y))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    out.save(path)


def rng_for(name):
    return random.Random(sum(ord(ch) * (i + 7) for i, ch in enumerate(name)))
