# -*- coding: utf-8 -*-
"""All translations of the Dynasty mod: (Ukrainian, English) per key."""

T = {}


def add(key, uk, en):
    assert key not in T, key
    T[key] = (uk, en)


# ---- creative tab / keys ----------------------------------------------------------------
add("itemGroup.dynasty", "Династія", "Dynasty")
add("key.categories.dynasty", "Династія", "Dynasty")
add("key.dynasty.fire", "Постріл з гармати", "Fire the cannon")
add("key.dynasty.open", "Відкрити керування королівством", "Open realm screen")

# ---- blocks (buildings) -----------------------------------------------------------------
BUILDINGS = [
    ("town_hall", "Ратуша", "Town Hall", "Центр: +монети, +наука", "Centre: coins, science"),
    ("house", "Будинок", "House", "Житло: +4 (6) жителів", "Housing: +4 (6) people"),
    ("farm", "Ферма", "Farm", "Їжа: +6 за рівень", "Food: +6 per level"),
    ("lumber_camp", "Лісопильня", "Lumber Camp", "Дерево: +5 за рівень", "Wood: +5 per level"),
    ("quarry", "Кар'єр", "Quarry", "Камінь +4, залізо +1", "Stone +4, iron +1"),
    ("market", "Ринок", "Market", "Монети: +6 за рівень", "Coins: +6 per level"),
    ("academy", "Академія", "Academy", "Наука: +3 за рівень", "Science: +3 per level"),
    ("tavern", "Таверна", "Tavern", "Щастя й народжуваність", "Happiness, births"),
    ("barracks", "Казарма", "Barracks", "Армія: +6 місць", "Army: +6 slots"),
    ("garage", "Гараж", "Garage", "Купівля техніки", "Buy vehicles"),
    ("watchtower", "Сторожова вежа", "Watchtower", "Оборона від рейдів", "Raid defence"),
    ("refinery", "Нафтопереробка", "Refinery", "Паливо (треба Нафта)", "Fuel (needs Oil)"),
]
for bid, uk, en, euk, een in BUILDINGS:
    add("block.dynasty." + bid, uk, en)
    add("gui.dynasty.effect." + bid, euk, een)

# ---- items ------------------------------------------------------------------------------
ITEMS = [
    ("coin", "Монета", "Coin"),
    ("ring", "Заручальна каблучка", "Engagement Ring"),
    ("fuel_canister", "Каністра з пальним", "Fuel Canister"),
    ("royal_scroll", "Королівський сувій", "Royal Scroll"),
    ("command_banner", "Командирський прапор", "Command Banner"),
    ("musket_ball", "Мушкетна куля", "Musket Ball"),
    ("cartridge", "Патрон", "Cartridge"),
    ("rocket", "Ракета", "Rocket"),
    ("shell", "Танковий снаряд", "Tank Shell"),
    ("grenade", "Граната", "Grenade"),
    ("flintlock_pistol", "Кремінний пістоль", "Flintlock Pistol"),
    ("musket", "Мушкет", "Musket"),
    ("rifle", "Гвинтівка", "Rifle"),
    ("smg", "Автомат", "Submachine Gun"),
    ("bazooka", "Базука", "Bazooka"),
    ("halberd", "Алебарда", "Halberd"),
    ("cart", "Візок", "Cart"),
    ("jeep", "Джип", "Jeep"),
    ("truck", "Вантажівка", "Truck"),
    ("tank", "Танк", "Tank"),
    ("citizen_spawn_egg", "Яйце виклику: підданий", "Citizen Spawn Egg"),
    ("soldier_spawn_egg", "Яйце виклику: солдат", "Soldier Spawn Egg"),
    ("bandit_spawn_egg", "Яйце виклику: бандит", "Bandit Spawn Egg"),
]
for iid, uk, en in ITEMS:
    add("item.dynasty." + iid, uk, en)

# ---- entities ---------------------------------------------------------------------------
for eid, uk, en in [
    ("citizen", "Підданий", "Citizen"),
    ("soldier", "Солдат", "Soldier"),
    ("bandit", "Бандит", "Bandit"),
    ("bullet", "Снаряд", "Projectile"),
    ("cart", "Візок", "Cart"),
    ("jeep", "Джип", "Jeep"),
    ("truck", "Вантажівка", "Truck"),
    ("tank", "Танк", "Tank"),
]:
    add("entity.dynasty." + eid, uk, en)

# ---- professions, soldiers, factions ------------------------------------------------------
for pid, uk, en in [
    ("peasant", "Селянин", "Peasant"),
    ("farmer", "Фермер", "Farmer"),
    ("lumberjack", "Лісоруб", "Lumberjack"),
    ("miner", "Шахтар", "Miner"),
    ("merchant", "Торговець", "Merchant"),
    ("scholar", "Вчений", "Scholar"),
]:
    add("profession.dynasty." + pid, uk, en)

for sid, uk, en in [
    ("footman", "Піхотинець", "Footman"),
    ("archer", "Лучник", "Archer"),
    ("knight", "Лицар", "Knight"),
    ("musketeer", "Мушкетер", "Musketeer"),
    ("rifleman", "Стрілець", "Rifleman"),
    ("gunner", "Автоматник", "Gunner"),
]:
    add("soldier.dynasty." + sid, uk, en)
add("soldier.dynasty.info", "%s (%s): здоров'я %s/%s, режим: %s", "%s (%s): health %s/%s, mode: %s")
add("soldier.dynasty.dismissed", "%s (%s) звільнений зі служби", "%s (%s) was dismissed from service")
add("soldier.dynasty.mode.follow", "іде за вами", "following you")
add("soldier.dynasty.mode.post", "тримає позицію", "holding position")

for fid, uk, en in [
    ("north", "Північне князівство", "Northern Duchy"),
    ("east", "Східна орда", "Eastern Horde"),
    ("republic", "Вільна республіка", "Free Republic"),
]:
    add("faction.dynasty." + fid, uk, en)
add("diplomacy.dynasty.status.none", "Нейтралітет", "Neutral")
add("diplomacy.dynasty.status.trade", "Торгівля", "Trade")
add("diplomacy.dynasty.status.alliance", "Союз", "Alliance")
add("diplomacy.dynasty.status.war", "Війна", "War")

add("edict.dynasty.martial_law", "Воєнний стан", "Martial Law")
add("edict.dynasty.martial_law.desc", "Утримання армії -30%, але народ незадоволений (щастя -10).",
    "Army upkeep -30%, but the people are unhappy (happiness -10).")
add("edict.dynasty.free_trade", "Вільна торгівля", "Free Trade")
add("edict.dynasty.free_trade.desc", "Податки +25%, але щастя -5.", "Taxes +25%, but happiness -5.")
add("edict.dynasty.patronage", "Меценатство", "Patronage")
add("edict.dynasty.patronage.desc", "Коштує 10 монет щодня, зате щастя +10.", "Costs 10 coins a day, happiness +10.")

add("direction.dynasty.north", "півночі", "the north")
add("direction.dynasty.east", "сходу", "the east")
add("direction.dynasty.south", "півдня", "the south")
add("direction.dynasty.west", "заходу", "the west")

# ---- technologies -----------------------------------------------------------------------
TECHS = [
    ("agriculture", "Землеробство", "Agriculture", "+50% їжі з ферм і фермерів.", "+50% food from farms and farmers."),
    ("archery", "Стрільба з лука", "Archery", "Дозволяє наймати лучників.", "Lets you recruit archers."),
    ("masonry", "Каменярство", "Masonry", "+50% каменю; будинки вміщують 6 жителів.", "+50% stone; houses hold 6 people."),
    ("trade", "Торгівля", "Trade", "+50% монет з ринків і торговців; +25% податків.", "+50% coins from markets and merchants; +25% taxes."),
    ("education", "Освіта", "Education", "+50% науки від академій і вчених.", "+50% science from academies and scholars."),
    ("steelworking", "Сталеварство", "Steelworking", "Подвоює залізо з кар'єрів; лицарі.", "Doubles quarry iron; unlocks knights."),
    ("medicine", "Медицина", "Medicine", "Щастя +5, захист від чуми, більше дітей.", "Happiness +5, plague protection, more children."),
    ("fortification", "Укріплення", "Fortification", "Сторожові вежі вдвічі ефективніші.", "Watchtowers are twice as effective."),
    ("gunpowder", "Порох", "Gunpowder", "Мушкети, пістолі, гранати, мушкетери.", "Muskets, pistols, grenades, musketeers."),
    ("banking", "Банківська справа", "Banking", "Відсотки з казни (1%, до 20 монет).", "Interest on the treasury (1%, up to 20 coins)."),
    ("rifling", "Нарізна зброя", "Rifling", "Гвинтівки та стрільці.", "Rifles and riflemen."),
    ("steam", "Парова машина", "Steam Power", "Основа промисловості.", "The foundation of industry."),
    ("electricity", "Електрика", "Electricity", "+15% науки від академій.", "+15% science from academies."),
    ("industry", "Промисловість", "Industry", "+25% їжі, дерева й каменю.", "+25% food, wood and stone."),
    ("oil", "Нафта", "Oil", "Нафтопереробки виробляють паливо.", "Refineries produce fuel."),
    ("automatic", "Автоматична зброя", "Automatic Weapons", "Автомати та автоматники.", "Submachine guns and gunners."),
    ("combustion", "Двигун внутрішнього згоряння", "Combustion Engine", "Джипи та вантажівки.", "Jeeps and trucks."),
    ("explosives", "Вибухівка", "Explosives", "Базуки та ракети.", "Bazookas and rockets."),
    ("radio", "Радіозв'язок", "Radio", "Прапор командує на 128 блоків (замість 64).", "The banner commands up to 128 blocks (instead of 64)."),
    ("armor", "Бронетехніка", "Armour", "Танки.", "Tanks."),
]
for tid, uk, en, duk, den in TECHS:
    add("tech.dynasty." + tid, uk, en)
    add("tech.dynasty." + tid + ".desc", duk, den)

# ---- dialogues --------------------------------------------------------------------------
DIALOGUE = {
    "peasant": (
        ("Господарство саме себе не підніме, пане.", "The farm won't run itself, my lord."),
        ("Грядки не политі, а вже й вечір...", "The beds aren't watered and it's evening already..."),
        ("Кажуть, цього року буде добрий врожай.", "They say the harvest will be good this year."),
    ),
    "farmer": (
        ("Пшениця цього року — як золото!", "The wheat is like gold this year!"),
        ("Гарні ферми — ситі люди.", "Good farms, well-fed people."),
        ("Дощу б ще трохи — і комора буде повна.", "A little more rain and the barn will be full."),
    ),
    "lumberjack": (
        ("Дерево дзвінке, сокира гостра — життя вдалось.", "Ringing timber, sharp axe - life is good."),
        ("Лісу вистачить на сотню будинків.", "There is enough forest for a hundred houses."),
        ("Обережно, пане, дерево падає!", "Careful, my lord, timber!"),
    ),
    "miner": (
        ("У шахті знайшли жилу — залізо буде.", "We struck a vein - there will be iron."),
        ("Темрява не лякає, лякає порожня кишеня.", "The dark is fine, an empty pocket is not."),
        ("Кам'яна пилюка в носі, зате вдома тепло.", "Stone dust in my nose, but home is warm."),
    ),
    "merchant": (
        ("Торгівля — кров королівства!", "Trade is the blood of the realm!"),
        ("Хочете вигідну угоду? Я знаю одного купця.", "Want a good deal? I know a merchant."),
        ("Монета до монети — і скарбниця повна.", "Coin to coin and the treasury is full."),
    ),
    "scholar": (
        ("Знання — наша найкраща зброя.", "Knowledge is our best weapon."),
        ("Ще трохи — і відкриємо щось геніальне!", "A little more and we will discover something brilliant!"),
        ("Книги не горять... але краще їх не палити.", "Books don't burn... but let's not test that."),
    ),
    "love": (
        ("Ви завжди знаєте, як підняти мені настрій.", "You always know how to lift my mood."),
        ("Ловлю себе на тому, що чекаю на нашу зустріч.", "I catch myself waiting for us to meet."),
        ("З вами навіть звичайний день — свято.", "Even an ordinary day is a holiday with you."),
    ),
    "spouse": (
        ("Любий мій, королівство тримається завдяки вам.", "My dear, the realm stands because of you."),
        ("Вечеря чекає, не затримуйтесь надовго.", "Dinner is waiting, don't be long."),
        ("Щодня дякую долі за нашу зустріч.", "Every day I thank fate that we met."),
    ),
    "child": (
        ("Гра-гра-гра! Пограємось?", "Play, play, play! Shall we play?"),
        ("Я виросту — і стану воїном!", "When I grow up I'll be a warrior!"),
        ("А в вас є цукерки?", "Do you have any candy?"),
    ),
    "unhappy": (
        ("Люди голодні та злі... зробіть щось.", "People are hungry and angry... do something."),
        ("Скарбниця пуста, а податки ростуть — доки?", "The treasury is empty and taxes grow - how long?"),
        ("Ще трохи — і почнуться заворушення.", "Soon there will be riots."),
    ),
}
for who, lines in DIALOGUE.items():
    for i, (uk, en) in enumerate(lines):
        add("dialogue.dynasty.%s.%d" % (who, i), uk, en)

# ---- citizen interaction ------------------------------------------------------------------
for k, uk, en in [
    ("already_talked", "Ми вже сьогодні розмовляли.", "We already talked today."),
    ("foreign", "Це не ваш підданий.", "This is not your subject."),
    ("too_far", "Надто далеко.", "Too far away."),
    ("gift_baby", "Це ще дитина.", "This is still a child."),
    ("gift_none", "Цей предмет не годиться для подарунка.", "That item is not a gift."),
    ("gift_enough", "На сьогодні подарунків досить.", "Enough gifts for today."),
    ("gift_favorite", "Улюблений подарунок! Прихильність різко зросла.", "A favourite gift! Affection soared."),
    ("gift_ok", "Дякую за подарунок!", "Thank you for the gift!"),
    ("date_low", "Потрібна прихильність від 25.", "Needs affection of at least 25."),
    ("date_done", "Сьогодні вже було побачення.", "You already had a date today."),
    ("date_start", "Побачення розпочато! Прогуляйтеся разом пару хвилин.", "Date started! Take a walk together for a couple of minutes."),
    ("date_end", "Побачення з %s вдалося - прихильність зросла.", "The date with %s went well - affection grew."),
    ("hug_no", "Для обіймів потрібна прихильність від 85 (або шлюб).", "Hugs need affection 85+ (or marriage)."),
    ("hug_done", "Сьогодні вже обіймались.", "You already hugged today."),
    ("hug_ok", "Теплі обійми: регенерація й поглинання.", "A warm hug: regeneration and absorption."),
    ("propose_taken", "Цей підданий уже одружений.", "This citizen is already married."),
    ("propose_married", "Ви вже одружені.", "You are already married."),
    ("propose_low", "Потрібна прихильність від 70.", "Needs affection of at least 70."),
    ("propose_noring", "Візьміть каблучку в руку.", "Hold an engagement ring in your hand."),
    ("propose_yes", "Так! Ми одружені!", "Yes! We are married!"),
    ("profession_set", "Тепер працює: %s", "Now works as: %s"),
]:
    add("citizen.dynasty." + k, uk, en)
add("event.dynasty.wedding", "%s і %s одружились! Хай живе династія!", "%s and %s got married! Long live the dynasty!")

# ---- messages -----------------------------------------------------------------------------
for k, uk, en in [
    ("hall_exists", "У вас уже є ратуша.", "You already have a town hall."),
    ("need_hall", "Спершу поставте ратушу.", "Place a town hall first."),
    ("out_of_range", "Занадто далеко від ратуші (радіус %s блоків).", "Too far from the town hall (radius %s blocks)."),
    ("too_many", "Досягнуто ліміту будівель (%s).", "Building limit reached (%s)."),
    ("realm_founded", "Королівство засновано! Будівлі працюють у радіусі %s блоків від ратуші. Сувій або ПКМ по ратуші відкриває керування.",
     "Realm founded! Buildings work within %s blocks of the town hall. Use the scroll or right-click the hall to manage it."),
    ("building_placed", "Будівлю додано до королівства: %s", "Building added to the realm: %s"),
    ("hall_destroyed", "Ратушу зруйновано! Королівство втратило центр.", "The town hall was destroyed! The realm lost its centre."),
    ("need_realm", "Спершу поставте ратушу, щоб заснувати королівство.", "Place a town hall to found a realm first."),
    ("foreign_building", "Ця будівля належить іншому королівству.", "This building belongs to another realm."),
    ("claimed", "Будівлю приєднано до королівства: %s", "Building joined the realm: %s"),
    ("no_building", "Будівлю не знайдено.", "Building not found."),
    ("max_level", "Максимальний рівень.", "Maximum level."),
    ("hall_level_needed", "Спершу покращте ратушу.", "Upgrade the town hall first."),
    ("not_enough", "Недостатньо ресурсів.", "Not enough resources."),
    ("upgraded", "%s покращено до рівня %s.", "%s upgraded to level %s."),
    ("tech_known", "Цю технологію вже відкрито.", "This technology is already known."),
    ("tech_locked", "Спершу відкрийте потрібні технології.", "Research the required technologies first."),
    ("research_started", "Починаємо дослідження: %s", "Research started: %s"),
    ("research_cancelled", "Дослідження скасовано (очки збережено).", "Research cancelled (points are kept)."),
    ("need_tech_soldier", "Потрібна технологія: %s", "Technology required: %s"),
    ("need_tech", "Потрібна технологія: %s", "Technology required: %s"),
    ("army_full", "Армія заповнена - будуйте казарми.", "The army is full - build barracks."),
    ("spawn_failed", "Не вдалося створити юніт.", "Could not create the unit."),
    ("recruited", "Найнято: %s", "Recruited: %s"),
    ("need_garage", "Потрібен гараж рівня %s.", "A garage of level %s is required."),
    ("vehicle_bought", "Техніку куплено: %s (у вашому інвентарі).", "Vehicle bought: %s (in your inventory)."),
    ("deposit_none", "У вас немає ресурсів, які приймає скарбниця.", "You carry nothing the treasury accepts."),
    ("deposited", "Здано предметів: %s", "Items deposited: %s"),
    ("withdrawn", "Взято монет: %s", "Coins taken: %s"),
    ("fuel_withdrawn", "Взято каністр: %s", "Canisters taken: %s"),
    ("edict_on", "Указ чинний: %s", "Edict enacted: %s"),
    ("edict_off", "Указ скасовано: %s", "Edict repealed: %s"),
    ("at_war_with", "Ви у війні з: %s", "You are at war with: %s"),
    ("gift_sent", "Дар надіслано: %s (відносини покращились).", "Gift sent to %s (relations improved)."),
    ("diplo_bad_state", "Зараз це неможливо.", "Not possible right now."),
    ("relation_low", "Відносини надто погані.", "Relations are too poor."),
    ("trade_signed", "Торгова угода з: %s", "Trade agreement with: %s"),
    ("alliance_signed", "Союз укладено: %s", "Alliance signed with: %s"),
    ("war_declared", "Війну оголошено: %s", "War declared on: %s"),
    ("peace_signed", "Мир укладено: %s", "Peace signed with: %s"),
    ("new_day", "День %s: монети %s, їжа %s", "Day %s: coins %s, food %s"),
    ("welcome", "Династія: поставте ратушу, щоб заснувати королівство. Рецепти шукайте в книзі рецептів.",
     "Dynasty: place a town hall to found your realm. Look for recipes in the recipe book."),
    ("welcome_back", "Ваше королівство: день %s, у казні %s монет.", "Your realm: day %s, %s coins in the treasury."),
    ("tech_done", "Відкрито технологію: %s", "Technology discovered: %s"),
    ("child_born", "У вас народилась дитина: %s!", "A child was born to you: %s!"),
    ("child_grown", "%s подорослішав(ла)!", "%s has grown up!"),
    ("succession", "Правитель загинув. Спадкоємець %s продовжує династію (покоління %s).",
     "The ruler has fallen. Heir %s continues the dynasty (generation %s)."),
    ("no_heir", "Правитель загинув без спадкоємця - престиж і щастя впали.", "The ruler died without an heir - prestige and happiness dropped."),
    ("spouse_died", "Ваше кохання, %s, загинуло. Ви овдовіли.", "Your beloved %s has died. You are widowed."),
    ("raid_incoming", "РЕЙД! Бандити (%s) наближаються з %s!", "RAID! Bandits (%s) approach from %s!"),
    ("raid_repelled", "Рейд відбито! Знищено бандитів: %s. Нагорода: %s монет.", "Raid repelled! Bandits slain: %s. Reward: %s coins."),
    ("no_ammo", "Немає боєприпасів: %s", "Out of ammunition: %s"),
    ("order_follow", "Наказ: слідувати за мною (бійців: %s)", "Order: follow me (soldiers: %s)"),
    ("order_post", "Наказ: тримати позицію (бійців: %s)", "Order: hold position (soldiers: %s)"),
    ("order_attack", "Наказ: у атаку! (бійців: %s)", "Order: attack! (soldiers: %s)"),
]:
    add("message.dynasty." + k, uk, en)

# ---- daily report -------------------------------------------------------------------------
for k, uk, en in [
    ("balance", "Баланс: монети %s, їжа %s, дерево %s, камінь %s, залізо %s", "Balance: coins %s, food %s, wood %s, stone %s, iron %s"),
    ("tech_done", "Відкрито технологію: %s", "Technology discovered: %s"),
    ("immigrants", "Прибули нові піддані: %s", "New subjects arrived: %s"),
    ("famine", "ГОЛОД! Їжі не вистачило - щастя падає.", "FAMINE! Not enough food - happiness falls."),
    ("wages_unpaid", "Жалування армії не виплачено!", "The army's wages were not paid!"),
    ("desertion", "Солдат %s дезертирував.", "Soldier %s deserted."),
    ("child_born", "Народилась дитина: %s", "A child was born: %s"),
    ("child_born_citizen", "У родині піддана %s народилась дитина.", "A child was born to the family of %s."),
    ("child_grown", "%s подорослішав(ла).", "%s has grown up."),
    ("wedding_citizens", "Піддані %s та %s одружились.", "Subjects %s and %s got married."),
    ("raid_warning", "Рейд: розбійників %s, з боку: %s", "Raid: %s bandits, from %s"),
    ("raid_deterred", "Бандити побачили вашу оборону й відступили.", "Bandits saw your defences and backed off."),
    ("raid_looted", "Бандити пограбували королівство: -%s монет.", "Bandits looted the realm: -%s coins."),
    ("raid_repelled", "Рейд відбито (%s бандитів)! Нагорода: %s монет.", "Raid repelled (%s bandits)! Reward: %s coins."),
    ("raid_gone", "Бандити зникли.", "The bandits are gone."),
    ("faction_war", "Фракція %s оголосила вам війну!", "%s declared war on you!"),
    ("event_harvest", "Багатий урожай: +%s їжі.", "Bountiful harvest: +%s food."),
    ("event_caravan", "Купецький караван: +%s монет.", "Merchant caravan: +%s coins."),
    ("event_plague", "Чума! Щастя й запаси їжі впали.", "Plague! Happiness and food fell."),
    ("event_plague_healed", "Лікарі зупинили епідемію.", "Healers stopped the epidemic."),
    ("event_festival", "Свято! -40 монет, щастя +12, престиж +1.", "Festival! -40 coins, happiness +12, prestige +1."),
    ("event_ore", "Знайдено багату жилу: +30 каменю, +%s заліза.", "Rich vein found: +30 stone, +%s iron."),
    ("event_thieves", "Злодії викрали %s монет.", "Thieves stole %s coins."),
    ("event_thieves_caught", "Варта впіймала злодіїв.", "The guards caught the thieves."),
    ("event_envoy", "Посол: %s - відносини покращились.", "Envoy of %s - relations improved."),
    ("event_wanderer", "До вас прибився мандрівник: %s.", "A wanderer joined you: %s."),
]:
    add("report.dynasty." + k, uk, en)

# ---- commands -----------------------------------------------------------------------------
for k, uk, en in [
    ("info1", "%s - день %s; монети %s, їжа %s, дерево %s, камінь %s, залізо %s, паливо %s",
     "%s - day %s; coins %s, food %s, wood %s, stone %s, iron %s, fuel %s"),
    ("info2", "Щастя %s%%; жителі %s/%s; армія %s/%s; престиж %s; технології %s/%s",
     "Happiness %s%%; people %s/%s; army %s/%s; prestige %s; technologies %s/%s"),
    ("coins", "Додано монет: %s (у казні %s)", "Coins added: %s (treasury %s)"),
    ("resources", "Додано по %s кожного ресурсу", "Added %s of every resource"),
    ("tech_all", "Усі технології відкрито", "All technologies unlocked"),
    ("tech", "Відкрито: %s", "Unlocked: %s"),
    ("unknown_tech", "Невідома технологія: %s", "Unknown technology: %s"),
    ("nextday", "Минув день королівства (тепер день %s)", "A realm day has passed (now day %s)"),
    ("raid", "Рейд розпочато: бандитів %s", "Raid started: %s bandits"),
    ("raid_failed", "Не вдалося розпочати рейд", "Could not start a raid"),
    ("kit", "Видано стартовий набір", "Starter kit given"),
]:
    add("command.dynasty." + k, uk, en)

# ---- tooltips and HUD ---------------------------------------------------------------------
for k, uk, en in [
    ("scroll", "ПКМ - відкрити керування королівством", "Right-click to open the realm screen"),
    ("banner.1", "ПКМ у повітрі: солдати йдуть за вами", "Right-click in the air: soldiers follow you"),
    ("banner.2", "Shift+ПКМ або ПКМ по блоку: тримати позицію", "Shift+right-click or click a block: hold position"),
    ("banner.3", "ПКМ по ворогу: наказати атакувати", "Right-click an enemy: order an attack"),
    ("gun.damage", "Шкода: %s", "Damage: %s"),
    ("gun.ammo", "Боєприпаси: %s", "Ammunition: %s"),
    ("requires_tech", "Потрібна технологія: %s", "Requires technology: %s"),
    ("grenade", "ПКМ - кинути; вибухає без руйнування блоків", "Right-click to throw; explodes without breaking blocks"),
    ("vehicle.place", "ПКМ по блоку - поставити; Shift+ПКМ по техніці - підібрати", "Right-click a block to place; Shift+right-click it to pick up"),
    ("vehicle.fuel", "Заправка: вугілля, блейз-стрижні або каністра (ПКМ по техніці)", "Fuel: coal, blaze rods or a canister (right-click it)"),
    ("vehicle.cannon", "Клавіша R - постріл з гармати (потрібні снаряди)", "Press R to fire the cannon (needs shells)"),
]:
    add("tooltip.dynasty." + k, uk, en)
add("vehicle.dynasty.hud", "Паливо: %s с · Міцність: %s/%s", "Fuel: %s s · Hull: %s/%s")
add("vehicle.dynasty.hud_nofuel", "Міцність: %s/%s", "Hull: %s/%s")
add("vehicle.dynasty.no_ammo", "Немає танкових снарядів!", "Out of tank shells!")

# ---- GUI ----------------------------------------------------------------------------------
GUI = [
    ("realm", "Королівство", "Realm"),
    ("tab.overview", "Огляд", "Overview"),
    ("tab.buildings", "Будівлі", "Buildings"),
    ("tab.army", "Армія", "Army"),
    ("tab.tech", "Науки", "Science"),
    ("tab.diplomacy", "Політика", "Politics"),
    ("tab.family", "Родина", "Family"),
    ("realm_of", "Королівство: %s", "Realm of %s"),
    ("day_gen", "День %s · Покоління %s", "Day %s · Generation %s"),
    ("res.coins", "Монети", "Coins"),
    ("res.food", "Їжа", "Food"),
    ("res.wood", "Дерево", "Wood"),
    ("res.stone", "Камінь", "Stone"),
    ("res.iron", "Залізо", "Iron"),
    ("res.fuel", "Паливо", "Fuel"),
    ("short.coins", "м", "c"),
    ("short.food", "ї", "f"),
    ("short.wood", "д", "w"),
    ("short.stone", "к", "s"),
    ("short.iron", "з", "i"),
    ("short.fuel", "п", "g"),
    ("happiness", "Щастя", "Happiness"),
    ("population", "Жителі: %s (+%s дітей) / %s", "People: %s (+%s kids) / %s"),
    ("prestige", "Престиж", "Prestige"),
    ("science", "Наука за день", "Science per day"),
    ("army_line", "Армія: %s/%s · Оборона: %s", "Army: %s/%s · Defence: %s"),
    ("raid_active", "РЕЙД! Знищено %s з %s", "RAID! Slain %s of %s"),
    ("report", "Звіт останнього дня", "Last day report"),
    ("deposit", "Здати ресурси", "Deposit goods"),
    ("withdraw_coins", "Взяти 10 монет", "Take 10 coins"),
    ("withdraw_coins.tip", "Видає 10 монет-предметів із казни.", "Takes 10 coin items out of the treasury."),
    ("withdraw_fuel", "Каністра (10 п)", "Canister (10 g)"),
    ("withdraw_fuel.tip", "10 одиниць пального з казни - 1 каністра.", "10 fuel from the treasury - 1 canister."),
    ("buildings_line", "Ратуша: рівень %s · Будівель: %s/%s", "Town hall: level %s · Buildings: %s/%s"),
    ("level", "рівень %s", "level %s"),
    ("upgrade", "Покращити", "Upgrade"),
    ("upgrade.cost", "Ціна: %s", "Cost: %s"),
    ("upgrade.hall_first", "Спершу покращте ратушу", "Upgrade the town hall first"),
    ("max_level", "Максимум", "Maximum"),
    ("recruit", "Найняти", "Recruit"),
    ("buy", "Купити", "Buy"),
    ("needs", "Потрібно:", "Needs:"),
    ("needs_garage", "Потрібен гараж, рівень %s", "Needs a garage, level %s"),
    ("army_head", "Армія %s/%s · Оборона %s · Утримання %s м/день", "Army %s/%s · Defence %s · Upkeep %s c/day"),
    ("vehicles_head", "Техніка (рівень гаражів: %s)", "Vehicles (garage levels: %s)"),
    ("legend", "м монети  ї їжа  д дерево  к камінь  з залізо  п паливо", "c coins  f food  w wood  s stone  i iron  g fuel"),
    ("era", "Епоха", "Era"),
    ("no_research", "Нічого не досліджується. Накопичено: %s (+%s/день)", "Nothing researched. Banked: %s (+%s/day)"),
    ("researching", "Дослідження: %s - %s/%s (+%s/день)", "Researching: %s - %s/%s (+%s/day)"),
    ("tech_cost", "Вартість: %s очок", "Cost: %s points"),
    ("tech_needs", "Потрібно:", "Requires:"),
    ("cancel_research", "Скасувати", "Cancel"),
    ("gift", "Дар (50)", "Gift (50)"),
    ("trade", "Торгівля", "Trade"),
    ("alliance", "Союз (100)", "Alliance (100)"),
    ("war", "Війна", "War"),
    ("peace", "Мир (80)", "Peace (80)"),
    ("relation", "Відносини", "Relations"),
    ("edicts", "Укази", "Edicts"),
    ("diplo_hint", "Дар: 50 монет · Торгівля: відносини від 10 · Союз: торгівля й від 50 · Мир: 80 монет",
     "Gift: 50 coins · Trade: relations 10+ · Alliance: trade and 50+ · Peace: 80 coins"),
    ("family_head", "Ваша династія", "Your dynasty"),
    ("spouse", "Дружина/чоловік", "Spouse"),
    ("none", "немає", "none"),
    ("children", "Діти", "Children"),
    ("adult", "дорослих", "adults"),
    ("heir", "Спадкоємець", "Heir"),
    ("generation", "Покоління", "Generation"),
    ("family_list", "Ваші діти:", "Your children:"),
    ("family_empty", "Поки немає", "None yet"),
    ("family_hint", "Одружіться з підданим (каблучкою) - з'являться діти. Дорослий спадкоємець продовжить династію.",
     "Marry a citizen with a ring and children will come. An adult heir carries the dynasty on."),
    # citizen screen
    ("citizen", "Підданий", "Citizen"),
    ("talk", "Розмовляти", "Talk"),
    ("give_gift", "Подарувати", "Give gift"),
    ("date", "Побачення", "Date"),
    ("hug", "Обійняти", "Hug"),
    ("propose", "Освідчитись", "Propose"),
    ("change_job", "Змінити роботу", "Change job"),
    ("female", "жін.", "female"),
    ("male", "чол.", "male"),
    ("child", "дитина", "child"),
    ("married_to_you", "Одружений(а) з вами", "Married to you"),
    ("married_to", "Одружений(а) з %s", "Married to %s"),
    ("single", "Неодружений(а)", "Single"),
    ("affection", "Прихильність", "Affection"),
    ("favorite_gift", "Улюблений подарунок", "Favourite gift"),
    ("favorite_unknown", "Улюблений подарунок: ще невідомо", "Favourite gift: not known yet"),
    ("parents", "Батьки", "Parents"),
]
for k, uk, en in GUI:
    add("gui.dynasty." + k, uk, en)
