#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Static sanity checks of the resource files (no Minecraft needed)."""
import json
import os
import re
import sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
RES = os.path.join(ROOT, "src", "main", "resources")
JAVA = os.path.join(ROOT, "src", "main", "java")
errors = []
warnings = []

# 1. all json parses
json_files = []
for base, _, files in os.walk(RES):
    for f in files:
        p = os.path.join(base, f)
        if f.endswith(".json"):
            json_files.append(p)
            try:
                with open(p, encoding="utf-8") as fh:
                    json.load(fh)
            except Exception as e:  # noqa: BLE001
                errors.append("invalid json %s: %s" % (os.path.relpath(p, RES), e))
print("json files:", len(json_files))

# 2. texture references of models exist
for p in json_files:
    if "/models/" not in p.replace("\\", "/"):
        continue
    obj = json.load(open(p, encoding="utf-8"))
    for key, val in (obj.get("textures") or {}).items():
        ns, _, path = val.partition(":")
        if ns == "dynasty":
            tp = os.path.join(RES, "assets", "dynasty", "textures", path + ".png")
            if not os.path.exists(tp):
                errors.append("%s: missing texture %s" % (os.path.relpath(p, RES), val))
    parent = obj.get("parent", "")
    if parent.startswith("dynasty:"):
        pp = os.path.join(RES, "assets", "dynasty", "models", parent.split(":")[1] + ".json")
        if not os.path.exists(pp):
            errors.append("%s: missing parent model %s" % (os.path.relpath(p, RES), parent))

# 3. ids registered in code vs resources
items_src = open(os.path.join(JAVA, "com", "dynasty", "registry", "ModItems.java"), encoding="utf-8").read()
item_ids = set(re.findall(r'(?:registerSimpleItem|registerItem|register)\("([a-z_]+)"', items_src))
building_ids = ["town_hall", "house", "farm", "lumber_camp", "quarry", "market", "academy", "tavern", "barracks", "garage",
                "watchtower", "refinery"]
item_ids |= set(building_ids) | {"cart", "jeep", "truck", "tank"}
for i in sorted(item_ids):
    if not os.path.exists(os.path.join(RES, "assets", "dynasty", "models", "item", i + ".json")):
        errors.append("missing item model for " + i)
for b in building_ids:
    for rel in ("assets/dynasty/blockstates/%s.json" % b, "assets/dynasty/models/block/%s.json" % b,
                "data/dynasty/loot_table/blocks/%s.json" % b,
                "assets/dynasty/textures/block/%s_side.png" % b, "assets/dynasty/textures/block/%s_top.png" % b):
        if not os.path.exists(os.path.join(RES, rel)):
            errors.append("missing " + rel)

# 4. entity textures used by the renderers
profs = ["peasant", "farmer", "lumberjack", "miner", "merchant", "scholar"]
need = ["assets/dynasty/textures/entity/citizen/%s_%s_%d.png" % (p, s, t) for p in profs for s in "mf" for t in (0, 1)]
need += ["assets/dynasty/textures/entity/soldier/%s.png" % s for s in ("footman", "archer", "knight", "musketeer", "rifleman", "gunner")]
need += ["assets/dynasty/textures/entity/bandit/%s.png" % s for s in ("thug", "archer", "gunman")]
need += ["assets/dynasty/textures/entity/vehicle/%s.png" % s for s in ("cart", "jeep", "truck", "tank")]
for rel in need:
    if not os.path.exists(os.path.join(RES, rel)):
        errors.append("missing " + rel)

# 5. recipes only reference known items of this mod
for base, _, files in os.walk(os.path.join(RES, "data", "dynasty", "recipe")):
    for f in files:
        obj = json.load(open(os.path.join(base, f), encoding="utf-8"))
        refs = [obj["result"]["id"]]

        def walk(o):
            if isinstance(o, dict):
                if "item" in o:
                    refs.append(o["item"])
                for v in o.values():
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)

        walk(obj.get("key", {}))
        walk(obj.get("ingredients", []))
        for r in refs:
            if r.startswith("dynasty:") and r.split(":")[1] not in item_ids:
                errors.append("recipe %s references unknown item %s" % (f, r))
        if obj["type"] == "minecraft:crafting_shaped":
            used = set("".join(obj["pattern"])) - {" "}
            if used != set(obj["key"]):
                errors.append("recipe %s: pattern keys %s != key %s" % (f, sorted(used), sorted(obj["key"])))
            if len(obj["pattern"]) > 3 or any(len(r) > 3 for r in obj["pattern"]):
                errors.append("recipe %s: pattern too large" % f)

print("errors: %d" % len(errors))
for e in errors:
    print("  ERROR", e)
sys.exit(1 if errors else 0)
