#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerates every texture, model, recipe, loot table, language file and the VehicleModels.java class.

Usage:  python tools/generate_assets.py [preview_dir]

Requires Python 3.9+ and Pillow (pip install pillow). The generated files are committed to the repository, so this
script is only needed when you want to change the art/recipes/translations - the Gradle build does not run it.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "gen"))

import data_gen  # noqa: E402
import tex_blocks  # noqa: E402
import tex_items  # noqa: E402
import tex_skins  # noqa: E402
import vehicles  # noqa: E402


def main():
    preview = sys.argv[1] if len(sys.argv) > 1 else None
    tex_blocks.generate(preview)
    tex_items.generate(preview)
    tex_skins.generate(preview)
    path = vehicles.generate(preview)
    n = data_gen.generate()
    print("done: %d recipes, vehicle models written to %s" % (n, os.path.relpath(path, os.path.dirname(HERE))))


if __name__ == "__main__":
    main()
