package com.dynasty.event;

import com.dynasty.Dynasty;
import com.dynasty.entity.BanditEntity;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.realm.RealmCommands;
import com.dynasty.realm.RealmManager;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Game (server) event handlers. */
@EventBusSubscriber(modid = Dynasty.MODID)
public final class GameEvents {
    private GameEvents() {}

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (server.getTickCount() % 100 == 0) {
            RealmManager.tick(server);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RealmManager.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) {
            return;
        }
        if (entity instanceof ServerPlayer player) {
            RealmManager.onRulerDeath(player);
        } else if (entity instanceof BanditEntity bandit) {
            RealmManager.onBanditKilled(bandit);
        } else if (entity instanceof CitizenEntity citizen) {
            RealmManager.onCitizenDied(citizen);
        }
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        RealmCommands.register(event.getDispatcher());
    }
}
