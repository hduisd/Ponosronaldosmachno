package com.dynasty.event;

import com.dynasty.Dynasty;
import com.dynasty.entity.BanditEntity;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.entity.SoldierEntity;
import com.dynasty.entity.VehicleEntity;
import com.dynasty.entity.VehicleKind;
import com.dynasty.registry.ModEntities;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

/** Mod bus event handlers. */
@EventBusSubscriber(modid = Dynasty.MODID)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.CITIZEN.get(), CitizenEntity.createAttributes().build());
        event.put(ModEntities.SOLDIER.get(), SoldierEntity.createAttributes().build());
        event.put(ModEntities.BANDIT.get(), BanditEntity.createAttributes().build());
        for (VehicleKind kind : VehicleKind.values()) {
            event.put(kind.entityType(), VehicleEntity.createAttributes(kind).build());
        }
    }
}
