package com.dynasty.realm;

/** Abstract neighbouring powers used by the diplomacy system. */
public final class Faction {
    public static final int COUNT = 3;

    public static final int STATUS_NONE = 0;
    public static final int STATUS_TRADE = 1;
    public static final int STATUS_ALLIANCE = 2;
    public static final int STATUS_WAR = 3;

    private static final String[] IDS = {"north", "east", "republic"};

    private Faction() {}

    public static String nameKey(int index) {
        return "faction.dynasty." + IDS[Math.floorMod(index, COUNT)];
    }

    public static String statusKey(int status) {
        switch (status) {
            case STATUS_TRADE:
                return "diplomacy.dynasty.status.trade";
            case STATUS_ALLIANCE:
                return "diplomacy.dynasty.status.alliance";
            case STATUS_WAR:
                return "diplomacy.dynasty.status.war";
            default:
                return "diplomacy.dynasty.status.none";
        }
    }
}
