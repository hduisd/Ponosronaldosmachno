package com.dynasty.realm;

/** All building blocks that can belong to a realm. */
public enum BuildingType {
    TOWN_HALL("town_hall", true),
    HOUSE("house", false),
    FARM("farm", false),
    LUMBER_CAMP("lumber_camp", false),
    QUARRY("quarry", true),
    MARKET("market", false),
    ACADEMY("academy", true),
    TAVERN("tavern", false),
    BARRACKS("barracks", true),
    GARAGE("garage", true),
    WATCHTOWER("watchtower", true),
    REFINERY("refinery", true);

    public static final int MAX_LEVEL = 3;

    public final String id;
    public final boolean stone;

    BuildingType(String id, boolean stone) {
        this.id = id;
        this.stone = stone;
    }

    public String nameKey() {
        return "block.dynasty." + id;
    }

    public static BuildingType byIndex(int i) {
        BuildingType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }

    /** Cost to upgrade from the given level to the next one: coins, food, wood, stone, iron, fuel. */
    public int[] upgradeCost(int fromLevel) {
        int l = Math.max(1, fromLevel);
        switch (this) {
            case TOWN_HALL:
                return new int[] {150 * l, 0, 60 * l, 60 * l, 10 * l, 0};
            case GARAGE:
            case REFINERY:
                return new int[] {120 * l, 0, 30 * l, 40 * l, 20 * l, 0};
            case BARRACKS:
            case WATCHTOWER:
                return new int[] {80 * l, 0, 20 * l, 40 * l, 10 * l, 0};
            default:
                return new int[] {40 * l, 0, 20 * l, 20 * l, 0, 0};
        }
    }
}
