package com.dynasty.realm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;

import com.dynasty.Config;
import com.dynasty.entity.BanditEntity;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.entity.SoldierEntity;
import com.dynasty.registry.ModEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

/** World-facing helpers of the realm logic: levels, spawning, census. */
final class RealmWorld {
    private RealmWorld() {}

    @Nullable
    static ServerLevel levelOf(MinecraftServer server, Realm r) {
        ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(r.dim));
        return server.getLevel(key);
    }

    static boolean hallLoaded(MinecraftServer server, Realm r) {
        if (r.hall == null) {
            return false;
        }
        ServerLevel level = levelOf(server, r);
        return level != null && level.isLoaded(r.hall);
    }

    /** Finds a free spot on the surface at a random distance and direction around a centre. */
    static BlockPos surfaceNear(ServerLevel level, BlockPos center, int minRadius, int maxRadius) {
        RandomSource rng = level.getRandom();
        for (int i = 0; i < 16; i++) {
            double angle = rng.nextDouble() * Math.PI * 2.0D;
            double dist = minRadius + rng.nextDouble() * Math.max(0, maxRadius - minRadius);
            int x = center.getX() + (int) Math.round(Math.cos(angle) * dist);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * dist);
            if (!level.isLoaded(new BlockPos(x, center.getY(), z))) {
                continue;
            }
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
            BlockPos below = top.below();
            if (level.getFluidState(below).isEmpty() && !level.getBlockState(below).isAir()) {
                return top;
            }
        }
        return center.above();
    }

    // ---- citizens ------------------------------------------------------------------------

    static List<CitizenEntity> ownedCitizens(ServerLevel level, Realm r) {
        AABB box = new AABB(r.hall).inflate(Config.REALM_RADIUS.get() + 16);
        return level.getEntitiesOfClass(CitizenEntity.class, box,
                c -> c.isAlive() && (c.getOwnerId() == null || r.owner.equals(c.getOwnerId())));
    }

    static Profession pickProfession(Realm r, RandomSource rng) {
        int[] w = new int[Profession.values().length];
        w[Profession.PEASANT.ordinal()] = 2;
        w[Profession.FARMER.ordinal()] = 1 + r.count(BuildingType.FARM);
        w[Profession.LUMBERJACK.ordinal()] = 1 + r.count(BuildingType.LUMBER_CAMP);
        w[Profession.MINER.ordinal()] = 1 + r.count(BuildingType.QUARRY);
        w[Profession.MERCHANT.ordinal()] = 1 + r.count(BuildingType.MARKET);
        w[Profession.SCHOLAR.ordinal()] = 1 + r.count(BuildingType.ACADEMY);
        int total = 0;
        for (int v : w) {
            total += v;
        }
        int roll = rng.nextInt(total);
        for (int i = 0; i < w.length; i++) {
            roll -= w[i];
            if (roll < 0) {
                return Profession.byIndex(i);
            }
        }
        return Profession.PEASANT;
    }

    @Nullable
    static CitizenEntity spawnCitizen(ServerLevel level, Realm r, BlockPos near, int minRadius, int maxRadius,
                                      Profession profession) {
        CitizenEntity c = ModEntities.CITIZEN.get().create(level);
        if (c == null) {
            return null;
        }
        BlockPos pos = surfaceNear(level, near, minRadius, maxRadius);
        c.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.getRandom().nextFloat() * 360.0F, 0.0F);
        c.initCitizen(level.getRandom());
        c.setProfession(profession);
        c.setOwner(r.owner);
        c.setHome(r.hall);
        level.addFreshEntity(c);
        return c;
    }

    @Nullable
    static CitizenEntity spawnBaby(ServerLevel level, Realm r, BlockPos at, String parentA, String parentB,
                                   int generation, boolean playerChild) {
        CitizenEntity baby = ModEntities.CITIZEN.get().create(level);
        if (baby == null) {
            return null;
        }
        baby.moveTo(at.getX() + 0.5D, at.getY(), at.getZ() + 0.5D, level.getRandom().nextFloat() * 360.0F, 0.0F);
        baby.initCitizen(level.getRandom());
        baby.setOwner(r.owner);
        baby.setHome(r.hall);
        baby.setGeneration(generation);
        baby.setParents(parentA + " & " + parentB);
        baby.setPlayerChild(playerChild);
        baby.setAge(-24000 * Config.CHILD_DAYS.get());
        level.addFreshEntity(baby);
        return baby;
    }

    // ---- census --------------------------------------------------------------------------

    /** Recounts citizens (around the hall) and soldiers (around the hall and around the ruler). */
    static void census(MinecraftServer server, Realm r) {
        ServerLevel level = levelOf(server, r);
        if (level == null || r.hall == null) {
            return;
        }
        if (level.isLoaded(r.hall)) {
            int adults = 0;
            int babies = 0;
            int[] jobs = new int[Profession.values().length];
            for (CitizenEntity c : ownedCitizens(level, r)) {
                if (c.getOwnerId() == null) {
                    c.setOwner(r.owner);
                    c.setHome(r.hall);
                }
                if (c.isBaby()) {
                    babies++;
                } else {
                    adults++;
                    jobs[c.getProfession().ordinal()]++;
                }
            }
            r.population = adults;
            r.babies = babies;
            System.arraycopy(jobs, 0, r.jobs, 0, jobs.length);
        }
        ServerPlayer owner = server.getPlayerList().getPlayer(r.owner);
        if (owner != null) {
            int[] counts = new int[SoldierType.values().length];
            Set<Integer> seen = new HashSet<>();
            if (level.isLoaded(r.hall)) {
                countSoldiers(level, new AABB(r.hall).inflate(Config.REALM_RADIUS.get() + 32), r, counts, seen);
            }
            countSoldiers(owner.serverLevel(), owner.getBoundingBox().inflate(160.0D), r, counts, seen);
            System.arraycopy(counts, 0, r.soldierCounts, 0, counts.length);
        }
    }

    private static void countSoldiers(ServerLevel level, AABB box, Realm r, int[] counts, Set<Integer> seen) {
        for (SoldierEntity s : level.getEntitiesOfClass(SoldierEntity.class, box,
                e -> e.isAlive() && r.owner.equals(e.getOwnerId()))) {
            if (seen.add(s.getId())) {
                counts[s.getSoldierType().ordinal()]++;
            }
        }
    }

    // ---- raids ---------------------------------------------------------------------------

    static List<BanditEntity> raiders(MinecraftServer server, Realm r) {
        List<BanditEntity> list = new ArrayList<>();
        ServerLevel level = levelOf(server, r);
        if (level == null || r.hall == null) {
            return list;
        }
        AABB box = new AABB(r.hall).inflate(Config.REALM_RADIUS.get() + 96);
        list.addAll(level.getEntitiesOfClass(BanditEntity.class, box,
                b -> b.isAlive() && r.owner.equals(b.getRealmOwner())));
        return list;
    }

    /** Result of spawning a raid: how many raiders and where they gathered. */
    record Raid(int count, BlockPos base) {}

    /** Spawns a band of raiders around 40 blocks from the hall. */
    static Raid spawnRaid(ServerLevel level, Realm r, int size) {
        RandomSource rng = level.getRandom();
        double angle = rng.nextDouble() * Math.PI * 2.0D;
        int cx = r.hall.getX() + (int) Math.round(Math.cos(angle) * 42.0D);
        int cz = r.hall.getZ() + (int) Math.round(Math.sin(angle) * 42.0D);
        BlockPos base = new BlockPos(cx, r.hall.getY(), cz);
        if (!level.isLoaded(base)) {
            base = surfaceNear(level, r.hall, 24, 34);
        } else {
            base = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base);
        }
        double gunChance = r.has(Tech.GUNPOWDER) || r.day > 25 ? 0.35D : 0.10D;
        int spawned = 0;
        for (int i = 0; i < size; i++) {
            BanditEntity b = ModEntities.BANDIT.get().create(level);
            if (b == null) {
                continue;
            }
            double roll = rng.nextDouble();
            int kind = roll < gunChance ? BanditEntity.GUNMAN : roll < gunChance + 0.25D ? BanditEntity.ARCHER : BanditEntity.THUG;
            BlockPos pos = surfaceNear(level, base, 0, 4);
            b.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, rng.nextFloat() * 360.0F, 0.0F);
            b.setKind(kind);
            b.setRealmOwner(r.owner);
            b.setRaidTarget(r.hall);
            level.addFreshEntity(b);
            spawned++;
        }
        return new Raid(spawned, base);
    }

    /** Compass direction key from the hall towards the point the raiders came from. */
    static String directionKey(BlockPos from, BlockPos to) {
        int dx = to.getX() - from.getX();
        int dz = to.getZ() - from.getZ();
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? "direction.dynasty.east" : "direction.dynasty.west";
        }
        return dz > 0 ? "direction.dynasty.south" : "direction.dynasty.north";
    }

    @Nullable
    static Entity find(ServerLevel level, @Nullable java.util.UUID id) {
        return id == null ? null : level.getEntity(id);
    }
}
