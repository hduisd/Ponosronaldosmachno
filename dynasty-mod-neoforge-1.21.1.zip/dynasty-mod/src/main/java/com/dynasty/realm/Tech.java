package com.dynasty.realm;

import java.util.Locale;

/** The technology tree. Costs are research points. */
public enum Tech {
    AGRICULTURE(1, 15),
    ARCHERY(1, 15),
    MASONRY(1, 20),
    TRADE(1, 25),
    EDUCATION(1, 30, AGRICULTURE),
    STEELWORKING(1, 40, MASONRY),
    MEDICINE(1, 35, EDUCATION),
    FORTIFICATION(2, 50, MASONRY),
    GUNPOWDER(2, 60, STEELWORKING, EDUCATION),
    BANKING(2, 60, TRADE, EDUCATION),
    RIFLING(2, 80, GUNPOWDER),
    STEAM(3, 100, GUNPOWDER, STEELWORKING),
    ELECTRICITY(3, 120, STEAM),
    INDUSTRY(3, 120, STEAM, BANKING),
    OIL(3, 130, STEAM),
    AUTOMATIC(3, 150, RIFLING, INDUSTRY),
    COMBUSTION(4, 160, OIL),
    EXPLOSIVES(4, 170, GUNPOWDER, INDUSTRY),
    RADIO(4, 160, ELECTRICITY),
    ARMOR(4, 200, COMBUSTION, STEELWORKING);

    public final int era;
    public final int cost;
    public final Tech[] prereqs;
    public final String id;

    Tech(int era, int cost, Tech... prereqs) {
        this.era = era;
        this.cost = cost;
        this.prereqs = prereqs;
        this.id = name().toLowerCase(Locale.ROOT);
    }

    public String nameKey() {
        return "tech.dynasty." + id;
    }

    public String descKey() {
        return "tech.dynasty." + id + ".desc";
    }

    public static Tech byId(String id) {
        for (Tech t : values()) {
            if (t.id.equals(id)) {
                return t;
            }
        }
        return null;
    }

    public static Tech byIndex(int i) {
        Tech[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
