package com.dynasty.realm;

import javax.annotation.Nullable;

import com.dynasty.Config;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.player.Player;

/** Checks whether the realm of a player knows a technology. */
public final class TechGate {
    private TechGate() {}

    /** On the client this always returns true; the server makes the real decision. */
    public static boolean allowed(Player player, @Nullable Tech tech) {
        if (tech == null) {
            return true;
        }
        if (player.level().isClientSide) {
            return true;
        }
        if (!Config.REQUIRE_TECH.get() || player.getAbilities().instabuild) {
            return true;
        }
        MinecraftServer server = player.getServer();
        if (server == null) {
            return true;
        }
        Realm realm = RealmData.get(server).getRealm(player.getUUID());
        return realm != null && realm.has(tech);
    }

    public static void deny(Player player, Tech tech) {
        if (!player.level().isClientSide) {
            player.displayClientMessage(
                    Component.translatable("message.dynasty.need_tech", Component.translatable(tech.nameKey())), true);
        }
    }
}
