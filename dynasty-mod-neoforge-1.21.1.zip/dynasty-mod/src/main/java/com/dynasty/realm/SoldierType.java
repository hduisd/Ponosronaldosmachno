package com.dynasty.realm;

import java.util.Locale;

/** Kinds of soldiers that can be recruited. */
public enum SoldierType {
    //          tech                  coins food wood stone iron fuel   upkeep hp   dmg  armor range interval melee speed
    FOOTMAN(null, new int[] {15, 5, 0, 0, 2, 0}, 1, 24.0, 5.0, 2.0, 0, 0, true, 0.30),
    ARCHER(Tech.ARCHERY, new int[] {20, 5, 3, 0, 0, 0}, 1, 20.0, 5.0, 0.0, 18, 30, false, 0.28),
    KNIGHT(Tech.STEELWORKING, new int[] {50, 10, 0, 0, 12, 0}, 3, 40.0, 8.0, 8.0, 0, 0, true, 0.27),
    MUSKETEER(Tech.GUNPOWDER, new int[] {60, 10, 0, 0, 8, 0}, 3, 22.0, 11.0, 2.0, 24, 60, false, 0.27),
    RIFLEMAN(Tech.RIFLING, new int[] {90, 12, 0, 0, 12, 0}, 4, 26.0, 9.0, 4.0, 32, 25, false, 0.28),
    GUNNER(Tech.AUTOMATIC, new int[] {130, 14, 0, 0, 20, 0}, 6, 28.0, 4.5, 6.0, 20, 6, false, 0.28);

    public final Tech tech;
    public final int[] cost;
    public final int upkeep;
    public final double health;
    public final double damage;
    public final double armor;
    public final int range;
    public final int interval;
    public final boolean melee;
    public final double speed;
    public final String id;

    SoldierType(Tech tech, int[] cost, int upkeep, double health, double damage, double armor,
                int range, int interval, boolean melee, double speed) {
        this.tech = tech;
        this.cost = cost;
        this.upkeep = upkeep;
        this.health = health;
        this.damage = damage;
        this.armor = armor;
        this.range = range;
        this.interval = interval;
        this.melee = melee;
        this.speed = speed;
        this.id = name().toLowerCase(Locale.ROOT);
    }

    public String nameKey() {
        return "soldier.dynasty." + id;
    }

    public static SoldierType byIndex(int i) {
        SoldierType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
