package com.dynasty.realm;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

/** All persistent state of one player's realm. */
public final class Realm {
    public static final int RES_COINS = 0;
    public static final int RES_FOOD = 1;
    public static final int RES_WOOD = 2;
    public static final int RES_STONE = 3;
    public static final int RES_IRON = 4;
    public static final int RES_FUEL = 5;
    public static final int RES_COUNT = 6;

    public static final int EDICT_MARTIAL_LAW = 1;
    public static final int EDICT_FREE_TRADE = 2;
    public static final int EDICT_PATRONAGE = 4;

    public final UUID owner;
    public String ownerName = "";
    public String dim = "minecraft:overworld";
    public BlockPos hall;

    public int coins = 120;
    public int food = 50;
    public int wood = 30;
    public int stone = 30;
    public int iron = 8;
    public int fuel = 0;

    public int happiness = 60;
    public int day = 0;
    public long lastDay = Long.MIN_VALUE;
    public int prestige = 0;
    public int generation = 1;

    public final Set<String> techs = new LinkedHashSet<>();
    public String researching = "";
    public int progress = 0;

    public final Map<Long, Building> buildings = new LinkedHashMap<>();

    public int edicts = 0;
    public final int[] relation = new int[Faction.COUNT];
    public final int[] status = new int[Faction.COUNT];

    public UUID spouse;
    public String spouseName = "";
    public int childrenBorn = 0;
    public int adultChildren = 0;
    public String heirName = "";
    public final List<String> family = new ArrayList<>();

    // census cache (refreshed every day while the hall is loaded)
    public int population = 0;
    public int babies = 0;
    public final int[] jobs = new int[Profession.values().length];
    public final int[] soldierCounts = new int[SoldierType.values().length];

    // raids
    public int raidSize = 0;
    public int raidKills = 0;
    public int raidCooldown = 2;

    public final List<String> report = new ArrayList<>();

    public Realm(UUID owner) {
        this.owner = owner;
    }

    // ---- queries -------------------------------------------------------------------------

    public boolean has(Tech tech) {
        return techs.contains(tech.id);
    }

    public boolean hasEdict(int bit) {
        return (edicts & bit) != 0;
    }

    public boolean hasHall() {
        return hall != null;
    }

    public int count(BuildingType type) {
        int n = 0;
        for (Building b : buildings.values()) {
            if (b.type == type) {
                n++;
            }
        }
        return n;
    }

    public int levelSum(BuildingType type) {
        int n = 0;
        for (Building b : buildings.values()) {
            if (b.type == type) {
                n += b.level;
            }
        }
        return n;
    }

    public int hallLevel() {
        if (hall == null) {
            return 1;
        }
        Building b = buildings.get(hall.asLong());
        return b == null ? 1 : b.level;
    }

    public int soldiers() {
        int n = 0;
        for (int c : soldierCounts) {
            n += c;
        }
        return n;
    }

    public int capacity() {
        int cap = hall == null ? 0 : 4 * hallLevel();
        cap += levelSum(BuildingType.HOUSE) * (has(Tech.MASONRY) ? 6 : 4);
        return cap;
    }

    public int armyCap() {
        return 2 + 6 * levelSum(BuildingType.BARRACKS);
    }

    public int defense() {
        int d = 10 * levelSum(BuildingType.WATCHTOWER) * (has(Tech.FORTIFICATION) ? 2 : 1);
        return d + soldiers() * 3;
    }

    public int get(int res) {
        switch (res) {
            case RES_COINS:
                return coins;
            case RES_FOOD:
                return food;
            case RES_WOOD:
                return wood;
            case RES_STONE:
                return stone;
            case RES_IRON:
                return iron;
            default:
                return fuel;
        }
    }

    public void add(int res, int amount) {
        switch (res) {
            case RES_COINS:
                coins = clamp(coins + amount);
                break;
            case RES_FOOD:
                food = clamp(food + amount);
                break;
            case RES_WOOD:
                wood = clamp(wood + amount);
                break;
            case RES_STONE:
                stone = clamp(stone + amount);
                break;
            case RES_IRON:
                iron = clamp(iron + amount);
                break;
            default:
                fuel = clamp(fuel + amount);
                break;
        }
    }

    private static int clamp(long v) {
        return (int) Math.max(0L, Math.min(999_999L, v));
    }

    public boolean canAfford(int[] cost) {
        for (int i = 0; i < RES_COUNT && i < cost.length; i++) {
            if (cost[i] > get(i)) {
                return false;
            }
        }
        return true;
    }

    public void pay(int[] cost) {
        for (int i = 0; i < RES_COUNT && i < cost.length; i++) {
            add(i, -cost[i]);
        }
    }

    public boolean atWar() {
        for (int s : status) {
            if (s == Faction.STATUS_WAR) {
                return true;
            }
        }
        return false;
    }

    public boolean hasAlliance() {
        for (int s : status) {
            if (s == Faction.STATUS_ALLIANCE) {
                return true;
            }
        }
        return false;
    }

    /** Adds a line to the daily report. Arguments starting with '@' are translation keys. */
    public void log(String key, String... args) {
        StringBuilder sb = new StringBuilder(key);
        for (String a : args) {
            sb.append('|').append(a);
        }
        report.add(sb.toString());
    }

    // ---- persistence ---------------------------------------------------------------------

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putUUID("owner", owner);
        t.putString("ownerName", ownerName);
        t.putString("dim", dim);
        if (hall != null) {
            t.putLong("hall", hall.asLong());
        }
        t.putInt("coins", coins);
        t.putInt("food", food);
        t.putInt("wood", wood);
        t.putInt("stone", stone);
        t.putInt("iron", iron);
        t.putInt("fuel", fuel);
        t.putInt("happiness", happiness);
        t.putInt("day", day);
        t.putLong("lastDay", lastDay);
        t.putInt("prestige", prestige);
        t.putInt("generation", generation);
        ListTag techList = new ListTag();
        for (String s : techs) {
            techList.add(StringTag.valueOf(s));
        }
        t.put("techs", techList);
        t.putString("researching", researching);
        t.putInt("progress", progress);
        ListTag bl = new ListTag();
        for (Map.Entry<Long, Building> e : buildings.entrySet()) {
            CompoundTag b = new CompoundTag();
            b.putLong("p", e.getKey());
            b.putInt("t", e.getValue().type.ordinal());
            b.putInt("l", e.getValue().level);
            bl.add(b);
        }
        t.put("buildings", bl);
        t.putInt("edicts", edicts);
        t.putIntArray("relation", relation);
        t.putIntArray("status", status);
        if (spouse != null) {
            t.putUUID("spouse", spouse);
        }
        t.putString("spouseName", spouseName);
        t.putInt("childrenBorn", childrenBorn);
        t.putInt("adultChildren", adultChildren);
        t.putString("heirName", heirName);
        ListTag fl = new ListTag();
        for (String s : family) {
            fl.add(StringTag.valueOf(s));
        }
        t.put("family", fl);
        t.putInt("population", population);
        t.putInt("babies", babies);
        t.putIntArray("jobs", jobs);
        t.putIntArray("soldierCounts", soldierCounts);
        t.putInt("raidSize", raidSize);
        t.putInt("raidKills", raidKills);
        t.putInt("raidCooldown", raidCooldown);
        ListTag rl = new ListTag();
        for (String s : report) {
            rl.add(StringTag.valueOf(s));
        }
        t.put("report", rl);
        return t;
    }

    public static Realm load(CompoundTag t) {
        Realm r = new Realm(t.getUUID("owner"));
        r.ownerName = t.getString("ownerName");
        r.dim = t.getString("dim");
        if (r.dim.isEmpty()) {
            r.dim = "minecraft:overworld";
        }
        if (t.contains("hall")) {
            r.hall = BlockPos.of(t.getLong("hall"));
        }
        r.coins = t.getInt("coins");
        r.food = t.getInt("food");
        r.wood = t.getInt("wood");
        r.stone = t.getInt("stone");
        r.iron = t.getInt("iron");
        r.fuel = t.getInt("fuel");
        r.happiness = t.getInt("happiness");
        r.day = t.getInt("day");
        r.lastDay = t.contains("lastDay") ? t.getLong("lastDay") : Long.MIN_VALUE;
        r.prestige = t.getInt("prestige");
        r.generation = Math.max(1, t.getInt("generation"));
        ListTag techList = t.getList("techs", Tag.TAG_STRING);
        for (int i = 0; i < techList.size(); i++) {
            r.techs.add(techList.getString(i));
        }
        r.researching = t.getString("researching");
        r.progress = t.getInt("progress");
        ListTag bl = t.getList("buildings", Tag.TAG_COMPOUND);
        for (int i = 0; i < bl.size(); i++) {
            CompoundTag b = bl.getCompound(i);
            BuildingType type = BuildingType.byIndex(b.getInt("t"));
            r.buildings.put(b.getLong("p"), new Building(type, Math.max(1, b.getInt("l"))));
        }
        r.edicts = t.getInt("edicts");
        copy(t.getIntArray("relation"), r.relation);
        copy(t.getIntArray("status"), r.status);
        if (t.hasUUID("spouse")) {
            r.spouse = t.getUUID("spouse");
        }
        r.spouseName = t.getString("spouseName");
        r.childrenBorn = t.getInt("childrenBorn");
        r.adultChildren = t.getInt("adultChildren");
        r.heirName = t.getString("heirName");
        ListTag fl = t.getList("family", Tag.TAG_STRING);
        for (int i = 0; i < fl.size(); i++) {
            r.family.add(fl.getString(i));
        }
        r.population = t.getInt("population");
        r.babies = t.getInt("babies");
        copy(t.getIntArray("jobs"), r.jobs);
        copy(t.getIntArray("soldierCounts"), r.soldierCounts);
        r.raidSize = t.getInt("raidSize");
        r.raidKills = t.getInt("raidKills");
        r.raidCooldown = t.getInt("raidCooldown");
        ListTag rl = t.getList("report", Tag.TAG_STRING);
        for (int i = 0; i < rl.size(); i++) {
            r.report.add(rl.getString(i));
        }
        return r;
    }

    private static void copy(int[] src, int[] dst) {
        System.arraycopy(src, 0, dst, 0, Math.min(src.length, dst.length));
    }
}
