package com.dynasty.realm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** World-saved storage of all realms (attached to the overworld). */
public class RealmData extends SavedData {
    public static final String NAME = "dynasty_realms";

    private final Map<UUID, Realm> realms = new LinkedHashMap<>();

    public RealmData() {}

    public static RealmData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(RealmData::new, RealmData::load), NAME);
    }

    public static RealmData load(CompoundTag tag, HolderLookup.Provider lookup) {
        RealmData data = new RealmData();
        ListTag list = tag.getList("realms", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Realm r = Realm.load(list.getCompound(i));
            data.realms.put(r.owner, r);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider lookup) {
        ListTag list = new ListTag();
        for (Realm r : realms.values()) {
            list.add(r.save());
        }
        tag.put("realms", list);
        return tag;
    }

    public Realm getRealm(UUID owner) {
        return realms.get(owner);
    }

    public Realm create(UUID owner, String ownerName) {
        Realm r = new Realm(owner);
        r.ownerName = ownerName;
        realms.put(owner, r);
        setDirty();
        return r;
    }

    public Collection<Realm> all() {
        return new ArrayList<>(realms.values());
    }

    public List<Realm> list() {
        return new ArrayList<>(realms.values());
    }
}
