package com.dynasty.realm;

import com.dynasty.registry.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** /dynasty ... commands: info for everybody, the rest for operators. */
public final class RealmCommands {
    private RealmCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("dynasty")
                .then(Commands.literal("info").executes(ctx -> info(ctx.getSource())))
                .then(Commands.literal("coins").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("amount", IntegerArgumentType.integer(-100000, 100000))
                                .executes(ctx -> coins(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "amount")))))
                .then(Commands.literal("resources").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1, 100000))
                                .executes(ctx -> resources(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "amount")))))
                .then(Commands.literal("tech").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("all").executes(ctx -> techAll(ctx.getSource())))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .executes(ctx -> tech(ctx.getSource(), StringArgumentType.getString(ctx, "id")))))
                .then(Commands.literal("nextday").requires(s -> s.hasPermission(2))
                        .executes(ctx -> nextDay(ctx.getSource())))
                .then(Commands.literal("raid").requires(s -> s.hasPermission(2))
                        .executes(ctx -> raid(ctx.getSource())))
                .then(Commands.literal("kit").requires(s -> s.hasPermission(2))
                        .executes(ctx -> kit(ctx.getSource()))));
    }

    private static Realm realm(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        Realm r = RealmData.get(source.getServer()).getRealm(player.getUUID());
        if (r == null) {
            source.sendFailure(Component.translatable("message.dynasty.need_realm"));
            return null;
        }
        return r;
    }

    private static int info(CommandSourceStack source) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        RealmWorld.census(source.getServer(), r);
        source.sendSuccess(() -> Component.translatable("command.dynasty.info1", r.ownerName, r.day, r.coins, r.food,
                r.wood, r.stone, r.iron, r.fuel), false);
        source.sendSuccess(() -> Component.translatable("command.dynasty.info2", r.happiness, r.population + r.babies,
                r.capacity(), r.soldiers(), r.armyCap(), r.prestige, r.techs.size(), Tech.values().length), false);
        return 1;
    }

    private static int coins(CommandSourceStack source, int amount) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        r.add(Realm.RES_COINS, amount);
        RealmData.get(source.getServer()).setDirty();
        source.sendSuccess(() -> Component.translatable("command.dynasty.coins", amount, r.coins), true);
        return 1;
    }

    private static int resources(CommandSourceStack source, int amount) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        for (int i = 0; i < Realm.RES_COUNT; i++) {
            r.add(i, amount);
        }
        RealmData.get(source.getServer()).setDirty();
        source.sendSuccess(() -> Component.translatable("command.dynasty.resources", amount), true);
        return 1;
    }

    private static int techAll(CommandSourceStack source) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        for (Tech t : Tech.values()) {
            r.techs.add(t.id);
        }
        r.researching = "";
        RealmData.get(source.getServer()).setDirty();
        source.sendSuccess(() -> Component.translatable("command.dynasty.tech_all"), true);
        return 1;
    }

    private static int tech(CommandSourceStack source, String id) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        Tech t = Tech.byId(id);
        if (t == null) {
            source.sendFailure(Component.translatable("command.dynasty.unknown_tech", id));
            return 0;
        }
        r.techs.add(t.id);
        RealmData.get(source.getServer()).setDirty();
        source.sendSuccess(() -> Component.translatable("command.dynasty.tech", Component.translatable(t.nameKey())), true);
        return 1;
    }

    private static int nextDay(CommandSourceStack source) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        if (!r.hasHall()) {
            source.sendFailure(Component.translatable("message.dynasty.need_realm"));
            return 0;
        }
        RealmManager.processDay(source.getServer(), RealmData.get(source.getServer()), r);
        source.sendSuccess(() -> Component.translatable("command.dynasty.nextday", r.day), true);
        return 1;
    }

    private static int raid(CommandSourceStack source) throws CommandSyntaxException {
        Realm r = realm(source);
        if (r == null) {
            return 0;
        }
        ServerLevel level = RealmWorld.levelOf(source.getServer(), r);
        ServerPlayer player = source.getPlayerOrException();
        if (level == null || !RealmManager.startRaid(level, r, level.getRandom(), player)) {
            source.sendFailure(Component.translatable("command.dynasty.raid_failed"));
            return 0;
        }
        RealmData.get(source.getServer()).setDirty();
        source.sendSuccess(() -> Component.translatable("command.dynasty.raid", r.raidSize), true);
        return 1;
    }

    private static void give(ServerPlayer player, Item item, int count) {
        ItemStack stack = new ItemStack(item, count);
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    private static int kit(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.TOWN_HALL).get(), 1);
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.HOUSE).get(), 3);
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.FARM).get(), 2);
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.LUMBER_CAMP).get(), 1);
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.QUARRY).get(), 1);
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.MARKET).get(), 1);
        give(player, ModItems.BUILDING_ITEMS.get(BuildingType.BARRACKS).get(), 1);
        give(player, ModItems.ROYAL_SCROLL.get(), 1);
        give(player, ModItems.COMMAND_BANNER.get(), 1);
        give(player, ModItems.RING.get(), 2);
        give(player, ModItems.COIN.get(), 64);
        source.sendSuccess(() -> Component.translatable("command.dynasty.kit"), true);
        return 1;
    }
}
