package com.dynasty.realm;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Nullable;

import com.dynasty.Config;
import com.dynasty.entity.BanditEntity;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.entity.SoldierEntity;
import com.dynasty.entity.VehicleKind;
import com.dynasty.net.Net;
import com.dynasty.net.RealmSnapshot;
import com.dynasty.registry.ModEntities;
import com.dynasty.registry.ModItems;
import com.dynasty.util.Fx;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * The rules of the game: founding a realm, buildings, the daily cycle (economy, research,
 * happiness, family, events, raids) and everything the realm screen can ask for.
 */
public final class RealmManager {
    // ---- screen actions (client to server) -----------------------------------------------
    public static final int ACT_UPGRADE = 0;
    public static final int ACT_RESEARCH = 1;
    public static final int ACT_RECRUIT = 2;
    public static final int ACT_VEHICLE = 3;
    public static final int ACT_DEPOSIT = 4;
    public static final int ACT_WITHDRAW_COINS = 5;
    public static final int ACT_WITHDRAW_FUEL = 6;
    public static final int ACT_EDICT = 7;
    public static final int ACT_DIPLOMACY = 8;
    public static final int ACT_REFRESH = 9;

    public static final int DIPLO_GIFT = 0;
    public static final int DIPLO_TRADE = 1;
    public static final int DIPLO_ALLIANCE = 2;
    public static final int DIPLO_WAR = 3;
    public static final int DIPLO_PEACE = 4;

    public static final int TAB_OVERVIEW = 0;
    public static final int TAB_BUILDINGS = 1;
    public static final int TAB_ARMY = 2;
    public static final int TAB_TECH = 3;
    public static final int TAB_DIPLOMACY = 4;
    public static final int TAB_FAMILY = 5;

    public static final int MAX_BUILDINGS = 60;
    private static final int MAX_REPORT_LINES = 36;

    private RealmManager() {}

    // ---- helpers -------------------------------------------------------------------------

    /** The number of the current Minecraft day. */
    public static long today(MinecraftServer server) {
        return server.overworld().getDayTime() / 24000L;
    }

    @Nullable
    public static Realm realmOf(MinecraftServer server, UUID owner) {
        return RealmData.get(server).getRealm(owner);
    }

    private static Realm realmOrCreate(ServerPlayer player) {
        RealmData data = RealmData.get(player.server);
        Realm r = data.getRealm(player.getUUID());
        if (r == null) {
            r = data.create(player.getUUID(), player.getName().getString());
        } else {
            r.ownerName = player.getName().getString();
        }
        return r;
    }

    private static String fmt(String key, String... args) {
        StringBuilder sb = new StringBuilder(key);
        for (String a : args) {
            sb.append('|').append(a);
        }
        return sb.toString();
    }

    private static String err(String key, String... args) {
        return "!" + fmt(key, args);
    }

    private static void msg(ServerPlayer player, String key, Object... args) {
        player.displayClientMessage(Component.translatable(key, args), true);
    }

    private static void chat(@Nullable ServerPlayer player, String key, Object... args) {
        if (player != null) {
            player.sendSystemMessage(Component.translatable(key, args));
        }
    }

    private static void addReport(Realm r, String key, String... args) {
        r.log(key, args);
        while (r.report.size() > MAX_REPORT_LINES) {
            r.report.remove(0);
        }
    }

    private static boolean techOk(ServerPlayer player, Realm r, @Nullable Tech tech) {
        return tech == null || r.has(tech) || player.getAbilities().instabuild || !Config.REQUIRE_TECH.get();
    }

    private static boolean withinRealm(Realm r, ServerLevel level, BlockPos pos) {
        if (r.hall == null || !r.dim.equals(level.dimension().location().toString())) {
            return false;
        }
        double dx = pos.getX() - r.hall.getX();
        double dz = pos.getZ() - r.hall.getZ();
        double radius = Config.REALM_RADIUS.get();
        return dx * dx + dz * dz <= radius * radius;
    }

    // ---- placing and using buildings -----------------------------------------------------

    /** Checked while a building block is about to be placed (server side). */
    public static boolean canPlace(ServerPlayer player, BuildingType type, BlockPos pos) {
        Realm r = realmOf(player.server, player.getUUID());
        if (type == BuildingType.TOWN_HALL) {
            if (r != null && r.hasHall()) {
                msg(player, "message.dynasty.hall_exists");
                return false;
            }
            return true;
        }
        if (r == null || !r.hasHall()) {
            msg(player, "message.dynasty.need_hall");
            return false;
        }
        if (!withinRealm(r, (ServerLevel) player.level(), pos)) {
            msg(player, "message.dynasty.out_of_range", Config.REALM_RADIUS.get());
            return false;
        }
        if (r.buildings.size() >= MAX_BUILDINGS) {
            msg(player, "message.dynasty.too_many", MAX_BUILDINGS);
            return false;
        }
        return true;
    }

    public static void onBuildingPlaced(ServerLevel level, BlockPos pos, BuildingType type, ServerPlayer player) {
        RealmData data = RealmData.get(player.server);
        Realm r = realmOrCreate(player);
        if (type == BuildingType.TOWN_HALL) {
            if (r.hasHall()) {
                return;
            }
            r.hall = pos.immutable();
            r.dim = level.dimension().location().toString();
            r.buildings.put(pos.asLong(), new Building(type, 1));
            r.lastDay = today(player.server);
            if (r.day == 0) {
                for (int i = 0; i < 3; i++) {
                    RealmWorld.spawnCitizen(level, r, pos, 3, 8, RealmWorld.pickProfession(r, level.getRandom()));
                }
                RealmWorld.census(player.server, r);
            }
            Fx.sound(level, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, "ui.toast.challenge_complete", 1.0F, 1.0F);
            player.sendSystemMessage(Component.translatable("message.dynasty.realm_founded", Config.REALM_RADIUS.get()));
        } else {
            if (!withinRealm(r, level, pos) || r.buildings.size() >= MAX_BUILDINGS) {
                return;
            }
            r.buildings.put(pos.asLong(), new Building(type, 1));
            msg(player, "message.dynasty.building_placed", Component.translatable(type.nameKey()));
        }
        data.setDirty();
    }

    public static void onBuildingRemoved(ServerLevel level, BlockPos pos, BuildingType type) {
        MinecraftServer server = level.getServer();
        RealmData data = RealmData.get(server);
        String dim = level.dimension().location().toString();
        for (Realm r : data.all()) {
            if (!r.dim.equals(dim)) {
                continue;
            }
            Building b = r.buildings.get(pos.asLong());
            if (b == null || b.type != type) {
                continue;
            }
            r.buildings.remove(pos.asLong());
            if (type == BuildingType.TOWN_HALL && r.hall != null && r.hall.asLong() == pos.asLong()) {
                r.hall = null;
                chat(server.getPlayerList().getPlayer(r.owner), "message.dynasty.hall_destroyed");
            }
            data.setDirty();
            return;
        }
    }

    public static void onBuildingUsed(ServerPlayer player, ServerLevel level, BlockPos pos, BuildingType type) {
        MinecraftServer server = player.server;
        RealmData data = RealmData.get(server);
        Realm r = data.getRealm(player.getUUID());
        if (r == null || !r.hasHall()) {
            msg(player, "message.dynasty.need_realm");
            return;
        }
        Building b = r.buildings.get(pos.asLong());
        if (b == null) {
            String dim = level.dimension().location().toString();
            for (Realm other : data.all()) {
                if (other != r && other.dim.equals(dim) && other.buildings.containsKey(pos.asLong())) {
                    msg(player, "message.dynasty.foreign_building");
                    return;
                }
            }
            if (!withinRealm(r, level, pos) || r.buildings.size() >= MAX_BUILDINGS) {
                msg(player, "message.dynasty.out_of_range", Config.REALM_RADIUS.get());
                return;
            }
            r.buildings.put(pos.asLong(), new Building(type, 1));
            data.setDirty();
            msg(player, "message.dynasty.claimed", Component.translatable(type.nameKey()));
        }
        RealmWorld.census(server, r);
        sendRealm(player, r, type == BuildingType.TOWN_HALL ? TAB_OVERVIEW : TAB_BUILDINGS, pos.asLong(), "");
    }

    public static void openRealm(ServerPlayer player) {
        Realm r = realmOf(player.server, player.getUUID());
        if (r == null || !r.hasHall()) {
            msg(player, "message.dynasty.need_realm");
            return;
        }
        RealmWorld.census(player.server, r);
        sendRealm(player, r, TAB_OVERVIEW, RealmSnapshot.NO_FOCUS, "");
    }

    // ---- snapshot ------------------------------------------------------------------------

    public static void sendRealm(ServerPlayer player, Realm r, int tab, long focus, String message) {
        Net.sendRealm(player, snapshot(r, tab, focus, message));
    }

    public static RealmSnapshot snapshot(Realm r, int tab, long focus, String message) {
        RealmSnapshot s = new RealmSnapshot();
        s.tab = tab;
        s.focus = focus;
        s.message = message;
        s.ownerName = r.ownerName;
        s.day = r.day;
        for (int i = 0; i < Realm.RES_COUNT; i++) {
            s.res[i] = r.get(i);
        }
        Economy e = Economy.compute(r);
        int[] income = e.income();
        income[Realm.RES_COINS] -= e.upkeepCoins;
        income[Realm.RES_FOOD] -= e.upkeepFood;
        System.arraycopy(income, 0, s.income, 0, Realm.RES_COUNT);
        s.science = e.sciencePoints();
        s.upkeepCoins = e.upkeepCoins;
        s.happiness = r.happiness;
        s.population = r.population;
        s.babies = r.babies;
        s.capacity = r.capacity();
        s.prestige = r.prestige;
        s.generation = r.generation;
        s.armyCap = r.armyCap();
        s.defense = r.defense();
        System.arraycopy(r.soldierCounts, 0, s.soldiers, 0, s.soldiers.length);
        System.arraycopy(r.jobs, 0, s.jobs, 0, s.jobs.length);
        s.researching = r.researching;
        s.progress = r.progress;
        int bits = 0;
        for (Tech t : Tech.values()) {
            if (r.has(t)) {
                bits |= 1 << t.ordinal();
            }
        }
        s.techBits = bits;
        s.edicts = r.edicts;
        System.arraycopy(r.relation, 0, s.relation, 0, Faction.COUNT);
        System.arraycopy(r.status, 0, s.status, 0, Faction.COUNT);
        s.garageLevels = r.levelSum(BuildingType.GARAGE);
        s.hallLevel = r.hallLevel();
        s.raidSize = r.raidSize;
        s.raidKills = r.raidKills;
        s.spouseName = r.spouseName;
        s.heirName = r.heirName;
        s.childrenBorn = r.childrenBorn;
        s.adultChildren = r.adultChildren;
        s.family.addAll(r.family);
        s.report.addAll(r.report);
        int n = 0;
        for (Map.Entry<Long, Building> en : r.buildings.entrySet()) {
            if (n++ >= MAX_BUILDINGS) {
                break;
            }
            s.bType.add(en.getValue().type.ordinal());
            s.bLevel.add(en.getValue().level);
            s.bPos.add(en.getKey());
        }
        return s;
    }

    // ---- actions from the realm screen ---------------------------------------------------

    public static void handleAction(ServerPlayer player, int action, int arg1, int arg2, long arg3) {
        MinecraftServer server = player.server;
        RealmData data = RealmData.get(server);
        Realm r = data.getRealm(player.getUUID());
        if (r == null || !r.hasHall()) {
            msg(player, "message.dynasty.need_realm");
            return;
        }
        String message = "";
        long focus = RealmSnapshot.NO_FOCUS;
        int tab = RealmSnapshot.TAB_KEEP;
        switch (action) {
            case ACT_UPGRADE:
                message = upgrade(player, r, arg3);
                focus = arg3;
                break;
            case ACT_RESEARCH:
                message = research(r, arg1);
                break;
            case ACT_RECRUIT:
                message = recruit(player, r, arg1);
                break;
            case ACT_VEHICLE:
                message = buyVehicle(player, r, arg1);
                break;
            case ACT_DEPOSIT:
                message = deposit(player, r);
                break;
            case ACT_WITHDRAW_COINS:
                message = withdrawCoins(player, r, arg1);
                break;
            case ACT_WITHDRAW_FUEL:
                message = withdrawFuel(player, r, arg1);
                break;
            case ACT_EDICT:
                message = toggleEdict(r, arg1);
                break;
            case ACT_DIPLOMACY:
                message = diplomacy(r, arg1, arg2);
                break;
            case ACT_REFRESH:
                RealmWorld.census(server, r);
                tab = TAB_OVERVIEW;
                break;
            default:
                break;
        }
        data.setDirty();
        sendRealm(player, r, tab, focus, message);
    }

    private static String upgrade(ServerPlayer player, Realm r, long posLong) {
        Building b = r.buildings.get(posLong);
        if (b == null) {
            return err("message.dynasty.no_building");
        }
        if (b.level >= BuildingType.MAX_LEVEL) {
            return err("message.dynasty.max_level");
        }
        if (b.type != BuildingType.TOWN_HALL && b.level >= r.hallLevel()) {
            return err("message.dynasty.hall_level_needed");
        }
        int[] cost = b.type.upgradeCost(b.level);
        if (!r.canAfford(cost)) {
            return err("message.dynasty.not_enough");
        }
        r.pay(cost);
        b.level++;
        if (b.type == BuildingType.TOWN_HALL) {
            r.prestige += 1;
        }
        BlockPos bp = BlockPos.of(posLong);
        ServerLevel level = RealmWorld.levelOf(player.server, r);
        if (level != null) {
            Fx.sound(level, bp.getX() + 0.5D, bp.getY() + 0.5D, bp.getZ() + 0.5D, "entity.player.levelup", 0.8F, 1.2F);
            Fx.particles(level, ParticleTypes.HAPPY_VILLAGER, bp.getX() + 0.5D, bp.getY() + 1.2D, bp.getZ() + 0.5D, 14, 0.5D);
        }
        return fmt("message.dynasty.upgraded", "@" + b.type.nameKey(), String.valueOf(b.level));
    }

    private static String research(Realm r, int index) {
        if (index < 0) {
            r.researching = "";
            return fmt("message.dynasty.research_cancelled");
        }
        if (index >= Tech.values().length) {
            return "";
        }
        Tech t = Tech.byIndex(index);
        if (r.has(t)) {
            return err("message.dynasty.tech_known");
        }
        for (Tech p : t.prereqs) {
            if (!r.has(p)) {
                return err("message.dynasty.tech_locked");
            }
        }
        r.researching = t.id;
        return fmt("message.dynasty.research_started", "@" + t.nameKey());
    }

    private static String recruit(ServerPlayer player, Realm r, int index) {
        if (index < 0 || index >= SoldierType.values().length) {
            return "";
        }
        SoldierType type = SoldierType.byIndex(index);
        if (!techOk(player, r, type.tech)) {
            return err("message.dynasty.need_tech_soldier", "@" + type.tech.nameKey());
        }
        RealmWorld.census(player.server, r);
        if (r.soldiers() >= r.armyCap()) {
            return err("message.dynasty.army_full");
        }
        if (!r.canAfford(type.cost)) {
            return err("message.dynasty.not_enough");
        }
        ServerLevel level = (ServerLevel) player.level();
        SoldierEntity soldier = ModEntities.SOLDIER.get().create(level);
        if (soldier == null) {
            return err("message.dynasty.spawn_failed");
        }
        BlockPos pos = RealmWorld.surfaceNear(level, player.blockPosition(), 2, 4);
        soldier.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, player.getYRot(), 0.0F);
        soldier.initSoldier(type, player.getUUID(), null);
        level.addFreshEntity(soldier);
        r.pay(type.cost);
        r.soldierCounts[type.ordinal()]++;
        Fx.sound(level, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, "item.armor.equip_iron", 1.0F, 1.0F);
        return fmt("message.dynasty.recruited", "@" + type.nameKey());
    }

    private static String buyVehicle(ServerPlayer player, Realm r, int index) {
        if (index < 0 || index >= VehicleKind.values().length) {
            return "";
        }
        VehicleKind kind = VehicleKind.byIndex(index);
        if (!techOk(player, r, kind.tech)) {
            return err("message.dynasty.need_tech_soldier", "@" + kind.tech.nameKey());
        }
        int garage = kind == VehicleKind.CART ? 0 : kind == VehicleKind.TANK ? 2 : 1;
        if (r.levelSum(BuildingType.GARAGE) < garage) {
            return err("message.dynasty.need_garage", String.valueOf(garage));
        }
        if (!r.canAfford(kind.cost)) {
            return err("message.dynasty.not_enough");
        }
        r.pay(kind.cost);
        give(player, new ItemStack(kind.item()));
        return fmt("message.dynasty.vehicle_bought", "@" + kind.nameKey());
    }

    private static void give(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    /** {resource, amount per item} for an item the treasury accepts, or null. */
    @Nullable
    private static int[] rate(ItemStack stack) {
        Item item = stack.getItem();
        if (item == ModItems.COIN.get()) {
            return new int[] {Realm.RES_COINS, 1};
        }
        if (item == Items.GOLD_INGOT) {
            return new int[] {Realm.RES_COINS, 9};
        }
        if (stack.is(ItemTags.LOGS)) {
            return new int[] {Realm.RES_WOOD, 4};
        }
        if (stack.is(ItemTags.PLANKS)) {
            return new int[] {Realm.RES_WOOD, 1};
        }
        if (item == Items.COBBLESTONE || item == Items.STONE || item == Items.COBBLED_DEEPSLATE
                || item == Items.ANDESITE || item == Items.DIORITE || item == Items.GRANITE) {
            return new int[] {Realm.RES_STONE, 1};
        }
        if (item == Items.IRON_INGOT || item == Items.RAW_IRON) {
            return new int[] {Realm.RES_IRON, 1};
        }
        if (item == Items.COAL || item == Items.CHARCOAL) {
            return new int[] {Realm.RES_FUEL, 3};
        }
        if (item == ModItems.FUEL_CANISTER.get()) {
            return new int[] {Realm.RES_FUEL, 10};
        }
        if (item == Items.BREAD) {
            return new int[] {Realm.RES_FOOD, 5};
        }
        if (item == Items.WHEAT || item == Items.BEETROOT || item == Items.MELON_SLICE
                || item == Items.SWEET_BERRIES || item == Items.COOKIE) {
            return new int[] {Realm.RES_FOOD, 1};
        }
        if (item == Items.CARROT || item == Items.POTATO || item == Items.APPLE) {
            return new int[] {Realm.RES_FOOD, 2};
        }
        if (item == Items.BAKED_POTATO || item == Items.COOKED_CHICKEN || item == Items.COOKED_COD
                || item == Items.COOKED_SALMON) {
            return new int[] {Realm.RES_FOOD, 4};
        }
        if (item == Items.COOKED_BEEF || item == Items.COOKED_PORKCHOP || item == Items.COOKED_MUTTON
                || item == Items.PUMPKIN_PIE) {
            return new int[] {Realm.RES_FOOD, 6};
        }
        return null;
    }

    private static String deposit(ServerPlayer player, Realm r) {
        Inventory inv = player.getInventory();
        int items = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) {
                continue;
            }
            int[] rate = rate(s);
            if (rate == null) {
                continue;
            }
            r.add(rate[0], rate[1] * s.getCount());
            items += s.getCount();
            s.setCount(0);
        }
        if (items == 0) {
            return err("message.dynasty.deposit_none");
        }
        Fx.sound(player.level(), player.getX(), player.getY(), player.getZ(), "entity.item.pickup", 0.8F, 0.9F);
        return fmt("message.dynasty.deposited", String.valueOf(items));
    }

    private static String withdrawCoins(ServerPlayer player, Realm r, int amount) {
        int n = Math.max(1, Math.min(64, amount));
        if (r.coins < n) {
            return err("message.dynasty.not_enough");
        }
        r.add(Realm.RES_COINS, -n);
        give(player, new ItemStack(ModItems.COIN.get(), n));
        return fmt("message.dynasty.withdrawn", String.valueOf(n));
    }

    private static String withdrawFuel(ServerPlayer player, Realm r, int canisters) {
        int n = Math.max(1, Math.min(16, canisters));
        if (r.fuel < 10 * n) {
            return err("message.dynasty.not_enough");
        }
        r.add(Realm.RES_FUEL, -10 * n);
        give(player, new ItemStack(ModItems.FUEL_CANISTER.get(), n));
        return fmt("message.dynasty.fuel_withdrawn", String.valueOf(n));
    }

    private static String edictKey(int bit) {
        switch (bit) {
            case Realm.EDICT_MARTIAL_LAW:
                return "edict.dynasty.martial_law";
            case Realm.EDICT_FREE_TRADE:
                return "edict.dynasty.free_trade";
            default:
                return "edict.dynasty.patronage";
        }
    }

    private static String toggleEdict(Realm r, int bit) {
        if (bit != Realm.EDICT_MARTIAL_LAW && bit != Realm.EDICT_FREE_TRADE && bit != Realm.EDICT_PATRONAGE) {
            return "";
        }
        r.edicts ^= bit;
        return fmt(r.hasEdict(bit) ? "message.dynasty.edict_on" : "message.dynasty.edict_off", "@" + edictKey(bit));
    }

    private static String diplomacy(Realm r, int f, int action) {
        if (f < 0 || f >= Faction.COUNT) {
            return "";
        }
        String name = "@" + Faction.nameKey(f);
        switch (action) {
            case DIPLO_GIFT:
                if (r.status[f] == Faction.STATUS_WAR) {
                    return err("message.dynasty.at_war_with", name);
                }
                if (r.coins < 50) {
                    return err("message.dynasty.not_enough");
                }
                r.add(Realm.RES_COINS, -50);
                r.relation[f] = Math.min(100, r.relation[f] + 10);
                return fmt("message.dynasty.gift_sent", name);
            case DIPLO_TRADE:
                if (r.status[f] != Faction.STATUS_NONE) {
                    return err("message.dynasty.diplo_bad_state");
                }
                if (r.relation[f] < 10) {
                    return err("message.dynasty.relation_low");
                }
                r.status[f] = Faction.STATUS_TRADE;
                r.relation[f] = Math.min(100, r.relation[f] + 5);
                return fmt("message.dynasty.trade_signed", name);
            case DIPLO_ALLIANCE:
                if (r.status[f] != Faction.STATUS_TRADE) {
                    return err("message.dynasty.diplo_bad_state");
                }
                if (r.relation[f] < 50) {
                    return err("message.dynasty.relation_low");
                }
                if (r.coins < 100) {
                    return err("message.dynasty.not_enough");
                }
                r.add(Realm.RES_COINS, -100);
                r.status[f] = Faction.STATUS_ALLIANCE;
                r.prestige += 2;
                return fmt("message.dynasty.alliance_signed", name);
            case DIPLO_WAR:
                if (r.status[f] == Faction.STATUS_WAR) {
                    return err("message.dynasty.diplo_bad_state");
                }
                r.status[f] = Faction.STATUS_WAR;
                r.relation[f] = Math.max(-100, r.relation[f] - 50);
                return fmt("message.dynasty.war_declared", name);
            case DIPLO_PEACE:
                if (r.status[f] != Faction.STATUS_WAR) {
                    return err("message.dynasty.diplo_bad_state");
                }
                if (r.coins < 80) {
                    return err("message.dynasty.not_enough");
                }
                r.add(Realm.RES_COINS, -80);
                r.status[f] = Faction.STATUS_NONE;
                r.relation[f] = Math.max(r.relation[f], -20);
                return fmt("message.dynasty.peace_signed", name);
            default:
                return "";
        }
    }

    // ---- the daily cycle -----------------------------------------------------------------

    /** Called every few seconds from the server tick. */
    public static void tick(MinecraftServer server) {
        RealmData data = RealmData.get(server);
        long today = today(server);
        for (Realm r : data.all()) {
            if (!r.hasHall()) {
                continue;
            }
            if (r.lastDay == Long.MIN_VALUE || r.lastDay > today) {
                r.lastDay = today;
                data.setDirty();
                continue;
            }
            int guard = 0;
            while (r.lastDay < today && guard < 5) {
                r.lastDay++;
                guard++;
                processDay(server, data, r);
            }
            if (r.lastDay < today) {
                r.lastDay = today;
            }
        }
    }

    /** Runs one realm day (also used by the admin command). */
    public static void processDay(MinecraftServer server, RealmData data, Realm r) {
        ServerLevel level = RealmWorld.levelOf(server, r);
        if (level == null || r.hall == null) {
            return;
        }
        boolean loaded = level.isLoaded(r.hall);
        ServerPlayer owner = server.getPlayerList().getPlayer(r.owner);
        RandomSource rng = level.getRandom();
        long today = r.lastDay;

        r.report.clear();
        r.day++;

        if (loaded) {
            resolveRaid(server, r);
            RealmWorld.census(server, r);
        }

        // --- economy
        Economy e = Economy.compute(r);
        int[] gain = e.income();
        int coinsBefore = r.coins;
        int foodBefore = r.food;
        for (int i = 0; i < Realm.RES_COUNT; i++) {
            r.add(i, gain[i]);
        }
        boolean unpaid = false;
        if (r.coins >= e.upkeepCoins) {
            r.add(Realm.RES_COINS, -e.upkeepCoins);
        } else {
            r.coins = 0;
            unpaid = true;
        }
        boolean famine = false;
        if (r.food >= e.upkeepFood) {
            r.add(Realm.RES_FOOD, -e.upkeepFood);
        } else {
            r.food = 0;
            famine = true;
        }
        addReport(r, "report.dynasty.balance", signed(r.coins - coinsBefore), signed(r.food - foodBefore),
                signed(gain[Realm.RES_WOOD]), signed(gain[Realm.RES_STONE]), signed(gain[Realm.RES_IRON]));

        if (unpaid && r.soldiers() > 0) {
            addReport(r, "report.dynasty.wages_unpaid");
            if (Config.DESERTION.get() && loaded) {
                desertOne(server, level, r);
            }
        }
        if (famine) {
            addReport(r, "report.dynasty.famine");
        }

        updateHappiness(r, famine, unpaid);

        // --- research
        r.progress += e.sciencePoints();
        Tech current = Tech.byId(r.researching);
        if (current != null) {
            if (r.has(current)) {
                r.researching = "";
            } else if (r.progress >= current.cost) {
                r.progress -= current.cost;
                r.techs.add(current.id);
                r.researching = "";
                r.prestige += current.era;
                addReport(r, "report.dynasty.tech_done", "@" + current.nameKey());
                chat(owner, "message.dynasty.tech_done", Component.translatable(current.nameKey()));
            }
        }

        diplomacyDay(r, rng);

        if (loaded) {
            immigration(level, r, rng);
            familyDay(server, level, r, today, rng, owner);
            RealmWorld.census(server, r);
        }

        randomEvent(level, r, rng, loaded);

        if (loaded) {
            maybeRaid(server, level, r, rng, owner);
        }

        data.setDirty();
        if (owner != null) {
            msg(owner, "message.dynasty.new_day", r.day, signed(r.coins - coinsBefore), signed(r.food - foodBefore));
        }
    }

    private static String signed(int v) {
        return v >= 0 ? "+" + v : String.valueOf(v);
    }

    private static void updateHappiness(Realm r, boolean famine, boolean unpaid) {
        int target = 55;
        target += Math.min(25, 5 * r.levelSum(BuildingType.TAVERN));
        if (r.has(Tech.MEDICINE)) {
            target += 5;
        }
        if (r.hasEdict(Realm.EDICT_PATRONAGE)) {
            target += 10;
        }
        if (r.hasEdict(Realm.EDICT_MARTIAL_LAW)) {
            target -= 10;
        }
        if (r.hasEdict(Realm.EDICT_FREE_TRADE)) {
            target -= 5;
        }
        if (r.spouse != null) {
            target += 5;
        }
        if (r.atWar()) {
            target -= 10;
        }
        if (r.hasAlliance()) {
            target += 3;
        }
        int people = r.population + r.babies;
        if (people > r.capacity()) {
            target -= Math.min(25, (people - r.capacity()) * 4);
        }
        if (famine) {
            target -= 25;
        }
        if (unpaid) {
            target -= 5;
        }
        if (r.food > 100) {
            target += 5;
        }
        target = Math.max(0, Math.min(100, target));
        if (r.happiness < target) {
            r.happiness = Math.min(target, r.happiness + 4);
        } else if (r.happiness > target) {
            r.happiness = Math.max(target, r.happiness - 4);
        }
    }

    private static void desertOne(MinecraftServer server, ServerLevel level, Realm r) {
        for (SoldierEntity s : level.getEntitiesOfClass(SoldierEntity.class,
                new net.minecraft.world.phys.AABB(r.hall).inflate(Config.REALM_RADIUS.get() + 32),
                e -> e.isAlive() && r.owner.equals(e.getOwnerId()))) {
            String name = s.getDisplayName().getString();
            s.discard();
            addReport(r, "report.dynasty.desertion", name);
            return;
        }
    }

    private static void diplomacyDay(Realm r, RandomSource rng) {
        for (int i = 0; i < Faction.COUNT; i++) {
            switch (r.status[i]) {
                case Faction.STATUS_TRADE:
                case Faction.STATUS_ALLIANCE:
                    r.relation[i] = Math.min(100, r.relation[i] + 1);
                    break;
                case Faction.STATUS_WAR:
                    r.relation[i] = Math.max(-100, r.relation[i] - 1);
                    break;
                default:
                    if (r.relation[i] > 0) {
                        r.relation[i]--;
                    } else if (r.relation[i] < 0) {
                        r.relation[i]++;
                    }
                    break;
            }
            if (r.status[i] == Faction.STATUS_NONE && r.relation[i] <= -60 && rng.nextInt(10) == 0) {
                r.status[i] = Faction.STATUS_WAR;
                addReport(r, "report.dynasty.faction_war", "@" + Faction.nameKey(i));
            }
        }
    }

    private static void immigration(ServerLevel level, Realm r, RandomSource rng) {
        int people = r.population + r.babies;
        int room = r.capacity() - people;
        if (room <= 0 || r.food < 20 || r.happiness < 40 || rng.nextInt(100) >= 70) {
            return;
        }
        int n = Math.min(room, 1 + (r.count(BuildingType.TAVERN) > 0 ? 1 : 0) + (r.count(BuildingType.MARKET) > 0 ? 1 : 0));
        int arrived = 0;
        for (int i = 0; i < n; i++) {
            CitizenEntity c = RealmWorld.spawnCitizen(level, r, r.hall, 6, 18, RealmWorld.pickProfession(r, rng));
            if (c != null) {
                arrived++;
            }
        }
        if (arrived > 0) {
            addReport(r, "report.dynasty.immigrants", String.valueOf(arrived));
        }
    }

    // ---- family --------------------------------------------------------------------------

    private static void familyDay(MinecraftServer server, ServerLevel level, Realm r, long today, RandomSource rng,
                                  @Nullable ServerPlayer owner) {
        List<CitizenEntity> citizens = RealmWorld.ownedCitizens(level, r);
        int adults = 0;
        int babies = 0;
        for (CitizenEntity c : citizens) {
            c.dailyUpdate(today);
            if (c.isBaby()) {
                babies++;
            } else {
                adults++;
            }
        }
        int room = r.capacity() - (adults + babies);

        // the ruler's own children
        if (r.spouse != null && room > 0 && r.happiness >= 40 && r.childrenBorn < 12) {
            Entity se = level.getEntity(r.spouse);
            if (se instanceof CitizenEntity spouse && spouse.isAlive() && !spouse.isBaby()
                    && spouse.getPartnerKind() == CitizenEntity.PARTNER_PLAYER) {
                double chance = 0.22D + 0.04D * Math.min(5, r.levelSum(BuildingType.TAVERN)) + (r.has(Tech.MEDICINE) ? 0.06D : 0.0D);
                if (today - spouse.getLastBirthDay() >= 3L && rng.nextDouble() < chance) {
                    CitizenEntity baby = RealmWorld.spawnBaby(level, r, spouse.blockPosition(), r.ownerName,
                            spouse.displayName(), r.generation + 1, true);
                    if (baby != null) {
                        spouse.setLastBirthDay(today);
                        r.childrenBorn++;
                        String babyName = baby.displayName();
                        r.family.add(babyName);
                        while (r.family.size() > 24) {
                            r.family.remove(0);
                        }
                        room--;
                        Fx.hearts(level, spouse);
                        addReport(r, "report.dynasty.child_born", babyName);
                        chat(owner, "message.dynasty.child_born", Component.literal(babyName));
                    }
                }
            }
        }

        // singles marry each other
        CitizenEntity bride = null;
        CitizenEntity groom = null;
        for (CitizenEntity c : citizens) {
            if (c.isBaby() || c.getPartnerKind() != CitizenEntity.PARTNER_NONE || c.getAffection() >= 50 || c.isDating()) {
                continue;
            }
            if (c.isFemale() && bride == null) {
                bride = c;
            } else if (!c.isFemale() && groom == null) {
                groom = c;
            }
        }
        if (bride != null && groom != null && rng.nextInt(100) < 30 && bride.distanceToSqr(groom) < 40.0D * 40.0D) {
            bride.setPartnerCitizen(groom, today);
            groom.setPartnerCitizen(bride, today);
            Fx.hearts(level, bride);
            Fx.hearts(level, groom);
            addReport(r, "report.dynasty.wedding_citizens", bride.displayName(), groom.displayName());
        }

        // citizen couples have children
        for (CitizenEntity mother : citizens) {
            if (room <= 0) {
                break;
            }
            if (!mother.isFemale() || mother.isBaby() || mother.getPartnerKind() != CitizenEntity.PARTNER_CITIZEN
                    || today - mother.getLastBirthDay() < 4L || rng.nextInt(100) >= 12) {
                continue;
            }
            Entity pe = RealmWorld.find(level, mother.getPartnerId());
            if (pe instanceof CitizenEntity father && father.isAlive()) {
                CitizenEntity baby = RealmWorld.spawnBaby(level, r, mother.blockPosition(), mother.displayName(),
                        father.displayName(), Math.max(mother.getGeneration(), father.getGeneration()) + 1, false);
                if (baby != null) {
                    mother.setLastBirthDay(today);
                    room--;
                    Fx.hearts(level, mother);
                    addReport(r, "report.dynasty.child_born_citizen", mother.displayName());
                }
            }
        }
    }

    /** A child of the realm has grown up. */
    public static void onChildGrown(CitizenEntity c) {
        if (!(c.level() instanceof ServerLevel level) || c.getOwnerId() == null) {
            return;
        }
        MinecraftServer server = level.getServer();
        RealmData data = RealmData.get(server);
        Realm r = data.getRealm(c.getOwnerId());
        if (r == null) {
            return;
        }
        ServerPlayer owner = server.getPlayerList().getPlayer(r.owner);
        if (c.isPlayerChild()) {
            r.adultChildren++;
            r.prestige += 1;
            if (r.heirName.isEmpty()) {
                r.heirName = c.displayName();
            }
            chat(owner, "message.dynasty.child_grown", Component.literal(c.displayName()));
        }
        addReport(r, "report.dynasty.child_grown", c.displayName());
        data.setDirty();
    }

    /** The ruler died: the heir (if any) takes over the dynasty. */
    public static void onRulerDeath(ServerPlayer player) {
        RealmData data = RealmData.get(player.server);
        Realm r = data.getRealm(player.getUUID());
        if (r == null || !r.hasHall()) {
            return;
        }
        if (r.adultChildren > 0) {
            r.adultChildren--;
            r.generation++;
            r.prestige += 3;
            String heir = r.heirName.isEmpty() ? "?" : r.heirName;
            if (r.adultChildren == 0) {
                r.heirName = "";
            }
            chat(player, "message.dynasty.succession", Component.literal(heir), r.generation);
        } else {
            r.prestige = Math.max(0, r.prestige - 3);
            r.happiness = Math.max(0, r.happiness - 15);
            chat(player, "message.dynasty.no_heir");
        }
        data.setDirty();
    }

    /** A citizen died: if it was the ruler's spouse, the ruler is widowed. */
    public static void onCitizenDied(CitizenEntity c) {
        if (!(c.level() instanceof ServerLevel level) || c.getOwnerId() == null) {
            return;
        }
        MinecraftServer server = level.getServer();
        RealmData data = RealmData.get(server);
        Realm r = data.getRealm(c.getOwnerId());
        if (r == null || r.spouse == null || !r.spouse.equals(c.getUUID())) {
            return;
        }
        r.spouse = null;
        r.spouseName = "";
        r.happiness = Math.max(0, r.happiness - 15);
        chat(server.getPlayerList().getPlayer(r.owner), "message.dynasty.spouse_died", Component.literal(c.displayName()));
        data.setDirty();
    }

    // ---- events and raids ----------------------------------------------------------------

    private static void randomEvent(ServerLevel level, Realm r, RandomSource rng, boolean loaded) {
        if (rng.nextInt(100) >= 22) {
            return;
        }
        switch (rng.nextInt(8)) {
            case 0:
                if (r.count(BuildingType.FARM) > 0) {
                    int n = 30 + rng.nextInt(50);
                    r.add(Realm.RES_FOOD, n);
                    addReport(r, "report.dynasty.event_harvest", String.valueOf(n));
                }
                break;
            case 1:
                if (r.count(BuildingType.MARKET) > 0 || r.has(Tech.TRADE)) {
                    int n = 50 + rng.nextInt(80);
                    r.add(Realm.RES_COINS, n);
                    addReport(r, "report.dynasty.event_caravan", String.valueOf(n));
                }
                break;
            case 2:
                if (r.has(Tech.MEDICINE)) {
                    addReport(r, "report.dynasty.event_plague_healed");
                } else {
                    r.happiness = Math.max(0, r.happiness - 8);
                    r.add(Realm.RES_FOOD, -15);
                    addReport(r, "report.dynasty.event_plague");
                }
                break;
            case 3:
                if (r.coins >= 40) {
                    r.add(Realm.RES_COINS, -40);
                    r.happiness = Math.min(100, r.happiness + 12);
                    r.prestige += 1;
                    addReport(r, "report.dynasty.event_festival");
                }
                break;
            case 4:
                if (r.count(BuildingType.QUARRY) > 0) {
                    int iron = 8 + rng.nextInt(8);
                    r.add(Realm.RES_STONE, 30);
                    r.add(Realm.RES_IRON, iron);
                    addReport(r, "report.dynasty.event_ore", String.valueOf(iron));
                }
                break;
            case 5:
                if (r.count(BuildingType.WATCHTOWER) > 0 || r.soldiers() >= 4) {
                    addReport(r, "report.dynasty.event_thieves_caught");
                } else {
                    int n = Math.min(r.coins, 30 + rng.nextInt(30));
                    r.add(Realm.RES_COINS, -n);
                    addReport(r, "report.dynasty.event_thieves", String.valueOf(n));
                }
                break;
            case 6: {
                int f = rng.nextInt(Faction.COUNT);
                if (r.status[f] != Faction.STATUS_WAR) {
                    r.relation[f] = Math.min(100, r.relation[f] + 10);
                    addReport(r, "report.dynasty.event_envoy", "@" + Faction.nameKey(f));
                }
                break;
            }
            default:
                if (loaded && r.population + r.babies < r.capacity()) {
                    CitizenEntity c = RealmWorld.spawnCitizen(level, r, r.hall, 6, 16, RealmWorld.pickProfession(r, rng));
                    if (c != null) {
                        addReport(r, "report.dynasty.event_wanderer", c.displayName());
                    }
                }
                break;
        }
    }

    private static void maybeRaid(MinecraftServer server, ServerLevel level, Realm r, RandomSource rng,
                                  @Nullable ServerPlayer owner) {
        if (r.raidCooldown > 0) {
            r.raidCooldown--;
            return;
        }
        if (!Config.RAIDS.get() || r.raidSize > 0 || r.day < 4) {
            return;
        }
        double chance = (0.14D + (r.atWar() ? 0.22D : 0.0D)) * Config.RAID_FREQUENCY.get();
        if (r.hasAlliance()) {
            chance *= 0.7D;
        }
        if (rng.nextDouble() >= chance) {
            return;
        }
        double deterrence = Math.min(0.6D, r.defense() / 250.0D);
        if (rng.nextDouble() < deterrence) {
            addReport(r, "report.dynasty.raid_deterred");
            r.raidCooldown = 1;
            return;
        }
        startRaid(level, r, rng, owner);
    }

    /** Starts a raid right now (also used by the admin command). */
    public static boolean startRaid(ServerLevel level, Realm r, RandomSource rng, @Nullable ServerPlayer owner) {
        if (r.hall == null || r.raidSize > 0) {
            return false;
        }
        int size = Math.min(16, 2 + r.day / 7 + (r.atWar() ? 2 : 0) + rng.nextInt(3));
        RealmWorld.Raid raid = RealmWorld.spawnRaid(level, r, size);
        if (raid.count() <= 0) {
            return false;
        }
        r.raidSize = raid.count();
        r.raidKills = 0;
        r.raidCooldown = 2 + rng.nextInt(3);
        String direction = RealmWorld.directionKey(r.hall, raid.base());
        addReport(r, "report.dynasty.raid_warning", String.valueOf(raid.count()), "@" + direction);
        chat(owner, "message.dynasty.raid_incoming", raid.count(), Component.translatable(direction));
        if (owner != null) {
            Fx.sound(owner.level(), owner.getX(), owner.getY(), owner.getZ(), "event.raid.horn", 2.0F, 1.0F);
        }
        return true;
    }

    private static void resolveRaid(MinecraftServer server, Realm r) {
        if (r.raidSize <= 0) {
            return;
        }
        List<BanditEntity> alive = RealmWorld.raiders(server, r);
        if (alive.isEmpty()) {
            addReport(r, "report.dynasty.raid_gone");
        } else {
            int loot = Math.min(r.coins, 20 + r.coins / 10);
            r.add(Realm.RES_COINS, -loot);
            r.happiness = Math.max(0, r.happiness - 8);
            for (BanditEntity b : alive) {
                b.discard();
            }
            addReport(r, "report.dynasty.raid_looted", String.valueOf(loot));
        }
        r.raidSize = 0;
        r.raidKills = 0;
    }

    /** A raider died; if it was the last one the raid is repelled. */
    public static void onBanditKilled(BanditEntity b) {
        UUID id = b.getRealmOwner();
        if (id == null || !(b.level() instanceof ServerLevel level)) {
            return;
        }
        MinecraftServer server = level.getServer();
        RealmData data = RealmData.get(server);
        Realm r = data.getRealm(id);
        if (r == null || r.raidSize <= 0) {
            return;
        }
        r.raidKills++;
        if (r.raidKills >= r.raidSize) {
            int size = r.raidSize;
            int reward = 20 + 8 * size;
            r.add(Realm.RES_COINS, reward);
            r.prestige += 1;
            r.happiness = Math.min(100, r.happiness + 5);
            r.raidSize = 0;
            r.raidKills = 0;
            addReport(r, "report.dynasty.raid_repelled", String.valueOf(size), String.valueOf(reward));
            chat(server.getPlayerList().getPlayer(r.owner), "message.dynasty.raid_repelled", size, reward);
        }
        data.setDirty();
    }

    // ---- player events -------------------------------------------------------------------

    public static void onLogin(ServerPlayer player) {
        Realm r = realmOf(player.server, player.getUUID());
        if (r == null || !r.hasHall()) {
            player.sendSystemMessage(Component.translatable("message.dynasty.welcome"));
        } else {
            player.sendSystemMessage(Component.translatable("message.dynasty.welcome_back", r.day, r.coins));
        }
    }
}
