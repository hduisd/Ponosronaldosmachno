package com.dynasty.realm;

import com.dynasty.Config;

/** Projected (or actually applied) daily balance of a realm. */
public final class Economy {
    public double coins;
    public double food;
    public double wood;
    public double stone;
    public double iron;
    public double fuel;
    public double science;

    public int upkeepCoins;
    public int upkeepFood;

    public int[] income() {
        return new int[] {
            (int) Math.round(coins), (int) Math.round(food), (int) Math.round(wood),
            (int) Math.round(stone), (int) Math.round(iron), (int) Math.round(fuel)
        };
    }

    public int sciencePoints() {
        return (int) Math.round(science);
    }

    public static Economy compute(Realm r) {
        Economy e = new Economy();
        double agri = r.has(Tech.AGRICULTURE) ? 1.5 : 1.0;
        double ind = r.has(Tech.INDUSTRY) ? 1.25 : 1.0;
        double masonry = r.has(Tech.MASONRY) ? 1.5 : 1.0;
        double steel = r.has(Tech.STEELWORKING) ? 2.0 : 1.0;
        double trade = r.has(Tech.TRADE) ? 1.5 : 1.0;
        double edu = r.has(Tech.EDUCATION) ? 1.5 : 1.0;
        double elec = r.has(Tech.ELECTRICITY) ? 1.15 : 1.0;

        int hall = r.hall == null ? 0 : r.levelSum(BuildingType.TOWN_HALL);
        int farm = r.levelSum(BuildingType.FARM);
        int lumber = r.levelSum(BuildingType.LUMBER_CAMP);
        int quarry = r.levelSum(BuildingType.QUARRY);
        int market = r.levelSum(BuildingType.MARKET);
        int academy = r.levelSum(BuildingType.ACADEMY);
        int refinery = r.levelSum(BuildingType.REFINERY);

        e.coins += 5 * hall;
        e.science += hall;
        e.food += 6 * farm * agri * ind;
        e.wood += 5 * lumber * ind;
        e.stone += 4 * quarry * masonry * ind;
        e.iron += quarry * steel;
        e.coins += 6 * market * trade;
        e.science += 3 * academy * edu * elec;
        if (r.has(Tech.OIL)) {
            e.fuel += 4 * refinery;
        }

        int pop = r.population;
        double happy = 0.6 + r.happiness / 125.0;
        double tax = pop * 2 * happy * (r.has(Tech.TRADE) ? 1.25 : 1.0) * (r.hasEdict(Realm.EDICT_FREE_TRADE) ? 1.25 : 1.0);
        e.coins += tax;

        e.food += r.jobs[Profession.FARMER.ordinal()] * (farm > 0 ? 3 : 1) * agri;
        e.wood += r.jobs[Profession.LUMBERJACK.ordinal()] * (lumber > 0 ? 3 : 1);
        int miners = r.jobs[Profession.MINER.ordinal()];
        e.stone += miners * (quarry > 0 ? 2 : 0.5);
        e.iron += miners * (quarry > 0 ? 0.5 : 0.0);
        e.coins += r.jobs[Profession.MERCHANT.ordinal()] * (market > 0 ? 4 : 1) * trade;
        e.science += r.jobs[Profession.SCHOLAR.ordinal()] * (academy > 0 ? 2 : 0.5) * edu;

        if (r.has(Tech.BANKING)) {
            e.coins += Math.min(20.0, r.coins * 0.01);
        }
        for (int i = 0; i < Faction.COUNT; i++) {
            if (r.status[i] == Faction.STATUS_TRADE) {
                e.coins += 8;
            } else if (r.status[i] == Faction.STATUS_ALLIANCE) {
                e.coins += 3;
            }
        }

        double mult = 1.0 + 0.02 * r.prestige + (r.spouse != null ? 0.10 : 0.0);
        e.coins *= mult;
        e.science *= mult;
        e.science *= Config.RESEARCH_SPEED.get();

        double up = 0;
        SoldierType[] types = SoldierType.values();
        for (int i = 0; i < types.length; i++) {
            up += r.soldierCounts[i] * types[i].upkeep;
        }
        if (r.hasEdict(Realm.EDICT_MARTIAL_LAW)) {
            up *= 0.7;
        }
        if (r.hasEdict(Realm.EDICT_PATRONAGE)) {
            up += 10;
        }
        e.upkeepCoins = (int) Math.round(up);
        e.upkeepFood = pop + r.soldiers();
        return e;
    }
}
