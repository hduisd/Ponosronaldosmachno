package com.dynasty.realm;

/** Jobs of citizens. */
public enum Profession {
    PEASANT("peasant"),
    FARMER("farmer"),
    LUMBERJACK("lumberjack"),
    MINER("miner"),
    MERCHANT("merchant"),
    SCHOLAR("scholar");

    public final String id;

    Profession(String id) {
        this.id = id;
    }

    public String nameKey() {
        return "profession.dynasty." + id;
    }

    public Profession next() {
        Profession[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public static Profession byIndex(int i) {
        Profession[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
