package com.dynasty.realm;

/** A registered building of a realm (position is the key in {@link Realm#buildings}). */
public final class Building {
    public final BuildingType type;
    public int level;

    public Building(BuildingType type, int level) {
        this.type = type;
        this.level = level;
    }
}
