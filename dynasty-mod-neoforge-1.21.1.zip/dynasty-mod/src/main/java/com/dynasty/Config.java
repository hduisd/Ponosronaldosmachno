package com.dynasty;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Common (server-side) configuration of the Dynasty mod. */
public class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.IntValue REALM_RADIUS = BUILDER
            .comment("Radius (in blocks) around the Town Hall in which buildings belong to the realm")
            .defineInRange("realmRadius", 64, 16, 256);

    public static final ModConfigSpec.BooleanValue REQUIRE_TECH = BUILDER
            .comment("If true, weapons, vehicles and recruits require the matching technology (creative players ignore this)")
            .define("requireTech", true);

    public static final ModConfigSpec.BooleanValue RAIDS = BUILDER
            .comment("Enable bandit raids on realms")
            .define("raidsEnabled", true);

    public static final ModConfigSpec.DoubleValue RAID_FREQUENCY = BUILDER
            .comment("Multiplier for the daily chance of a raid")
            .defineInRange("raidFrequency", 1.0D, 0.0D, 5.0D);

    public static final ModConfigSpec.BooleanValue DESERTION = BUILDER
            .comment("If true, soldiers desert when the realm cannot pay their wages")
            .define("soldierDesertion", true);

    public static final ModConfigSpec.IntValue CHILD_DAYS = BUILDER
            .comment("How many Minecraft days it takes for a child to grow up")
            .defineInRange("childGrowthDays", 2, 1, 10);

    public static final ModConfigSpec.DoubleValue RESEARCH_SPEED = BUILDER
            .comment("Multiplier for research points gained per day")
            .defineInRange("researchSpeed", 1.0D, 0.1D, 10.0D);

    public static final ModConfigSpec SPEC = BUILDER.build();

    private Config() {}
}
