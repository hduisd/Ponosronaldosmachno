package com.dynasty.item;

import java.util.List;

import com.dynasty.entity.VehicleEntity;
import com.dynasty.entity.VehicleKind;
import com.dynasty.realm.TechGate;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Places a vehicle into the world. */
public class VehicleItem extends Item {
    private final VehicleKind kind;

    public VehicleItem(Properties properties, VehicleKind kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        Player player = context.getPlayer();
        if (player != null && !TechGate.allowed(player, kind.tech)) {
            TechGate.deny(player, kind.tech);
            return InteractionResult.FAIL;
        }
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        VehicleEntity vehicle = kind.entityType().create(level);
        if (vehicle == null) {
            return InteractionResult.FAIL;
        }
        vehicle.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, player == null ? 0.0F : player.getYRot(), 0.0F);
        if (player != null) {
            vehicle.setOwner(player.getUUID());
        }
        if (kind.usesFuel) {
            vehicle.setFuel(2400);
        }
        level.addFreshEntity(vehicle);
        if (player == null || !player.getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dynasty.vehicle.place"));
        if (kind.usesFuel) {
            tooltip.add(Component.translatable("tooltip.dynasty.vehicle.fuel"));
        }
        if (kind.hasCannon) {
            tooltip.add(Component.translatable("tooltip.dynasty.vehicle.cannon"));
        }
        if (kind.tech != null) {
            tooltip.add(Component.translatable("tooltip.dynasty.requires_tech", Component.translatable(kind.tech.nameKey())));
        }
    }
}
