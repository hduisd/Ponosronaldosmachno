package com.dynasty.item;

import java.util.List;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.dynasty.entity.BulletEntity;
import com.dynasty.realm.Tech;
import com.dynasty.realm.TechGate;
import com.dynasty.util.Fx;
import com.dynasty.util.ItemUtil;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/** A firearm: consumes ammo from the inventory and shoots a {@link BulletEntity}. */
public class GunItem extends Item {
    private final Tech tech;
    private final Supplier<Item> ammo;
    private final BulletEntity.Kind kind;
    private final float damage;
    private final int cooldown;
    private final float inaccuracy;
    private final float velocity;
    private final boolean automatic;
    private final String sound;
    private final float pitch;

    public GunItem(Properties properties, @Nullable Tech tech, Supplier<Item> ammo, BulletEntity.Kind kind,
                   float damage, int cooldown, float inaccuracy, float velocity, boolean automatic,
                   String sound, float pitch) {
        super(properties);
        this.tech = tech;
        this.ammo = ammo;
        this.kind = kind;
        this.damage = damage;
        this.cooldown = cooldown;
        this.inaccuracy = inaccuracy;
        this.velocity = velocity;
        this.automatic = automatic;
        this.sound = sound;
        this.pitch = pitch;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (automatic) {
            if (!player.getAbilities().instabuild && ItemUtil.count(player, ammo.get()) <= 0) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable("message.dynasty.no_ammo", ammo.get().getDescription()), true);
                }
                return InteractionResultHolder.fail(stack);
            }
            player.startUsingItem(hand);
            return InteractionResultHolder.consume(stack);
        }
        if (fire(level, player, true)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        return InteractionResultHolder.fail(stack);
    }

    private boolean fire(Level level, Player player, boolean addCooldown) {
        boolean creative = player.getAbilities().instabuild;
        if (!creative && ItemUtil.count(player, ammo.get()) <= 0) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.dynasty.no_ammo", ammo.get().getDescription()), true);
            }
            return false;
        }
        if (level.isClientSide) {
            return true;
        }
        if (!TechGate.allowed(player, tech)) {
            TechGate.deny(player, tech);
            return false;
        }
        if (!creative) {
            ItemUtil.consume(player, ammo.get(), 1);
        }
        BulletEntity bullet = new BulletEntity(level, player);
        bullet.configure(kind, damage);
        bullet.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, velocity, inaccuracy);
        level.addFreshEntity(bullet);
        Fx.sound(level, player.getX(), player.getEyeY(), player.getZ(), sound, 1.0F, pitch);
        if (addCooldown) {
            player.getCooldowns().addCooldown(this, cooldown);
        }
        return true;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return automatic ? 72000 : 0;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return automatic ? UseAnim.CROSSBOW : UseAnim.NONE;
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remainingUseDuration) {
        if (level.isClientSide || !automatic || !(entity instanceof Player player)) {
            return;
        }
        int used = getUseDuration(stack, entity) - remainingUseDuration;
        if (used % Math.max(1, cooldown) == 0) {
            if (!fire(level, player, false)) {
                player.stopUsingItem();
            }
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dynasty.gun.damage", String.format("%.1f", damage)));
        tooltip.add(Component.translatable("tooltip.dynasty.gun.ammo", ammo.get().getDescription()));
        if (tech != null) {
            tooltip.add(Component.translatable("tooltip.dynasty.requires_tech", Component.translatable(tech.nameKey())));
        }
    }
}
