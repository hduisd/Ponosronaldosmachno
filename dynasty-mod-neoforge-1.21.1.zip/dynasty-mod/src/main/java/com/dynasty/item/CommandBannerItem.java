package com.dynasty.item;

import java.util.List;

import com.dynasty.entity.BanditEntity;
import com.dynasty.entity.SoldierEntity;
import com.dynasty.realm.Realm;
import com.dynasty.realm.RealmData;
import com.dynasty.realm.Tech;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * Orders for the soldiers of the owner:
 * right click in the air = follow me, sneak + right click = hold this position,
 * right click on a block = hold that block, right click on an enemy = attack it.
 */
public class CommandBannerItem extends Item {
    public CommandBannerItem(Properties properties) {
        super(properties);
    }

    private static int range(Player player) {
        if (player.getServer() != null) {
            Realm r = RealmData.get(player.getServer()).getRealm(player.getUUID());
            if (r != null && r.has(Tech.RADIO)) {
                return 128;
            }
        }
        return 64;
    }

    private static List<SoldierEntity> soldiers(Player player) {
        double r = range(player);
        return player.level().getEntitiesOfClass(SoldierEntity.class, player.getBoundingBox().inflate(r),
                s -> player.getUUID().equals(s.getOwnerId()));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }
        List<SoldierEntity> list = soldiers(player);
        if (player.isShiftKeyDown()) {
            BlockPos pos = player.blockPosition();
            for (SoldierEntity s : list) {
                s.orderPost(pos);
            }
            player.displayClientMessage(Component.translatable("message.dynasty.order_post", list.size()), true);
        } else {
            for (SoldierEntity s : list) {
                s.orderFollow();
            }
            player.displayClientMessage(Component.translatable("message.dynasty.order_follow", list.size()), true);
        }
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (level.isClientSide || player == null) {
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        BlockPos pos = context.getClickedPos().above();
        List<SoldierEntity> list = soldiers(player);
        for (SoldierEntity s : list) {
            s.orderPost(pos);
        }
        player.displayClientMessage(Component.translatable("message.dynasty.order_post", list.size()), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (target instanceof Enemy || target instanceof BanditEntity) {
            List<SoldierEntity> list = soldiers(player);
            for (SoldierEntity s : list) {
                s.setTarget(target);
            }
            player.displayClientMessage(Component.translatable("message.dynasty.order_attack", list.size()), true);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dynasty.banner.1"));
        tooltip.add(Component.translatable("tooltip.dynasty.banner.2"));
        tooltip.add(Component.translatable("tooltip.dynasty.banner.3"));
    }
}
