package com.dynasty.item;

import java.util.List;

import com.dynasty.entity.BulletEntity;
import com.dynasty.realm.Tech;
import com.dynasty.realm.TechGate;
import com.dynasty.util.Fx;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** A hand grenade that explodes on impact (no block damage). */
public class GrenadeItem extends Item {
    public GrenadeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) {
            if (!TechGate.allowed(player, Tech.GUNPOWDER)) {
                TechGate.deny(player, Tech.GUNPOWDER);
                return InteractionResultHolder.fail(stack);
            }
            BulletEntity grenade = new BulletEntity(level, player);
            grenade.configure(BulletEntity.Kind.GRENADE, 10.0F);
            grenade.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.1F, 1.0F);
            level.addFreshEntity(grenade);
            Fx.sound(level, player.getX(), player.getEyeY(), player.getZ(), "entity.snowball.throw", 0.7F, 0.6F);
            player.getCooldowns().addCooldown(this, 20);
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dynasty.grenade"));
        tooltip.add(Component.translatable("tooltip.dynasty.requires_tech", Component.translatable(Tech.GUNPOWDER.nameKey())));
    }
}
