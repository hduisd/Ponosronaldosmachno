package com.dynasty.block;

import javax.annotation.Nullable;

import com.dynasty.realm.BuildingType;
import com.dynasty.realm.RealmManager;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** A building of a realm. The block is registered with the realm of the player who places it. */
public class BuildingBlock extends Block {
    private final BuildingType type;

    public BuildingBlock(Properties properties, BuildingType type) {
        super(properties);
        this.type = type;
    }

    public BuildingType type() {
        return type;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        if (!context.getLevel().isClientSide && context.getPlayer() instanceof ServerPlayer player) {
            if (!RealmManager.canPlace(player, type, context.getClickedPos())) {
                return null;
            }
        }
        return super.getStateForPlacement(context);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide && level instanceof ServerLevel serverLevel && placer instanceof ServerPlayer player) {
            RealmManager.onBuildingPlaced(serverLevel, pos, type, player);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!level.isClientSide && level instanceof ServerLevel serverLevel && !state.is(newState.getBlock())) {
            RealmManager.onBuildingRemoved(serverLevel, pos, type);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer sp) {
            RealmManager.onBuildingUsed(sp, serverLevel, pos, type);
        }
        return InteractionResult.CONSUME;
    }
}
