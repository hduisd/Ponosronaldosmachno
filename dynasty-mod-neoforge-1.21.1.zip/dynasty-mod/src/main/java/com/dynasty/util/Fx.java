package com.dynasty.util;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/** Small helpers for sounds and particles that only use registry ids. */
public final class Fx {
    private Fx() {}

    /** Plays a vanilla sound by its registry id (for example "entity.villager.yes"). */
    public static void sound(Level level, double x, double y, double z, String id, float volume, float pitch) {
        SoundEvent event = BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.fromNamespaceAndPath("minecraft", id));
        if (event != null) {
            level.playSound(null, x, y, z, event, SoundSource.NEUTRAL, volume, pitch);
        }
    }

    public static void sound(Entity entity, String id, float volume, float pitch) {
        sound(entity.level(), entity.getX(), entity.getY(), entity.getZ(), id, volume, pitch);
    }

    public static void particles(ServerLevel level, ParticleOptions type, double x, double y, double z, int count, double spread) {
        level.sendParticles(type, x, y, z, count, spread, spread, spread, 0.02D);
    }

    public static void hearts(ServerLevel level, Entity e) {
        particles(level, ParticleTypes.HEART, e.getX(), e.getY() + e.getBbHeight() + 0.3D, e.getZ(), 7, 0.4D);
    }

    public static void happy(ServerLevel level, Entity e) {
        particles(level, ParticleTypes.HAPPY_VILLAGER, e.getX(), e.getY() + e.getBbHeight() * 0.7D, e.getZ(), 8, 0.4D);
    }
}
