package com.dynasty.util;

import net.minecraft.util.RandomSource;

/** Random first names for citizens, soldiers and bandits. */
public final class Names {
    private static final String[] MALE = {
        "Богдан", "Тарас", "Остап", "Данило", "Ярослав", "Михайло", "Назар", "Левко", "Орест",
        "Святослав", "Іван", "Андрій", "Захар", "Максим", "Роман", "Олег", "Мирон", "Василь",
        "Стефан", "Лук'ян", "Григорій", "Юрій", "Дмитро", "Кирило", "Мар'ян", "Всеволод"
    };
    private static final String[] FEMALE = {
        "Соломія", "Оксана", "Леся", "Мар'яна", "Дарина", "Олена", "Софія", "Ярина", "Орися",
        "Устина", "Мирослава", "Катерина", "Галина", "Зоряна", "Христина", "Любава", "Злата",
        "Квітка", "Мілена", "Ольга", "Анастасія", "Вероніка", "Рута", "Влада", "Тетяна", "Єва"
    };

    private Names() {}

    public static String random(boolean female, RandomSource rng) {
        String[] a = female ? FEMALE : MALE;
        return a[rng.nextInt(a.length)];
    }
}
