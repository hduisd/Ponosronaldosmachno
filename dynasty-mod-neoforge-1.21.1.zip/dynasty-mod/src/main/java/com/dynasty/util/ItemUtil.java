package com.dynasty.util;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Inventory helpers. */
public final class ItemUtil {
    private ItemUtil() {}

    public static int count(Player player, Item item) {
        int have = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(item)) {
                have += s.getCount();
            }
        }
        return have;
    }

    /** Removes the given amount of an item; returns false (and removes nothing) if there is not enough. */
    public static boolean consume(Player player, Item item, int amount) {
        if (count(player, item) < amount) {
            return false;
        }
        int left = amount;
        for (int i = 0; i < player.getInventory().getContainerSize() && left > 0; i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(item)) {
                int take = Math.min(left, s.getCount());
                s.shrink(take);
                left -= take;
            }
        }
        return true;
    }
}
