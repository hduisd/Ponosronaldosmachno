package com.dynasty.util;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Affection value of gifts and the list of favourite gifts. */
public final class GiftTable {
    private GiftTable() {}

    public static int favoriteCount() {
        return 14;
    }

    public static Item favorite(int index) {
        switch (Math.floorMod(index, favoriteCount())) {
            case 0:
                return Items.POPPY;
            case 1:
                return Items.ALLIUM;
            case 2:
                return Items.CORNFLOWER;
            case 3:
                return Items.LILY_OF_THE_VALLEY;
            case 4:
                return Items.SUNFLOWER;
            case 5:
                return Items.CAKE;
            case 6:
                return Items.PUMPKIN_PIE;
            case 7:
                return Items.HONEY_BOTTLE;
            case 8:
                return Items.DIAMOND;
            case 9:
                return Items.EMERALD;
            case 10:
                return Items.BOOK;
            case 11:
                return Items.AMETHYST_SHARD;
            case 12:
                return Items.GOLDEN_APPLE;
            default:
                return Items.COOKIE;
        }
    }

    /** Base affection points of a gift; 0 means the item is not a gift. */
    public static int value(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0;
        }
        Item item = stack.getItem();
        if (stack.is(ItemTags.FLOWERS)) {
            return 4;
        }
        if (item == Items.DIAMOND) {
            return 12;
        }
        if (item == Items.GOLDEN_APPLE) {
            return 10;
        }
        if (item == Items.EMERALD) {
            return 9;
        }
        if (item == Items.CAKE) {
            return 8;
        }
        if (item == Items.GOLD_INGOT || item == Items.PUMPKIN_PIE) {
            return 6;
        }
        if (item == Items.HONEY_BOTTLE) {
            return 5;
        }
        if (item == Items.BOOK || item == Items.AMETHYST_SHARD) {
            return 4;
        }
        if (item == Items.COOKIE || item == Items.COOKED_BEEF || item == Items.COOKED_PORKCHOP
                || item == Items.COOKED_CHICKEN) {
            return 3;
        }
        if (item == Items.BREAD || item == Items.APPLE || item == Items.SWEET_BERRIES) {
            return 2;
        }
        return 0;
    }
}
