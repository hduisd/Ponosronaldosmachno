package com.dynasty.client;

import java.util.ArrayList;
import java.util.List;

import com.dynasty.entity.VehicleKind;
import com.dynasty.net.RealmActionPayload;
import com.dynasty.net.RealmSnapshot;
import com.dynasty.realm.BuildingType;
import com.dynasty.realm.Faction;
import com.dynasty.realm.Profession;
import com.dynasty.realm.Realm;
import com.dynasty.realm.RealmManager;
import com.dynasty.realm.SoldierType;
import com.dynasty.realm.Tech;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;

/** The main management screen of a realm: overview, buildings, army, technologies, diplomacy, family. */
public class RealmScreen extends Screen {
    private static final int W = 340;
    private static final int H = 236;
    private static final int ROWS_PER_PAGE = 6;

    private static final int WHITE = 0xFFFFFF;
    private static final int GREY = 0xAAAAAA;
    private static final int GREEN = 0x55FF55;
    private static final int RED = 0xFF5555;
    private static final int GOLD = 0xFFAA00;
    private static final int AQUA = 0x55FFFF;

    private static final String[] TAB_KEYS = {
        "gui.dynasty.tab.overview", "gui.dynasty.tab.buildings", "gui.dynasty.tab.army",
        "gui.dynasty.tab.tech", "gui.dynasty.tab.diplomacy", "gui.dynasty.tab.family"
    };
    private static final String[] RES = {"coins", "food", "wood", "stone", "iron", "fuel"};
    private static final int[] RES_COLORS = {0xFFD84A, 0x9BD65A, 0xB5835A, 0xB0B0B0, 0xD8D8E8, 0x5AA8E0};

    private RealmSnapshot s;
    private int tab;
    private int page;
    private long focus;
    private int left;
    private int top;
    private final List<Integer> order = new ArrayList<>();

    public RealmScreen(RealmSnapshot snapshot) {
        super(Component.translatable("gui.dynasty.realm"));
        this.s = snapshot;
        this.tab = snapshot.tab == RealmSnapshot.TAB_KEEP ? 0 : snapshot.tab;
        this.focus = snapshot.focus;
    }

    /** Called when the server sends a fresh snapshot while the screen is open. */
    public void update(RealmSnapshot snapshot) {
        this.s = snapshot;
        if (snapshot.tab != RealmSnapshot.TAB_KEEP) {
            this.tab = snapshot.tab;
            this.page = 0;
        }
        if (snapshot.focus != RealmSnapshot.NO_FOCUS) {
            this.focus = snapshot.focus;
        }
        this.rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---- helpers -------------------------------------------------------------------------

    private void send(int action, int arg1, int arg2, long arg3) {
        PacketDistributor.sendToServer(new RealmActionPayload(action, arg1, arg2, arg3));
    }

    private Button button(Component label, int x, int y, int w, int h, Button.OnPress action) {
        return this.addRenderableWidget(Button.builder(label, action).bounds(x, y, w, h).build());
    }

    private static String costText(int[] cost) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Realm.RES_COUNT && i < cost.length; i++) {
            if (cost[i] > 0) {
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(cost[i]).append(I18n.get("gui.dynasty.short." + RES[i]));
            }
        }
        return sb.length() == 0 ? "-" : sb.toString();
    }

    private boolean canAfford(int[] cost) {
        for (int i = 0; i < Realm.RES_COUNT && i < cost.length; i++) {
            if (cost[i] > s.res[i]) {
                return false;
            }
        }
        return true;
    }

    private int levelOfType(BuildingType type) {
        int n = 0;
        for (int i = 0; i < s.bType.size(); i++) {
            if (s.bType.get(i) == type.ordinal()) {
                n += s.bLevel.get(i);
            }
        }
        return n;
    }

    private int countOfType(BuildingType type) {
        int n = 0;
        for (int i = 0; i < s.bType.size(); i++) {
            if (s.bType.get(i) == type.ordinal()) {
                n++;
            }
        }
        return n;
    }

    private static String signed(int v) {
        return v >= 0 ? "+" + v : String.valueOf(v);
    }

    // ---- widgets -------------------------------------------------------------------------

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = (this.height - H) / 2;
        int tw = 54;
        for (int i = 0; i < TAB_KEYS.length; i++) {
            final int index = i;
            Button b = button(Component.translatable(TAB_KEYS[i]), left + 6 + i * (tw + 2), top + 5, tw, 18, btn -> {
                this.tab = index;
                this.page = 0;
                this.rebuildWidgets();
            });
            b.active = i != tab;
        }
        switch (tab) {
            case RealmManager.TAB_OVERVIEW:
                initOverview();
                break;
            case RealmManager.TAB_BUILDINGS:
                initBuildings();
                break;
            case RealmManager.TAB_ARMY:
                initArmy();
                break;
            case RealmManager.TAB_TECH:
                initTech();
                break;
            case RealmManager.TAB_DIPLOMACY:
                initDiplomacy();
                break;
            default:
                break;
        }
    }

    private void initOverview() {
        int y = top + H - 44;
        button(Component.translatable("gui.dynasty.deposit"), left + 8, y, 104, 18,
                btn -> send(RealmManager.ACT_DEPOSIT, 0, 0, 0L));
        addRenderableWidget(Button.builder(Component.translatable("gui.dynasty.withdraw_coins"),
                        btn -> send(RealmManager.ACT_WITHDRAW_COINS, 10, 0, 0L))
                .bounds(left + 118, y, 104, 18).tooltip(Tooltip.create(Component.translatable("gui.dynasty.withdraw_coins.tip"))).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.dynasty.withdraw_fuel"),
                        btn -> send(RealmManager.ACT_WITHDRAW_FUEL, 1, 0, 0L))
                .bounds(left + 228, y, 104, 18).tooltip(Tooltip.create(Component.translatable("gui.dynasty.withdraw_fuel.tip"))).build());
    }

    private void sortBuildings() {
        order.clear();
        for (int i = 0; i < s.bType.size(); i++) {
            order.add(i);
        }
        order.sort((a, b) -> {
            boolean fa = s.bPos.get(a) == focus;
            boolean fb = s.bPos.get(b) == focus;
            if (fa != fb) {
                return fa ? -1 : 1;
            }
            int c = Integer.compare(s.bType.get(a), s.bType.get(b));
            if (c != 0) {
                return c;
            }
            return Long.compare(s.bPos.get(a), s.bPos.get(b));
        });
    }

    private int pageCount() {
        return Math.max(1, (order.size() + ROWS_PER_PAGE - 1) / ROWS_PER_PAGE);
    }

    private void initBuildings() {
        sortBuildings();
        page = Math.max(0, Math.min(page, pageCount() - 1));
        int first = page * ROWS_PER_PAGE;
        for (int row = 0; row < ROWS_PER_PAGE; row++) {
            int idx = first + row;
            if (idx >= order.size()) {
                break;
            }
            int bi = order.get(idx);
            BuildingType type = BuildingType.byIndex(s.bType.get(bi));
            int level = s.bLevel.get(bi);
            long pos = s.bPos.get(bi);
            int y = top + 46 + row * 26;
            Button b;
            if (level >= BuildingType.MAX_LEVEL) {
                b = button(Component.translatable("gui.dynasty.max_level"), left + 244, y + 2, 88, 18, btn -> { });
                b.active = false;
            } else {
                int[] cost = type.upgradeCost(level);
                boolean hallBlocks = type != BuildingType.TOWN_HALL && level >= s.hallLevel;
                b = addRenderableWidget(Button.builder(Component.translatable("gui.dynasty.upgrade"),
                                btn -> send(RealmManager.ACT_UPGRADE, 0, 0, pos))
                        .bounds(left + 244, y + 2, 88, 18)
                        .tooltip(Tooltip.create(Component.translatable(hallBlocks ? "gui.dynasty.upgrade.hall_first" : "gui.dynasty.upgrade.cost", costText(cost))))
                        .build());
                b.active = !hallBlocks && canAfford(cost);
            }
        }
        Button prev = button(Component.literal("<"), left + 130, top + H - 44, 20, 18, btn -> {
            page = Math.max(0, page - 1);
            rebuildWidgets();
        });
        prev.active = page > 0;
        Button next = button(Component.literal(">"), left + 190, top + H - 44, 20, 18, btn -> {
            page = Math.min(pageCount() - 1, page + 1);
            rebuildWidgets();
        });
        next.active = page < pageCount() - 1;
    }

    private void initArmy() {
        for (SoldierType t : SoldierType.values()) {
            int row = t.ordinal();
            int y = top + 44 + row * 15;
            boolean unlocked = t.tech == null || s.knows(t.tech.ordinal());
            Button b = button(Component.translatable("gui.dynasty.recruit"), left + 268, y, 64, 14,
                    btn -> send(RealmManager.ACT_RECRUIT, t.ordinal(), 0, 0L));
            b.active = unlocked && canAfford(t.cost);
        }
        for (VehicleKind k : VehicleKind.values()) {
            int row = k.ordinal();
            int y = top + 156 + row * 15;
            boolean unlocked = k.tech == null || s.knows(k.tech.ordinal());
            int garage = k == VehicleKind.CART ? 0 : k == VehicleKind.TANK ? 2 : 1;
            Button b = button(Component.translatable("gui.dynasty.buy"), left + 268, y, 64, 14,
                    btn -> send(RealmManager.ACT_VEHICLE, k.ordinal(), 0, 0L));
            b.active = unlocked && s.garageLevels >= garage && canAfford(k.cost);
        }
    }

    private void initTech() {
        int[] rowOf = new int[5];
        for (Tech t : Tech.values()) {
            int col = t.era - 1;
            int row = rowOf[col]++;
            int x = left + 8 + col * 82;
            int y = top + 44 + row * 20;
            boolean known = s.knows(t.ordinal());
            boolean current = t.id.equals(s.researching);
            boolean unlocked = true;
            for (Tech p : t.prereqs) {
                if (!s.knows(p.ordinal())) {
                    unlocked = false;
                }
            }
            Component name = Component.translatable(t.nameKey());
            Component label;
            if (known) {
                label = name.copy().withStyle(ChatFormatting.GREEN);
            } else if (current) {
                label = Component.literal("> ").append(name).withStyle(ChatFormatting.YELLOW);
            } else if (unlocked) {
                label = name;
            } else {
                label = name.copy().withStyle(ChatFormatting.DARK_GRAY);
            }
            StringBuilder tip = new StringBuilder(I18n.get(t.descKey()));
            tip.append("\n").append(I18n.get("gui.dynasty.tech_cost", t.cost));
            if (t.prereqs.length > 0) {
                tip.append("\n").append(I18n.get("gui.dynasty.tech_needs")).append(' ');
                for (int i = 0; i < t.prereqs.length; i++) {
                    if (i > 0) {
                        tip.append(", ");
                    }
                    tip.append(I18n.get(t.prereqs[i].nameKey()));
                }
            }
            Button b = addRenderableWidget(Button.builder(label, btn -> send(RealmManager.ACT_RESEARCH, t.ordinal(), 0, 0L))
                    .bounds(x, y, 80, 18).tooltip(Tooltip.create(Component.literal(tip.toString()))).build());
            b.active = !known && unlocked && !current;
        }
        Button cancel = button(Component.translatable("gui.dynasty.cancel_research"), left + 252, top + 186, 80, 16,
                btn -> send(RealmManager.ACT_RESEARCH, -1, 0, 0L));
        cancel.active = !s.researching.isEmpty();
    }

    private void initDiplomacy() {
        String[] keys = {"gui.dynasty.gift", "gui.dynasty.trade", "gui.dynasty.alliance", "gui.dynasty.war", "gui.dynasty.peace"};
        int[] actions = {RealmManager.DIPLO_GIFT, RealmManager.DIPLO_TRADE, RealmManager.DIPLO_ALLIANCE,
            RealmManager.DIPLO_WAR, RealmManager.DIPLO_PEACE};
        for (int f = 0; f < Faction.COUNT; f++) {
            final int faction = f;
            int y = top + 46 + f * 38;
            int status = s.status[f];
            int rel = s.relation[f];
            for (int a = 0; a < keys.length; a++) {
                final int action = actions[a];
                Button b = button(Component.translatable(keys[a]), left + 8 + a * 65, y + 14, 63, 16,
                        btn -> send(RealmManager.ACT_DIPLOMACY, faction, action, 0L));
                switch (action) {
                    case RealmManager.DIPLO_GIFT:
                        b.active = status != Faction.STATUS_WAR && s.res[Realm.RES_COINS] >= 50;
                        break;
                    case RealmManager.DIPLO_TRADE:
                        b.active = status == Faction.STATUS_NONE && rel >= 10;
                        break;
                    case RealmManager.DIPLO_ALLIANCE:
                        b.active = status == Faction.STATUS_TRADE && rel >= 50 && s.res[Realm.RES_COINS] >= 100;
                        break;
                    case RealmManager.DIPLO_WAR:
                        b.active = status != Faction.STATUS_WAR;
                        break;
                    default:
                        b.active = status == Faction.STATUS_WAR && s.res[Realm.RES_COINS] >= 80;
                        break;
                }
            }
        }
        int[] bits = {Realm.EDICT_MARTIAL_LAW, Realm.EDICT_FREE_TRADE, Realm.EDICT_PATRONAGE};
        String[] edictKeys = {"edict.dynasty.martial_law", "edict.dynasty.free_trade", "edict.dynasty.patronage"};
        for (int i = 0; i < bits.length; i++) {
            final int bit = bits[i];
            boolean on = (s.edicts & bit) != 0;
            Component label = Component.translatable(edictKeys[i]).append(Component.literal(on ? " [+]" : " [-]"))
                    .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.GRAY);
            addRenderableWidget(Button.builder(label, btn -> send(RealmManager.ACT_EDICT, bit, 0, 0L))
                    .bounds(left + 8 + i * 109, top + 176, 107, 18)
                    .tooltip(Tooltip.create(Component.translatable(edictKeys[i] + ".desc"))).build());
        }
    }

    // ---- drawing -------------------------------------------------------------------------

    private void text(GuiGraphics g, Component c, int x, int y, int color) {
        g.drawString(this.font, c, x, y, color);
    }

    private void text(GuiGraphics g, String c, int x, int y, int color) {
        g.drawString(this.font, c, x, y, color);
    }

    /** Draws only the first wrapped line of a component. */
    private void line(GuiGraphics g, Component c, int x, int y, int maxWidth, int color) {
        List<FormattedCharSequence> lines = this.font.split(c, maxWidth);
        if (!lines.isEmpty()) {
            g.drawString(this.font, lines.get(0), x, y, color);
        }
    }

    private void bar(GuiGraphics g, int x, int y, int w, int h, int value, int max, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, 0xFF303030);
        int fill = max <= 0 ? 0 : Math.max(0, Math.min(w, (int) ((long) w * value / max)));
        g.fill(x, y, x + fill, y + h, 0xFF000000 | color);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(left, top, left + W, top + H, 0xE6141420);
        g.renderOutline(left, top, W, H, 0xFF8A6D3B);
        g.fill(left + 4, top + 26, left + W - 4, top + 27, 0xFF8A6D3B);
        switch (tab) {
            case RealmManager.TAB_OVERVIEW:
                drawOverview(g);
                break;
            case RealmManager.TAB_BUILDINGS:
                drawBuildings(g);
                break;
            case RealmManager.TAB_ARMY:
                drawArmy(g);
                break;
            case RealmManager.TAB_TECH:
                drawTech(g);
                break;
            case RealmManager.TAB_DIPLOMACY:
                drawDiplomacy(g);
                break;
            default:
                drawFamily(g);
                break;
        }
        drawMessage(g);
    }

    private void drawMessage(GuiGraphics g) {
        if (s.message == null || s.message.isEmpty()) {
            return;
        }
        boolean error = s.message.startsWith("!");
        Component c = GuiText.format(error ? s.message.substring(1) : s.message);
        line(g, c, left + 8, top + H - 15, W - 16, error ? RED : GREEN);
    }

    private void drawOverview(GuiGraphics g) {
        text(g, Component.translatable("gui.dynasty.realm_of", s.ownerName), left + 8, top + 32, GOLD);
        text(g, Component.translatable("gui.dynasty.day_gen", s.day, s.generation), left + 190, top + 32, GREY);
        for (int i = 0; i < Realm.RES_COUNT; i++) {
            int y = top + 46 + i * 11;
            g.fill(left + 8, y + 1, left + 14, y + 7, 0xFF000000 | RES_COLORS[i]);
            text(g, I18n.get("gui.dynasty.res." + RES[i]), left + 18, y, WHITE);
            text(g, String.valueOf(s.res[i]), left + 70, y, WHITE);
            text(g, "(" + signed(s.income[i]) + ")", left + 108, y, s.income[i] >= 0 ? GREEN : RED);
        }
        int rx = left + 170;
        text(g, I18n.get("gui.dynasty.happiness") + ": " + s.happiness + "%", rx, top + 46, WHITE);
        bar(g, rx, top + 57, 160, 6, s.happiness, 100, s.happiness >= 60 ? 0x55CC55 : s.happiness >= 35 ? 0xE0C030 : 0xCC4040);
        text(g, I18n.get("gui.dynasty.population", s.population, s.babies, s.capacity), rx, top + 68, s.population + s.babies > s.capacity ? RED : WHITE);
        text(g, I18n.get("gui.dynasty.prestige") + ": " + s.prestige, rx, top + 79, WHITE);
        text(g, I18n.get("gui.dynasty.science") + ": +" + s.science, rx, top + 90, AQUA);
        text(g, I18n.get("gui.dynasty.army_line", totalSoldiers(), s.armyCap, s.defense), rx, top + 101, WHITE);
        if (s.raidSize > 0) {
            text(g, I18n.get("gui.dynasty.raid_active", s.raidKills, s.raidSize), rx, top + 112, RED);
        }
        StringBuilder jobs = new StringBuilder();
        for (Profession p : Profession.values()) {
            if (jobs.length() > 0) {
                jobs.append("  ");
            }
            jobs.append(I18n.get(p.nameKey())).append(' ').append(s.jobs[p.ordinal()]);
        }
        line(g, Component.literal(jobs.toString()), left + 8, top + 116 + 0, 160, GREY);
        text(g, I18n.get("gui.dynasty.report"), left + 8, top + 128, GOLD);
        int shown = 0;
        for (int i = Math.max(0, s.report.size() - 7); i < s.report.size(); i++) {
            line(g, GuiText.format(s.report.get(i)), left + 8, top + 139 + shown * 10, W - 16, WHITE);
            shown++;
        }
    }

    private int totalSoldiers() {
        int n = 0;
        for (int v : s.soldiers) {
            n += v;
        }
        return n;
    }

    private void drawBuildings(GuiGraphics g) {
        text(g, I18n.get("gui.dynasty.buildings_line", s.hallLevel, s.bType.size(), RealmManager.MAX_BUILDINGS), left + 8, top + 32, GOLD);
        if (order.isEmpty()) {
            sortBuildings();
        }
        int first = page * ROWS_PER_PAGE;
        for (int row = 0; row < ROWS_PER_PAGE; row++) {
            int idx = first + row;
            if (idx >= order.size()) {
                break;
            }
            int bi = order.get(idx);
            BuildingType type = BuildingType.byIndex(s.bType.get(bi));
            int level = s.bLevel.get(bi);
            long pos = s.bPos.get(bi);
            int y = top + 46 + row * 26;
            if (pos == focus) {
                g.fill(left + 4, y - 2, left + W - 4, y + 23, 0x40FFD84A);
            }
            text(g, Component.translatable(type.nameKey()).append(Component.literal("  " + I18n.get("gui.dynasty.level", level))), left + 8, y, WHITE);
            BlockPos bp = BlockPos.of(pos);
            text(g, bp.getX() + ", " + bp.getY() + ", " + bp.getZ(), left + 8, y + 11, GREY);
            if (level < BuildingType.MAX_LEVEL) {
                text(g, costText(type.upgradeCost(level)), left + 100, y + 11, canAfford(type.upgradeCost(level)) ? GREEN : RED);
            }
            text(g, buildingEffect(type), left + 100, y, AQUA);
        }
        g.drawCenteredString(this.font, (page + 1) + " / " + pageCount(), left + 170, top + H - 40, GREY);
    }

    private String buildingEffect(BuildingType type) {
        return I18n.get("gui.dynasty.effect." + type.id);
    }

    private void drawArmy(GuiGraphics g) {
        text(g, I18n.get("gui.dynasty.army_head", totalSoldiers(), s.armyCap, s.defense, s.upkeepCoins), left + 8, top + 32, GOLD);
        for (SoldierType t : SoldierType.values()) {
            int y = top + 44 + t.ordinal() * 15 + 3;
            boolean unlocked = t.tech == null || s.knows(t.tech.ordinal());
            text(g, Component.translatable(t.nameKey()), left + 8, y, unlocked ? WHITE : 0x777777);
            text(g, "x" + s.soldiers[t.ordinal()], left + 92, y, GREY);
            text(g, unlocked ? costText(t.cost) : I18n.get("gui.dynasty.needs") + " " + I18n.get(t.tech.nameKey()), left + 120, y,
                    unlocked ? (canAfford(t.cost) ? GREEN : RED) : 0x777777);
        }
        text(g, I18n.get("gui.dynasty.vehicles_head", s.garageLevels), left + 8, top + 144, GOLD);
        for (VehicleKind k : VehicleKind.values()) {
            int y = top + 156 + k.ordinal() * 15 + 3;
            boolean unlocked = k.tech == null || s.knows(k.tech.ordinal());
            int garage = k == VehicleKind.CART ? 0 : k == VehicleKind.TANK ? 2 : 1;
            boolean ok = unlocked && s.garageLevels >= garage;
            text(g, Component.translatable(k.nameKey()), left + 8, y, ok ? WHITE : 0x777777);
            String info = !unlocked ? I18n.get("gui.dynasty.needs") + " " + I18n.get(k.tech.nameKey())
                    : s.garageLevels < garage ? I18n.get("gui.dynasty.needs_garage", garage) : costText(k.cost);
            text(g, info, left + 92, y, ok ? (canAfford(k.cost) ? GREEN : RED) : 0x777777);
        }
        text(g, I18n.get("gui.dynasty.legend"), left + 8, top + H - 28, GREY);
    }

    private void drawTech(GuiGraphics g) {
        String[] eras = {"I", "II", "III", "IV"};
        for (int i = 0; i < eras.length; i++) {
            text(g, I18n.get("gui.dynasty.era") + " " + eras[i], left + 8 + i * 82, top + 32, GOLD);
        }
        Tech current = Tech.byId(s.researching);
        if (current == null) {
            text(g, I18n.get("gui.dynasty.no_research", s.progress, s.science), left + 8, top + 190, GREY);
        } else {
            text(g, I18n.get("gui.dynasty.researching", I18n.get(current.nameKey()), s.progress, current.cost, s.science), left + 8, top + 190, AQUA);
            bar(g, left + 8, top + 203, W - 16, 6, s.progress, current.cost, 0x55AADD);
        }
    }

    private void drawDiplomacy(GuiGraphics g) {
        for (int f = 0; f < Faction.COUNT; f++) {
            int y = top + 46 + f * 38;
            text(g, Component.translatable(Faction.nameKey(f)), left + 8, y, WHITE);
            int status = s.status[f];
            int color = status == Faction.STATUS_WAR ? RED : status == Faction.STATUS_NONE ? GREY : GREEN;
            text(g, Component.translatable(Faction.statusKey(status)), left + 110, y, color);
            int rel = s.relation[f];
            text(g, I18n.get("gui.dynasty.relation") + " " + rel, left + 190, y, WHITE);
            bar(g, left + 250, y + 2, 80, 5, rel + 100, 200, rel >= 0 ? 0x55CC55 : 0xCC4040);
        }
        text(g, I18n.get("gui.dynasty.edicts"), left + 8, top + 162, GOLD);
        text(g, I18n.get("gui.dynasty.diplo_hint"), left + 8, top + 200, GREY);
    }

    private void drawFamily(GuiGraphics g) {
        int y = top + 34;
        text(g, I18n.get("gui.dynasty.family_head"), left + 8, y, GOLD);
        y += 14;
        text(g, I18n.get("gui.dynasty.spouse") + ": " + (s.spouseName.isEmpty() ? I18n.get("gui.dynasty.none") : s.spouseName), left + 8, y, WHITE);
        y += 12;
        text(g, I18n.get("gui.dynasty.children") + ": " + s.childrenBorn + "  (" + I18n.get("gui.dynasty.adult") + ": " + s.adultChildren + ")", left + 8, y, WHITE);
        y += 12;
        text(g, I18n.get("gui.dynasty.heir") + ": " + (s.heirName.isEmpty() ? I18n.get("gui.dynasty.none") : s.heirName), left + 8, y, WHITE);
        y += 12;
        text(g, I18n.get("gui.dynasty.generation") + ": " + s.generation, left + 8, y, WHITE);
        y += 12;
        text(g, I18n.get("gui.dynasty.prestige") + ": " + s.prestige, left + 8, y, WHITE);
        y += 16;
        text(g, I18n.get("gui.dynasty.family_list"), left + 8, y, GOLD);
        y += 12;
        if (s.family.isEmpty()) {
            text(g, I18n.get("gui.dynasty.family_empty"), left + 8, y, GREY);
        } else {
            StringBuilder sb = new StringBuilder();
            int col = 0;
            for (String name : s.family) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(name);
                if (this.font.width(sb.toString()) > W - 30) {
                    text(g, sb.toString(), left + 8, y, WHITE);
                    y += 11;
                    sb.setLength(0);
                    col++;
                    if (col >= 5) {
                        break;
                    }
                }
            }
            if (sb.length() > 0 && col < 5) {
                text(g, sb.toString(), left + 8, y, WHITE);
            }
        }
        text(g, I18n.get("gui.dynasty.family_hint"), left + 8, top + H - 28, GREY);
    }
}
