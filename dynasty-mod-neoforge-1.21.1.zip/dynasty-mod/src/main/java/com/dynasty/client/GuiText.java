package com.dynasty.client;

import net.minecraft.network.chat.Component;

/** Turns "translation.key|arg|@other.key" lines sent by the server into components. */
public final class GuiText {
    private GuiText() {}

    public static Component format(String line) {
        String[] parts = line.split("\\|", -1);
        Object[] args = new Object[Math.max(0, parts.length - 1)];
        for (int i = 1; i < parts.length; i++) {
            String a = parts[i];
            args[i - 1] = a.startsWith("@") ? Component.translatable(a.substring(1)) : a;
        }
        return Component.translatable(parts[0], args);
    }
}
