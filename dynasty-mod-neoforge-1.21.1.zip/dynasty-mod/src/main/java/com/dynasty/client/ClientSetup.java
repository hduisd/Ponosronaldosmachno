package com.dynasty.client;

import com.dynasty.Dynasty;
import com.dynasty.entity.VehicleEntity;
import com.dynasty.entity.VehicleKind;
import com.dynasty.net.FireVehiclePayload;
import com.dynasty.net.RealmActionPayload;
import com.dynasty.realm.RealmManager;
import com.dynasty.registry.ModEntities;
import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Client-only registrations: entity renderers, model layers and key bindings. */
@EventBusSubscriber(modid = Dynasty.MODID, value = Dist.CLIENT)
public final class ClientSetup {
    public static final KeyMapping FIRE_KEY = new KeyMapping("key.dynasty.fire", InputConstants.KEY_R, "key.categories.dynasty");
    public static final KeyMapping OPEN_KEY = new KeyMapping("key.dynasty.open", InputConstants.KEY_K, "key.categories.dynasty");

    private ClientSetup() {}

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(FIRE_KEY);
        event.register(OPEN_KEY);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.CITIZEN.get(), CitizenRenderer::new);
        event.registerEntityRenderer(ModEntities.SOLDIER.get(), SoldierRenderer::new);
        event.registerEntityRenderer(ModEntities.BANDIT.get(), BanditRenderer::new);
        event.registerEntityRenderer(ModEntities.BULLET.get(), ThrownItemRenderer::new);
        for (VehicleKind kind : VehicleKind.values()) {
            event.registerEntityRenderer(kind.entityType(), context -> new VehicleRenderer(context, kind));
        }
    }

    @SubscribeEvent
    public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        for (VehicleKind kind : VehicleKind.values()) {
            event.registerLayerDefinition(VehicleModels.layer(kind), () -> VehicleModels.create(kind));
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        while (FIRE_KEY.consumeClick()) {
            if (mc.player != null && mc.player.getVehicle() instanceof VehicleEntity vehicle && vehicle.getKind().hasCannon) {
                PacketDistributor.sendToServer(new FireVehiclePayload());
            }
        }
        while (OPEN_KEY.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                PacketDistributor.sendToServer(new RealmActionPayload(RealmManager.ACT_REFRESH, 0, 0, 0L));
            }
        }
    }
}
