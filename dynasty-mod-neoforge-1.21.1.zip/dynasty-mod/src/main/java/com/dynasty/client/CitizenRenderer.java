package com.dynasty.client;

import com.dynasty.Dynasty;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.realm.Profession;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Citizens look like players; the skin depends on profession, sex and skin tone. */
public class CitizenRenderer extends HumanoidMobRenderer<CitizenEntity, PlayerModel<CitizenEntity>> {
    private static final ResourceLocation[][][] TEXTURES = new ResourceLocation[Profession.values().length][2][2];

    static {
        for (Profession p : Profession.values()) {
            for (int sex = 0; sex < 2; sex++) {
                for (int tone = 0; tone < 2; tone++) {
                    TEXTURES[p.ordinal()][sex][tone] = Dynasty.id("textures/entity/citizen/" + p.id
                            + (sex == 1 ? "_f_" : "_m_") + tone + ".png");
                }
            }
        }
    }

    public CitizenRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
    }

    @Override
    protected void scale(CitizenEntity entity, PoseStack poseStack, float partialTick) {
        if (entity.isBaby()) {
            poseStack.scale(0.5F, 0.5F, 0.5F);
            this.shadowRadius = 0.25F;
        } else {
            this.shadowRadius = 0.5F;
        }
    }

    @Override
    public ResourceLocation getTextureLocation(CitizenEntity entity) {
        int tone = Math.floorMod(entity.getSkin(), 2);
        return TEXTURES[entity.getProfession().ordinal()][entity.isFemale() ? 1 : 0][tone];
    }
}
