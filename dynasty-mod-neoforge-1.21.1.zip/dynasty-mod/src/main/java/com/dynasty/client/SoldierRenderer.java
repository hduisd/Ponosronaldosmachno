package com.dynasty.client;

import com.dynasty.Dynasty;
import com.dynasty.entity.SoldierEntity;
import com.dynasty.realm.SoldierType;

import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Soldiers of the realm, one uniform per unit type. */
public class SoldierRenderer extends HumanoidMobRenderer<SoldierEntity, GunnerModel<SoldierEntity>> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[SoldierType.values().length];

    static {
        for (SoldierType t : SoldierType.values()) {
            TEXTURES[t.ordinal()] = Dynasty.id("textures/entity/soldier/" + t.id + ".png");
        }
    }

    public SoldierRenderer(EntityRendererProvider.Context context) {
        super(context, new GunnerModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(SoldierEntity entity) {
        return TEXTURES[entity.getSoldierType().ordinal()];
    }
}
