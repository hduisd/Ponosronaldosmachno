package com.dynasty.client;

import com.dynasty.Dynasty;
import com.dynasty.entity.VehicleEntity;
import com.dynasty.entity.VehicleKind;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Draws a vehicle from its generated cube model (see VehicleModels). */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private final ModelPart root;
    private final ModelPart turret;
    private final ResourceLocation texture;

    public VehicleRenderer(EntityRendererProvider.Context context, VehicleKind kind) {
        super(context);
        this.root = context.bakeLayer(VehicleModels.layer(kind));
        this.turret = this.root.hasChild("turret") ? this.root.getChild("turret") : null;
        this.texture = Dynasty.id("textures/entity/vehicle/" + kind.id + ".png");
        this.shadowRadius = 0.9F;
    }

    @Override
    public void render(VehicleEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float bodyYaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));
        float hurt = entity.hurtTime - partialTick;
        if (hurt > 0.0F) {
            poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.sin(hurt) * hurt * 0.6F));
        }
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0D, -1.501D, 0.0D);
        if (turret != null) {
            float headYaw = Mth.rotLerp(partialTick, entity.yHeadRotO, entity.yHeadRot);
            turret.yRot = Mth.wrapDegrees(headYaw - bodyYaw) * ((float) Math.PI / 180.0F);
        }
        VertexConsumer vertices = buffer.getBuffer(RenderType.entityCutoutNoCull(texture));
        root.render(poseStack, vertices, packedLight, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(VehicleEntity entity) {
        return texture;
    }
}
