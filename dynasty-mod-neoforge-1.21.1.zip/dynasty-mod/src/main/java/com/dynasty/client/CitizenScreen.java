package com.dynasty.client;

import com.dynasty.entity.CitizenEntity;
import com.dynasty.net.CitizenActionPayload;
import com.dynasty.net.CitizenSnapshot;
import com.dynasty.realm.Profession;
import com.dynasty.util.GiftTable;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/** Talk to a citizen: conversation, gifts, dates, hugs, proposal and job. */
public class CitizenScreen extends Screen {
    private static final int W = 230;
    private static final int H = 176;

    private static final String[] HEART = {
        ".XX.XX.",
        "XXXXXXX",
        "XXXXXXX",
        ".XXXXX.",
        "..XXX..",
        "...X..."
    };

    private CitizenSnapshot s;
    private int left;
    private int top;

    public CitizenScreen(CitizenSnapshot snapshot) {
        super(Component.translatable("gui.dynasty.citizen"));
        this.s = snapshot;
    }

    public int entityId() {
        return s.entityId;
    }

    public void update(CitizenSnapshot snapshot) {
        this.s = snapshot;
        this.rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void act(int action) {
        PacketDistributor.sendToServer(new CitizenActionPayload(s.entityId, action));
    }

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = (this.height - H) / 2;
        int[] actions = {CitizenEntity.ACT_TALK, CitizenEntity.ACT_GIFT, CitizenEntity.ACT_DATE,
            CitizenEntity.ACT_HUG, CitizenEntity.ACT_PROPOSE, CitizenEntity.ACT_PROFESSION};
        String[] keys = {"gui.dynasty.talk", "gui.dynasty.give_gift", "gui.dynasty.date", "gui.dynasty.hug",
            "gui.dynasty.propose", "gui.dynasty.change_job"};
        int[] flags = {CitizenSnapshot.F_TALK, CitizenSnapshot.F_GIFT, CitizenSnapshot.F_DATE,
            CitizenSnapshot.F_HUG, CitizenSnapshot.F_PROPOSE, CitizenSnapshot.F_PROFESSION};
        for (int i = 0; i < actions.length; i++) {
            final int action = actions[i];
            int col = i % 2;
            int row = i / 2;
            Button b = this.addRenderableWidget(Button.builder(Component.translatable(keys[i]), btn -> act(action))
                    .bounds(left + 8 + col * 110, top + 106 + row * 22, 104, 18).build());
            b.active = s.can(flags[i]);
        }
    }

    private void heart(GuiGraphics g, int x, int y, int color) {
        for (int r = 0; r < HEART.length; r++) {
            for (int c = 0; c < HEART[r].length(); c++) {
                if (HEART[r].charAt(c) == 'X') {
                    g.fill(x + c * 2, y + r * 2, x + c * 2 + 2, y + r * 2 + 2, color);
                }
            }
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(left, top, left + W, top + H, 0xE6141420);
        g.renderOutline(left, top, W, H, 0xFF8A6D3B);

        String sex = I18n.get(s.female ? "gui.dynasty.female" : "gui.dynasty.male");
        String job = s.baby ? I18n.get("gui.dynasty.child") : I18n.get(Profession.byIndex(s.profession).nameKey());
        g.drawString(this.font, s.name + "  (" + sex + ", " + job + ")", left + 8, top + 8, 0xFFD84A);

        String state;
        if (s.partnerKind == CitizenEntity.PARTNER_PLAYER) {
            state = I18n.get("gui.dynasty.married_to_you");
        } else if (s.partnerKind == CitizenEntity.PARTNER_CITIZEN) {
            state = I18n.get("gui.dynasty.married_to", s.partnerName);
        } else {
            state = I18n.get("gui.dynasty.single");
        }
        g.drawString(this.font, state, left + 8, top + 21, 0xAAAAAA);

        int full = Math.max(0, Math.min(10, s.affection / 10));
        for (int i = 0; i < 10; i++) {
            heart(g, left + 8 + i * 16, top + 35, i < full ? 0xFFE0405A : 0xFF4A3A44);
        }
        g.drawString(this.font, I18n.get("gui.dynasty.affection") + ": " + s.affection + "/100", left + 8, top + 50, 0xFFFFFF);

        if (s.favoriteIndex >= 0) {
            g.drawString(this.font, I18n.get("gui.dynasty.favorite_gift") + ": " + GiftTable.favorite(s.favoriteIndex).getDescription().getString(),
                    left + 8, top + 62, 0x55FFFF);
        } else {
            g.drawString(this.font, I18n.get("gui.dynasty.favorite_unknown"), left + 8, top + 62, 0x777777);
        }
        if (!s.parents.isEmpty()) {
            g.drawString(this.font, I18n.get("gui.dynasty.parents") + ": " + s.parents + "  ·  " + I18n.get("gui.dynasty.generation") + " " + s.generation,
                    left + 8, top + 74, 0xAAAAAA);
        }
        if (!s.messageKey.isEmpty()) {
            String arg = s.messageArg;
            Component msg = arg.isEmpty() ? Component.translatable(s.messageKey)
                    : Component.translatable(s.messageKey, arg.startsWith("@") ? Component.translatable(arg.substring(1)) : arg);
            List<FormattedCharSequence> lines = this.font.split(msg, W - 16);
            for (int i = 0; i < lines.size() && i < 2; i++) {
                g.drawString(this.font, lines.get(i), left + 8, top + 85 + i * 9, 0x55FF55);
            }
        }
    }
}
