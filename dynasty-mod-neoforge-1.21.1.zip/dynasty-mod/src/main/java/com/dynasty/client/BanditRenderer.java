package com.dynasty.client;

import com.dynasty.Dynasty;
import com.dynasty.entity.BanditEntity;

import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Raiders: thugs, archers and gunmen. */
public class BanditRenderer extends HumanoidMobRenderer<BanditEntity, GunnerModel<BanditEntity>> {
    private static final ResourceLocation[] TEXTURES = {
        Dynasty.id("textures/entity/bandit/thug.png"),
        Dynasty.id("textures/entity/bandit/archer.png"),
        Dynasty.id("textures/entity/bandit/gunman.png")
    };

    public BanditRenderer(EntityRendererProvider.Context context) {
        super(context, new GunnerModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BanditEntity entity) {
        return TEXTURES[Math.floorMod(entity.getKind(), TEXTURES.length)];
    }
}
