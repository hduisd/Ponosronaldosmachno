package com.dynasty.client;

import com.dynasty.net.CitizenSnapshot;
import com.dynasty.net.RealmSnapshot;

import net.minecraft.client.Minecraft;

/** Entry points called from the network handlers on the client. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openRealm(RealmSnapshot snapshot) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof RealmScreen screen) {
            screen.update(snapshot);
        } else if (snapshot.tab != RealmSnapshot.TAB_KEEP) {
            mc.setScreen(new RealmScreen(snapshot));
        }
    }

    public static void openCitizen(CitizenSnapshot snapshot) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof CitizenScreen screen && screen.entityId() == snapshot.entityId) {
            screen.update(snapshot);
        } else if (snapshot.messageKey.isEmpty()) {
            mc.setScreen(new CitizenScreen(snapshot));
        }
    }
}
