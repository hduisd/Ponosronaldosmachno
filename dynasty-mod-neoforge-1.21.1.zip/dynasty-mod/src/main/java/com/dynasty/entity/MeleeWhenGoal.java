package com.dynasty.entity;

import java.util.function.BooleanSupplier;

import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.PathfinderMob;

/** Melee attack that is only active while the condition holds. */
public class MeleeWhenGoal extends MeleeAttackGoal {
    private final BooleanSupplier enabled;

    public MeleeWhenGoal(PathfinderMob mob, double speed, boolean followEvenIfNotSeen, BooleanSupplier enabled) {
        super(mob, speed, followEvenIfNotSeen);
        this.enabled = enabled;
    }

    @Override
    public boolean canUse() {
        return enabled.getAsBoolean() && super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        return enabled.getAsBoolean() && super.canContinueToUse();
    }
}
