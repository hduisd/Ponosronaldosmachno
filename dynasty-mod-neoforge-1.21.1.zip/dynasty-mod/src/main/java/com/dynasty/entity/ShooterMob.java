package com.dynasty.entity;

import net.minecraft.world.entity.LivingEntity;

/** A mob that can use firearms/bows through {@link RangedShootGoal}. */
public interface ShooterMob {
    boolean usesRanged();

    double shootRange();

    int shootInterval();

    void shoot(LivingEntity target);
}
