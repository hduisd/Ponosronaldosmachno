package com.dynasty.entity;

import java.util.EnumSet;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;

/** Keeps a distance to the target and shoots at it. */
public class RangedShootGoal<T extends Mob & ShooterMob> extends Goal {
    private final T mob;
    private int cooldown;
    private int repath;

    public RangedShootGoal(T mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        return mob.usesRanged() && target != null && target.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        mob.setAggressive(true);
        cooldown = 20;
        repath = 0;
    }

    @Override
    public void stop() {
        mob.setAggressive(false);
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null) {
            return;
        }
        double distSqr = mob.distanceToSqr(target.getX(), target.getY(), target.getZ());
        boolean sees = mob.getSensing().hasLineOfSight(target);
        double range = mob.shootRange();
        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (distSqr > range * range * 0.64D || !sees) {
            if (--repath <= 0) {
                repath = 10;
                mob.getNavigation().moveTo(target, 1.0D);
            }
        } else {
            mob.getNavigation().stop();
        }
        if (cooldown > 0) {
            cooldown--;
        }
        if (cooldown <= 0 && sees && distSqr <= range * range) {
            mob.shoot(target);
            cooldown = mob.shootInterval();
        }
    }
}
