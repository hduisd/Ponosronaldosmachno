package com.dynasty.entity;

import java.util.UUID;

import javax.annotation.Nullable;

import com.dynasty.registry.ModItems;
import com.dynasty.util.Fx;
import com.dynasty.util.ItemUtil;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A rideable vehicle. It is a Mob so it gets vanilla movement physics; the controlling
 * player steers it like a horse (W/S = throttle, A/D = turn).
 */
public class VehicleEntity extends Mob {
    public static final int MAX_FUEL = 24000;

    private static final EntityDataAccessor<Integer> DATA_FUEL =
            SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);

    private final VehicleKind kind;
    @Nullable
    private UUID ownerId;
    private int fireCooldown;
    private double lastX;
    private double lastZ;

    public VehicleEntity(EntityType<? extends VehicleEntity> type, Level level, VehicleKind kind) {
        super(type, level);
        this.kind = kind;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes(VehicleKind k) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, k.health)
                .add(Attributes.MOVEMENT_SPEED, k.speed)
                .add(Attributes.ARMOR, k.armor)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.STEP_HEIGHT, 1.1D)
                .add(Attributes.FOLLOW_RANGE, 8.0D);
    }

    public VehicleKind getKind() {
        return kind;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_FUEL, 0);
    }

    public int getFuel() {
        return this.entityData.get(DATA_FUEL);
    }

    public void setFuel(int fuel) {
        this.entityData.set(DATA_FUEL, Math.max(0, Math.min(MAX_FUEL, fuel)));
    }

    @Nullable
    public UUID getOwnerId() {
        return ownerId;
    }

    public void setOwner(@Nullable UUID owner) {
        this.ownerId = owner;
    }

    // ---- riding --------------------------------------------------------------------------

    @Nullable
    public LivingEntity getControllingPassenger() {
        Entity first = this.getFirstPassenger();
        return first instanceof Player p ? p : null;
    }

    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().size() < kind.seats;
    }

    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        int index = Math.max(0, this.getPassengers().indexOf(passenger));
        index = Math.min(index, kind.seats - 1);
        double side = kind.seatX[index];
        double forward = kind.seatZ[index];
        Vec3 offset = new Vec3(side, 0.0D, forward).yRot(-this.getYRot() * ((float) Math.PI / 180.0F));
        callback.accept(passenger, this.getX() + offset.x, this.getY() + kind.seatY, this.getZ() + offset.z);
    }

    protected Vec3 getRiddenInput(Player player, Vec3 travelVector) {
        if (kind.usesFuel && getFuel() <= 0) {
            return Vec3.ZERO;
        }
        float forward = player.zza;
        if (forward < 0.0F) {
            forward *= 0.4F;
        }
        return new Vec3(0.0D, 0.0D, forward);
    }

    protected void tickRidden(Player player, Vec3 travelVector) {
        float steer = player.xxa;
        if (steer != 0.0F) {
            this.setYRot(this.getYRot() - steer * kind.turn);
        }
        this.setXRot(0.0F);
        this.yRotO = this.getYRot();
        this.yBodyRot = this.getYRot();
        this.yHeadRot = kind.hasCannon ? player.getYHeadRot() : this.getYRot();
    }

    protected float getRiddenSpeed(Player player) {
        return (float) this.getAttributeValue(Attributes.MOVEMENT_SPEED);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false;
    }

    // ---- interaction ---------------------------------------------------------------------

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        ItemStack held = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;
        if (player.isShiftKeyDown()) {
            if (ownerId == null || ownerId.equals(player.getUUID()) || creative) {
                pickUp(player);
                return InteractionResult.CONSUME;
            }
            return InteractionResult.PASS;
        }
        if (kind.usesFuel) {
            int value = fuelValue(held);
            if (value > 0) {
                if (getFuel() < MAX_FUEL) {
                    setFuel(getFuel() + value);
                    if (!creative) {
                        held.shrink(1);
                    }
                    Fx.sound(this, "item.bucket.fill_lava", 0.6F, 1.2F);
                }
                return InteractionResult.CONSUME;
            }
        }
        if (held.is(Items.IRON_INGOT) && this.getHealth() < this.getMaxHealth()) {
            this.heal(this.getMaxHealth() * 0.15F);
            if (!creative) {
                held.shrink(1);
            }
            Fx.sound(this, "block.anvil.use", 0.6F, 1.4F);
            return InteractionResult.CONSUME;
        }
        if (this.getPassengers().size() < kind.seats && !player.isPassenger()) {
            player.startRiding(this);
        }
        return InteractionResult.CONSUME;
    }

    private void pickUp(Player player) {
        ItemStack stack = new ItemStack(kind.item());
        if (!player.getInventory().add(stack)) {
            this.spawnAtLocation(stack);
        }
        this.discard();
    }

    public static int fuelValue(ItemStack stack) {
        Item item = stack.getItem();
        if (item == Items.COAL || item == Items.CHARCOAL) {
            return 1600;
        }
        if (item == Items.BLAZE_ROD) {
            return 2400;
        }
        if (item == Items.COAL_BLOCK) {
            return 14400;
        }
        if (item == ModItems.FUEL_CANISTER.get()) {
            return 6000;
        }
        return 0;
    }

    // ---- ticking -------------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        if (fireCooldown > 0) {
            fireCooldown--;
        }
        LivingEntity driver = getControllingPassenger();
        if (driver instanceof ServerPlayer sp) {
            double dx = this.getX() - lastX;
            double dz = this.getZ() - lastZ;
            if (kind.usesFuel && this.tickCount % 5 == 0 && dx * dx + dz * dz > 0.0004D && getFuel() > 0) {
                setFuel(getFuel() - 5);
            }
            if (this.tickCount % 10 == 0) {
                if (kind.usesFuel) {
                    sp.displayClientMessage(Component.translatable("vehicle.dynasty.hud",
                            getFuel() / 20, Math.round(this.getHealth()), Math.round(this.getMaxHealth())), true);
                } else {
                    sp.displayClientMessage(Component.translatable("vehicle.dynasty.hud_nofuel",
                            Math.round(this.getHealth()), Math.round(this.getMaxHealth())), true);
                }
            }
        }
        lastX = this.getX();
        lastZ = this.getZ();
    }

    /** Fires the main cannon (called when the driver presses the fire key). */
    public void fire(ServerPlayer player) {
        if (!kind.hasCannon || fireCooldown > 0 || getControllingPassenger() != player) {
            return;
        }
        boolean creative = player.getAbilities().instabuild;
        if (!creative && !ItemUtil.consume(player, ModItems.SHELL.get(), 1)) {
            player.displayClientMessage(Component.translatable("vehicle.dynasty.no_ammo"), true);
            return;
        }
        fireCooldown = 40;
        Vec3 look = player.getLookAngle();
        BulletEntity shell = new BulletEntity(this.level(), player);
        shell.configure(BulletEntity.Kind.SHELL, 16.0F);
        shell.setPos(this.getX() + look.x * 2.6D, this.getY() + 1.8D + look.y * 2.6D, this.getZ() + look.z * 2.6D);
        shell.shoot(look.x, look.y, look.z, 2.4F, 0.3F);
        this.level().addFreshEntity(shell);
        Fx.sound(this, "entity.generic.explode", 1.2F, 1.4F);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuel", getFuel());
        if (ownerId != null) {
            tag.putUUID("Owner", ownerId);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setFuel(tag.getInt("Fuel"));
        ownerId = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
    }
}
