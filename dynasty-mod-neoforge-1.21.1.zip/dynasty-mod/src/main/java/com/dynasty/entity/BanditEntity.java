package com.dynasty.entity;

import java.util.EnumSet;
import java.util.UUID;

import javax.annotation.Nullable;

import com.dynasty.registry.ModItems;
import com.dynasty.util.Fx;
import com.dynasty.util.Names;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** A raider sent against a realm. */
public class BanditEntity extends Monster implements ShooterMob {
    public static final int THUG = 0;
    public static final int ARCHER = 1;
    public static final int GUNMAN = 2;

    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(BanditEntity.class, EntityDataSerializers.INT);

    @Nullable
    private UUID realmOwner;
    @Nullable
    private BlockPos raidTarget;

    public BanditEntity(EntityType<? extends BanditEntity> type, Level level) {
        super(type, level);
        this.xpReward = 5;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 22.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_KIND, THUG);
    }

    public int getKind() {
        return this.entityData.get(DATA_KIND);
    }

    public void setKind(int kind) {
        this.entityData.set(DATA_KIND, kind);
        ItemStack main;
        switch (kind) {
            case ARCHER:
                main = new ItemStack(Items.BOW);
                break;
            case GUNMAN:
                main = new ItemStack(this.getRandom().nextBoolean() ? ModItems.FLINTLOCK_PISTOL.get() : ModItems.MUSKET.get());
                break;
            default:
                main = new ItemStack(this.getRandom().nextBoolean() ? Items.IRON_AXE : Items.STONE_SWORD);
                break;
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, main);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Nullable
    public UUID getRealmOwner() {
        return realmOwner;
    }

    public void setRealmOwner(@Nullable UUID realmOwner) {
        this.realmOwner = realmOwner;
        this.setPersistenceRequired();
        if (this.getCustomName() == null) {
            this.setCustomName(Component.literal(Names.random(false, this.getRandom())));
            this.setCustomNameVisible(false);
        }
    }

    @Nullable
    public BlockPos getRaidTarget() {
        return raidTarget;
    }

    public void setRaidTarget(@Nullable BlockPos raidTarget) {
        this.raidTarget = raidTarget;
    }

    // ---- ShooterMob ----------------------------------------------------------------------

    @Override
    public boolean usesRanged() {
        return getKind() != THUG;
    }

    @Override
    public double shootRange() {
        return getKind() == ARCHER ? 16.0D : 20.0D;
    }

    @Override
    public int shootInterval() {
        return getKind() == ARCHER ? 34 : 55;
    }

    @Override
    public void shoot(LivingEntity target) {
        boolean arrow = getKind() == ARCHER;
        BulletEntity bullet = new BulletEntity(this.level(), this);
        bullet.configure(arrow ? BulletEntity.Kind.ARROW : BulletEntity.Kind.BALL, arrow ? 4.0F : 7.0F);
        double dx = target.getX() - this.getX();
        double dy = target.getEyeY() - 0.1D - bullet.getY();
        double dz = target.getZ() - this.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        bullet.shoot(dx, dy + (arrow ? dist * 0.05D : 0.0D), dz, arrow ? 1.6F : 2.6F, arrow ? 10.0F : 5.0F);
        this.level().addFreshEntity(bullet);
        Fx.sound(this, arrow ? "entity.arrow.shoot" : "entity.firework_rocket.blast", 1.0F, 0.9F);
        this.swing(InteractionHand.MAIN_HAND);
    }

    // ---- AI ------------------------------------------------------------------------------

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeWhenGoal(this, 1.2D, false, () -> !usesRanged()));
        this.goalSelector.addGoal(1, new RangedShootGoal<BanditEntity>(this));
        this.goalSelector.addGoal(4, new MarchToTargetGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, SoldierEntity.class, true));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, CitizenEntity.class, true));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return realmOwner == null;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Kind", getKind());
        if (realmOwner != null) {
            tag.putUUID("RealmOwner", realmOwner);
        }
        if (raidTarget != null) {
            tag.putLong("RaidTarget", raidTarget.asLong());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_KIND, tag.getInt("Kind"));
        realmOwner = tag.hasUUID("RealmOwner") ? tag.getUUID("RealmOwner") : null;
        raidTarget = tag.contains("RaidTarget") ? BlockPos.of(tag.getLong("RaidTarget")) : null;
    }

    /** Raiders walk towards the town hall of the realm they attack until they find someone to fight. */
    static class MarchToTargetGoal extends Goal {
        private final BanditEntity bandit;
        private int recalc;

        MarchToTargetGoal(BanditEntity bandit) {
            this.bandit = bandit;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        private double distSqr() {
            BlockPos t = bandit.raidTarget;
            double dx = bandit.getX() - (t.getX() + 0.5D);
            double dz = bandit.getZ() - (t.getZ() + 0.5D);
            return dx * dx + dz * dz;
        }

        @Override
        public boolean canUse() {
            return bandit.raidTarget != null && bandit.getTarget() == null && distSqr() > 10.0D * 10.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return bandit.raidTarget != null && bandit.getTarget() == null && distSqr() > 6.0D * 6.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void tick() {
            if (--recalc <= 0) {
                recalc = 40;
                BlockPos t = bandit.raidTarget;
                bandit.getNavigation().moveTo(t.getX() + 0.5D, t.getY(), t.getZ() + 0.5D, 1.0D);
            }
        }
    }
}
