package com.dynasty.entity;

import java.util.EnumSet;
import java.util.UUID;

import javax.annotation.Nullable;

import com.dynasty.net.CitizenSnapshot;
import com.dynasty.net.Net;
import com.dynasty.realm.Profession;
import com.dynasty.realm.Realm;
import com.dynasty.realm.RealmData;
import com.dynasty.realm.RealmManager;
import com.dynasty.registry.ModItems;
import com.dynasty.util.Fx;
import com.dynasty.util.GiftTable;
import com.dynasty.util.Names;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * A subject of a realm. Citizens work, can be befriended, courted and married
 * (by the ruler or by each other) and have children that grow up.
 */
public class CitizenEntity extends AgeableMob {
    public static final int PARTNER_NONE = 0;
    public static final int PARTNER_PLAYER = 1;
    public static final int PARTNER_CITIZEN = 2;

    public static final int ACT_TALK = 0;
    public static final int ACT_GIFT = 1;
    public static final int ACT_DATE = 2;
    public static final int ACT_HUG = 3;
    public static final int ACT_PROPOSE = 4;
    public static final int ACT_PROFESSION = 5;

    private static final EntityDataAccessor<Integer> DATA_PROFESSION =
            SynchedEntityData.defineId(CitizenEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_FEMALE =
            SynchedEntityData.defineId(CitizenEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_SKIN =
            SynchedEntityData.defineId(CitizenEntity.class, EntityDataSerializers.INT);

    @Nullable
    private UUID owner;
    @Nullable
    private BlockPos home;
    private int affection;
    private int partnerKind;
    @Nullable
    private UUID partner;
    private String partnerName = "";
    private String parents = "";
    private int generation = 1;
    private int favGift = -1;
    private boolean playerChild;
    private long lastTalkDay = -1L;
    private long lastGiftDay = -1L;
    private long lastDateDay = -1L;
    private long lastHugDay = -1L;
    private long lastBirthDay = -1L;
    private long marriedDay = -1L;
    private long datingUntil = 0L;
    private int giftsToday = 0;

    public CitizenEntity(EntityType<? extends CitizenEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    private static final EntityDimensions BABY_DIMENSIONS = EntityDimensions.scalable(0.3F, 0.9F).withEyeHeight(0.8F);

    /** Children are half as tall as adults. */
    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        return this.isBaby() ? BABY_DIMENSIONS : super.getDefaultDimensions(pose);
    }

    // ---- synced data ---------------------------------------------------------------------

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_PROFESSION, 0);
        builder.define(DATA_FEMALE, false);
        builder.define(DATA_SKIN, 0);
    }

    public Profession getProfession() {
        return Profession.byIndex(this.entityData.get(DATA_PROFESSION));
    }

    public void setProfession(Profession profession) {
        this.entityData.set(DATA_PROFESSION, profession.ordinal());
        if (!this.level().isClientSide) {
            applyEquipment();
        }
    }

    public boolean isFemale() {
        return this.entityData.get(DATA_FEMALE);
    }

    public void setFemale(boolean female) {
        this.entityData.set(DATA_FEMALE, female);
    }

    public int getSkin() {
        return this.entityData.get(DATA_SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(DATA_SKIN, skin);
    }

    // ---- simple accessors ----------------------------------------------------------------

    @Nullable
    public UUID getOwnerId() {
        return owner;
    }

    public void setOwner(@Nullable UUID owner) {
        this.owner = owner;
    }

    @Nullable
    public BlockPos getHome() {
        return home;
    }

    public void setHome(@Nullable BlockPos home) {
        this.home = home;
    }

    public int getPartnerKind() {
        return partnerKind;
    }

    @Nullable
    public UUID getPartnerId() {
        return partner;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public boolean isMarried() {
        return partnerKind != PARTNER_NONE;
    }

    public int getAffection() {
        return affection;
    }

    public int getGeneration() {
        return generation;
    }

    public void setGeneration(int generation) {
        this.generation = Math.max(1, generation);
    }

    public void setParents(String parents) {
        this.parents = parents;
    }

    public boolean isPlayerChild() {
        return playerChild;
    }

    public void setPlayerChild(boolean playerChild) {
        this.playerChild = playerChild;
    }

    public long getLastBirthDay() {
        return lastBirthDay;
    }

    public void setLastBirthDay(long day) {
        this.lastBirthDay = day;
    }

    public long getMarriedDay() {
        return marriedDay;
    }

    public boolean isDating() {
        return datingUntil > this.level().getGameTime();
    }

    public String displayName() {
        Component n = this.getCustomName();
        return n == null ? "?" : n.getString();
    }

    /** Gives a fresh citizen a random look, name and favourite gift. */
    public void initCitizen(RandomSource rng) {
        setFemale(rng.nextBoolean());
        setSkin(rng.nextInt(2));
        if (favGift < 0) {
            favGift = rng.nextInt(GiftTable.favoriteCount());
        }
        if (this.getCustomName() == null) {
            this.setCustomName(Component.literal(Names.random(isFemale(), rng)));
            this.setCustomNameVisible(false);
        }
        applyEquipment();
    }

    private void applyEquipment() {
        ItemStack tool = ItemStack.EMPTY;
        if (!isBaby()) {
            switch (getProfession()) {
                case FARMER:
                    tool = new ItemStack(Items.IRON_HOE);
                    break;
                case LUMBERJACK:
                    tool = new ItemStack(Items.IRON_AXE);
                    break;
                case MINER:
                    tool = new ItemStack(Items.IRON_PICKAXE);
                    break;
                case MERCHANT:
                    tool = new ItemStack(Items.EMERALD);
                    break;
                case SCHOLAR:
                    tool = new ItemStack(Items.BOOK);
                    break;
                default:
                    break;
            }
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, tool);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    // ---- AI ------------------------------------------------------------------------------

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.35D));
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Monster.class, 10.0F, 1.0D, 1.3D));
        this.goalSelector.addGoal(2, new DateGoal(this));
        this.goalSelector.addGoal(3, new StayNearHomeGoal(this, 1.0D, 26.0D));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        long now = this.level().getGameTime();
        if (datingUntil != 0L && now >= datingUntil) {
            finishDate();
        }
        // citizens that wander too far away without a ruler nearby walk home
        if (home != null && this.tickCount % 200 == 0 && !isDating()) {
            double dx = this.getX() - (home.getX() + 0.5D);
            double dz = this.getZ() - (home.getZ() + 0.5D);
            if (dx * dx + dz * dz > 70.0D * 70.0D) {
                this.teleportTo(home.getX() + 0.5D, home.getY() + 1.0D, home.getZ() + 0.5D);
            }
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, new AgeableMob.AgeableMobGroupData(false));
        initCitizen(level.getRandom());
        return data;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return null;
    }

    @Override
    protected void ageBoundaryReached() {
        super.ageBoundaryReached();
        if (!this.level().isClientSide && !this.isBaby()) {
            Profession[] all = Profession.values();
            setProfession(all[1 + this.getRandom().nextInt(all.length - 1)]);
            RealmManager.onChildGrown(this);
        }
    }

    // ---- sounds --------------------------------------------------------------------------

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    // ---- interaction ---------------------------------------------------------------------

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer sp) {
            openFor(sp);
        }
        return InteractionResult.CONSUME;
    }

    private boolean checkOwner(ServerPlayer player) {
        Realm realm = RealmData.get(player.server).getRealm(player.getUUID());
        if (realm == null || !realm.hasHall()) {
            player.displayClientMessage(Component.translatable("message.dynasty.need_realm"), true);
            return false;
        }
        if (owner == null) {
            owner = player.getUUID();
            home = realm.hall;
        } else if (!owner.equals(player.getUUID())) {
            player.displayClientMessage(Component.translatable("citizen.dynasty.foreign"), true);
            return false;
        }
        return true;
    }

    public void openFor(ServerPlayer player) {
        if (!checkOwner(player)) {
            return;
        }
        Net.sendCitizen(player, snapshot(player, "", ""));
    }

    public CitizenSnapshot snapshot(ServerPlayer viewer, String msgKey, String msgArg) {
        CitizenSnapshot s = new CitizenSnapshot();
        s.entityId = this.getId();
        s.name = displayName();
        s.female = isFemale();
        s.baby = isBaby();
        s.profession = getProfession().ordinal();
        s.affection = affection;
        s.partnerKind = partnerKind;
        s.partnerName = partnerName;
        s.parents = parents;
        s.generation = generation;
        s.favoriteIndex = affection >= 20 ? favGift : -1;
        s.messageKey = msgKey;
        s.messageArg = msgArg;
        Realm realm = RealmData.get(viewer.server).getRealm(viewer.getUUID());
        s.happiness = realm == null ? 50 : realm.happiness;
        long today = RealmManager.today(viewer.server);
        boolean adult = !isBaby();
        int flags = 0;
        if (lastTalkDay != today) {
            flags |= CitizenSnapshot.F_TALK;
        }
        if (adult && GiftTable.value(viewer.getMainHandItem()) > 0) {
            flags |= CitizenSnapshot.F_GIFT;
        }
        if (adult && affection >= 25 && lastDateDay != today && !isDating()) {
            flags |= CitizenSnapshot.F_DATE;
        }
        boolean spouseOfViewer = partnerKind == PARTNER_PLAYER && viewer.getUUID().equals(partner);
        if (adult && lastHugDay != today && (spouseOfViewer || affection >= 85)) {
            flags |= CitizenSnapshot.F_HUG;
        }
        if (adult && partnerKind == PARTNER_NONE && affection >= 70 && realm != null && realm.spouse == null
                && viewer.getMainHandItem().is(ModItems.RING.get())) {
            flags |= CitizenSnapshot.F_PROPOSE;
        }
        if (adult) {
            flags |= CitizenSnapshot.F_PROFESSION;
        }
        s.flags = flags;
        return s;
    }

    public void handleAction(ServerPlayer player, int action) {
        if (!this.isAlive() || this.isRemoved()) {
            return;
        }
        if (player.distanceToSqr(this) > 64.0D) {
            player.displayClientMessage(Component.translatable("citizen.dynasty.too_far"), true);
            return;
        }
        if (!checkOwner(player)) {
            return;
        }
        Realm realm = RealmData.get(player.server).getRealm(player.getUUID());
        long today = RealmManager.today(player.server);
        ServerLevel sl = (ServerLevel) this.level();
        String key = "";
        String arg = "";
        boolean adult = !isBaby();

        switch (action) {
            case ACT_TALK: {
                if (lastTalkDay == today) {
                    key = "citizen.dynasty.already_talked";
                } else {
                    lastTalkDay = today;
                    if (adult) {
                        affection = Math.min(100, affection + 2 + this.getRandom().nextInt(3));
                    }
                    Fx.happy(sl, this);
                    key = pickDialogue(realm);
                }
                break;
            }
            case ACT_GIFT: {
                ItemStack held = player.getMainHandItem();
                int value = GiftTable.value(held);
                if (!adult) {
                    key = "citizen.dynasty.gift_baby";
                } else if (value <= 0) {
                    key = "citizen.dynasty.gift_none";
                } else if (lastGiftDay == today && giftsToday >= 2) {
                    key = "citizen.dynasty.gift_enough";
                } else {
                    boolean favorite = held.getItem() == GiftTable.favorite(favGift);
                    if (favorite) {
                        value *= 3;
                    }
                    if (lastGiftDay == today) {
                        value = Math.max(1, value / 3);
                    } else {
                        giftsToday = 0;
                    }
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                    lastGiftDay = today;
                    giftsToday++;
                    affection = Math.min(100, affection + value);
                    Fx.hearts(sl, this);
                    Fx.sound(this, "entity.villager.yes", 1.0F, 1.1F);
                    key = favorite ? "citizen.dynasty.gift_favorite" : "citizen.dynasty.gift_ok";
                }
                break;
            }
            case ACT_DATE: {
                if (!adult) {
                    key = "citizen.dynasty.gift_baby";
                } else if (affection < 25) {
                    key = "citizen.dynasty.date_low";
                } else if (lastDateDay == today || isDating()) {
                    key = "citizen.dynasty.date_done";
                } else {
                    lastDateDay = today;
                    datingUntil = this.level().getGameTime() + 2400L;
                    key = "citizen.dynasty.date_start";
                    Fx.happy(sl, this);
                }
                break;
            }
            case ACT_HUG: {
                boolean spouseOfViewer = partnerKind == PARTNER_PLAYER && player.getUUID().equals(partner);
                if (!adult || !(spouseOfViewer || affection >= 85)) {
                    key = "citizen.dynasty.hug_no";
                } else if (lastHugDay == today) {
                    key = "citizen.dynasty.hug_done";
                } else {
                    lastHugDay = today;
                    affection = Math.min(100, affection + 1);
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0));
                    Fx.hearts(sl, this);
                    Fx.sound(this, "entity.villager.celebrate", 1.0F, 1.0F);
                    key = "citizen.dynasty.hug_ok";
                }
                break;
            }
            case ACT_PROPOSE: {
                ItemStack held = player.getMainHandItem();
                if (!adult) {
                    key = "citizen.dynasty.gift_baby";
                } else if (partnerKind != PARTNER_NONE) {
                    key = "citizen.dynasty.propose_taken";
                } else if (realm != null && realm.spouse != null) {
                    key = "citizen.dynasty.propose_married";
                } else if (affection < 70) {
                    key = "citizen.dynasty.propose_low";
                } else if (!held.is(ModItems.RING.get())) {
                    key = "citizen.dynasty.propose_noring";
                } else {
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                    marryPlayer(player, realm, today);
                    key = "citizen.dynasty.propose_yes";
                }
                break;
            }
            case ACT_PROFESSION: {
                if (!adult) {
                    key = "citizen.dynasty.gift_baby";
                } else {
                    Profession next = getProfession().next();
                    setProfession(next);
                    key = "citizen.dynasty.profession_set";
                    arg = "@" + next.nameKey();
                }
                break;
            }
            default:
                break;
        }
        Net.sendCitizen(player, snapshot(player, key, arg));
    }

    private String pickDialogue(Realm realm) {
        int n = this.getRandom().nextInt(3);
        if (isBaby()) {
            return "dialogue.dynasty.child." + n;
        }
        if (partnerKind == PARTNER_PLAYER) {
            return "dialogue.dynasty.spouse." + n;
        }
        if (realm != null && realm.happiness < 35) {
            return "dialogue.dynasty.unhappy." + n;
        }
        if (affection >= 60) {
            return "dialogue.dynasty.love." + n;
        }
        return "dialogue.dynasty." + getProfession().id + "." + n;
    }

    private void marryPlayer(ServerPlayer player, Realm realm, long today) {
        partnerKind = PARTNER_PLAYER;
        partner = player.getUUID();
        partnerName = player.getName().getString();
        marriedDay = today;
        affection = 100;
        if (realm != null) {
            realm.spouse = this.getUUID();
            realm.spouseName = displayName();
            realm.prestige += 2;
            RealmData.get(player.server).setDirty();
        }
        ServerLevel sl = (ServerLevel) this.level();
        Fx.hearts(sl, this);
        Fx.hearts(sl, player);
        Fx.sound(this, "entity.player.levelup", 1.0F, 1.2F);
        player.server.getPlayerList().broadcastSystemMessage(
                Component.translatable("event.dynasty.wedding", player.getName(), displayName()), false);
    }

    /** Marries two citizens to each other (called by the daily realm update). */
    public void setPartnerCitizen(CitizenEntity other, long today) {
        this.partnerKind = PARTNER_CITIZEN;
        this.partner = other.getUUID();
        this.partnerName = other.displayName();
        this.marriedDay = today;
    }

    private void finishDate() {
        datingUntil = 0L;
        if (this.level() instanceof ServerLevel sl && owner != null) {
            Player p = this.level().getPlayerByUUID(owner);
            if (p instanceof ServerPlayer sp && this.distanceToSqr(sp) < 144.0D) {
                affection = Math.min(100, affection + (partnerKind == PARTNER_PLAYER ? 8 : 5));
                sp.displayClientMessage(Component.translatable("citizen.dynasty.date_end", displayName()), true);
                Fx.hearts(sl, this);
            }
        }
    }

    /** Called once per realm day. */
    public void dailyUpdate(long today) {
        if (lastGiftDay != today) {
            giftsToday = 0;
        }
        if (partnerKind == PARTNER_PLAYER) {
            if (affection < 60) {
                affection = 60;
            }
        } else if (!isBaby() && lastTalkDay < today - 3L && lastGiftDay < today - 3L && affection > 0) {
            affection--;
        }
    }

    // ---- persistence ---------------------------------------------------------------------

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Profession", getProfession().ordinal());
        tag.putBoolean("Female", isFemale());
        tag.putInt("Skin", getSkin());
        if (owner != null) {
            tag.putUUID("Owner", owner);
        }
        if (home != null) {
            tag.putLong("Home", home.asLong());
        }
        tag.putInt("Affection", affection);
        tag.putInt("PartnerKind", partnerKind);
        if (partner != null) {
            tag.putUUID("Partner", partner);
        }
        tag.putString("PartnerName", partnerName);
        tag.putString("Parents", parents);
        tag.putInt("Generation", generation);
        tag.putInt("FavGift", favGift);
        tag.putBoolean("PlayerChild", playerChild);
        tag.putLong("LastTalk", lastTalkDay);
        tag.putLong("LastGift", lastGiftDay);
        tag.putLong("LastDate", lastDateDay);
        tag.putLong("LastHug", lastHugDay);
        tag.putLong("LastBirth", lastBirthDay);
        tag.putLong("MarriedDay", marriedDay);
        tag.putInt("GiftsToday", giftsToday);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_PROFESSION, tag.getInt("Profession"));
        this.entityData.set(DATA_FEMALE, tag.getBoolean("Female"));
        this.entityData.set(DATA_SKIN, tag.getInt("Skin"));
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        home = tag.contains("Home") ? BlockPos.of(tag.getLong("Home")) : null;
        affection = tag.getInt("Affection");
        partnerKind = tag.getInt("PartnerKind");
        partner = tag.hasUUID("Partner") ? tag.getUUID("Partner") : null;
        partnerName = tag.getString("PartnerName");
        parents = tag.getString("Parents");
        generation = Math.max(1, tag.getInt("Generation"));
        favGift = tag.contains("FavGift") ? tag.getInt("FavGift") : -1;
        playerChild = tag.getBoolean("PlayerChild");
        lastTalkDay = tag.getLong("LastTalk");
        lastGiftDay = tag.getLong("LastGift");
        lastDateDay = tag.getLong("LastDate");
        lastHugDay = tag.getLong("LastHug");
        lastBirthDay = tag.getLong("LastBirth");
        marriedDay = tag.getLong("MarriedDay");
        giftsToday = tag.getInt("GiftsToday");
        if (favGift < 0) {
            favGift = this.getRandom().nextInt(GiftTable.favoriteCount());
        }
    }

    // ---- goals ---------------------------------------------------------------------------

    /** Follows the ruler while on a date. */
    static class DateGoal extends Goal {
        private final CitizenEntity citizen;
        private Player player;
        private int recalc;

        DateGoal(CitizenEntity citizen) {
            this.citizen = citizen;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (!citizen.isDating() || citizen.owner == null) {
                return false;
            }
            Player p = citizen.level().getPlayerByUUID(citizen.owner);
            if (p == null || p.isSpectator() || citizen.distanceToSqr(p) > 48.0D * 48.0D) {
                return false;
            }
            this.player = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return citizen.isDating() && player != null && player.isAlive()
                    && citizen.distanceToSqr(player) < 48.0D * 48.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            citizen.getNavigation().stop();
            player = null;
        }

        @Override
        public void tick() {
            citizen.getLookControl().setLookAt(player, 10.0F, (float) citizen.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (citizen.distanceToSqr(player) > 9.0D) {
                    citizen.getNavigation().moveTo(player, 1.1D);
                } else {
                    citizen.getNavigation().stop();
                }
            }
        }
    }

    /** Walks back towards the town hall when too far away. */
    static class StayNearHomeGoal extends Goal {
        private final CitizenEntity citizen;
        private final double speed;
        private final double maxDist;

        StayNearHomeGoal(CitizenEntity citizen, double speed, double maxDist) {
            this.citizen = citizen;
            this.speed = speed;
            this.maxDist = maxDist;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        private double distSqr() {
            BlockPos h = citizen.home;
            double dx = citizen.getX() - (h.getX() + 0.5D);
            double dz = citizen.getZ() - (h.getZ() + 0.5D);
            return dx * dx + dz * dz;
        }

        @Override
        public boolean canUse() {
            return citizen.home != null && !citizen.isDating() && distSqr() > maxDist * maxDist;
        }

        @Override
        public boolean canContinueToUse() {
            return citizen.home != null && !citizen.getNavigation().isDone() && distSqr() > (maxDist * 0.4D) * (maxDist * 0.4D);
        }

        @Override
        public void start() {
            BlockPos h = citizen.home;
            citizen.getNavigation().moveTo(h.getX() + 0.5D, h.getY(), h.getZ() + 0.5D, speed);
        }
    }
}
