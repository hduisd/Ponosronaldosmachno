package com.dynasty.entity;

import com.dynasty.registry.ModEntities;
import com.dynasty.registry.ModItems;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** A fired bullet, arrow, rocket, shell or thrown grenade. */
public class BulletEntity extends ThrowableItemProjectile {
    public enum Kind {
        BALL(false, 0.0F),
        CARTRIDGE(false, 0.0F),
        ARROW(false, 0.0F),
        ROCKET(true, 2.2F),
        GRENADE(true, 2.6F),
        SHELL(true, 3.0F);

        public final boolean explosive;
        public final float blast;

        Kind(boolean explosive, float blast) {
            this.explosive = explosive;
            this.blast = blast;
        }
    }

    private Kind kind = Kind.BALL;
    private float damage = 6.0F;

    public BulletEntity(EntityType<? extends BulletEntity> type, Level level) {
        super(type, level);
    }

    public BulletEntity(Level level, LivingEntity shooter) {
        super(ModEntities.BULLET.get(), shooter, level);
    }

    public void configure(Kind kind, float damage) {
        this.kind = kind;
        this.damage = damage;
        Item display;
        switch (kind) {
            case CARTRIDGE:
                display = ModItems.CARTRIDGE.get();
                break;
            case ARROW:
                display = Items.ARROW;
                break;
            case ROCKET:
                display = ModItems.ROCKET.get();
                break;
            case GRENADE:
                display = ModItems.GRENADE.get();
                break;
            case SHELL:
                display = ModItems.SHELL.get();
                break;
            default:
                display = ModItems.MUSKET_BALL.get();
                break;
        }
        this.setItem(new ItemStack(display));
        this.setNoGravity(kind == Kind.BALL || kind == Kind.CARTRIDGE || kind == Kind.ROCKET);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.MUSKET_BALL.get();
    }

    @Override
    public boolean canHitEntity(Entity target) {
        Entity owner = this.getOwner();
        if (owner != null && (target instanceof CitizenEntity || target instanceof SoldierEntity)) {
            if (owner instanceof SoldierEntity || owner instanceof net.minecraft.world.entity.player.Player) {
                return false;
            }
        }
        if (owner instanceof BanditEntity && target instanceof BanditEntity) {
            return false;
        }
        return super.canHitEntity(target);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            ItemStack shown = this.getItem();
            if (shown.is(ModItems.ROCKET.get()) || shown.is(ModItems.SHELL.get())) {
                this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), 0.0D, 0.0D, 0.0D);
            }
        } else if (this.tickCount > 100) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level().isClientSide) {
            return;
        }
        Entity target = result.getEntity();
        target.hurt(this.damageSources().thrown(this, this.getOwner()), damage);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (this.level().isClientSide) {
            return;
        }
        if (kind.explosive) {
            this.level().explode(this, this.getX(), this.getY(), this.getZ(), kind.blast, Level.ExplosionInteraction.NONE);
        }
        this.discard();
    }
}
