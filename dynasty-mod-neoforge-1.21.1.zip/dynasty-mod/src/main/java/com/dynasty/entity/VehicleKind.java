package com.dynasty.entity;

import java.util.Locale;

import com.dynasty.realm.Tech;
import com.dynasty.registry.ModEntities;
import com.dynasty.registry.ModItems;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;

/** Drivable vehicles. */
public enum VehicleKind {
    // tech, cost{coins,food,wood,stone,iron,fuel}, seats, hp, armor, speed, turn, fuel?, cannon?, w, h, seatY, seatX[], seatZ[]
    CART(null, new int[] {20, 0, 25, 0, 5, 0}, 2, 30.0, 0.0, 0.16, 3.4F, false, false, 1.6F, 1.2F, 0.60,
            new double[] {0.0, 0.0}, new double[] {0.35, -0.55}),
    JEEP(Tech.COMBUSTION, new int[] {120, 0, 0, 0, 40, 10}, 2, 60.0, 4.0, 0.34, 4.2F, true, false, 1.8F, 1.5F, 0.50,
            new double[] {0.32, -0.32}, new double[] {0.05, 0.05}),
    TRUCK(Tech.COMBUSTION, new int[] {180, 0, 10, 0, 60, 20}, 4, 90.0, 6.0, 0.26, 3.0F, true, false, 2.0F, 2.2F, 0.85,
            new double[] {0.35, -0.35, 0.0, 0.0}, new double[] {0.85, 0.85, -0.85, -1.55}),
    TANK(Tech.ARMOR, new int[] {400, 0, 0, 0, 150, 30}, 1, 220.0, 20.0, 0.17, 2.6F, true, true, 2.6F, 1.9F, 1.35,
            new double[] {0.0}, new double[] {0.0});

    public final String id;
    public final Tech tech;
    public final int[] cost;
    public final int seats;
    public final double health;
    public final double armor;
    public final double speed;
    public final float turn;
    public final boolean usesFuel;
    public final boolean hasCannon;
    public final float width;
    public final float height;
    public final double seatY;
    public final double[] seatX;
    public final double[] seatZ;

    VehicleKind(Tech tech, int[] cost, int seats, double health, double armor, double speed, float turn,
                boolean usesFuel, boolean hasCannon, float width, float height, double seatY,
                double[] seatX, double[] seatZ) {
        this.id = name().toLowerCase(Locale.ROOT);
        this.tech = tech;
        this.cost = cost;
        this.seats = seats;
        this.health = health;
        this.armor = armor;
        this.speed = speed;
        this.turn = turn;
        this.usesFuel = usesFuel;
        this.hasCannon = hasCannon;
        this.width = width;
        this.height = height;
        this.seatY = seatY;
        this.seatX = seatX;
        this.seatZ = seatZ;
    }

    public String nameKey() {
        return "entity.dynasty." + id;
    }

    public Item item() {
        return ModItems.VEHICLE_ITEMS.get(this).get();
    }

    public EntityType<VehicleEntity> entityType() {
        return ModEntities.VEHICLES.get(this).get();
    }

    public static VehicleKind byIndex(int i) {
        VehicleKind[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
