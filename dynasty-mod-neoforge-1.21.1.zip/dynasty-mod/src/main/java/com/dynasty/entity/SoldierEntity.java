package com.dynasty.entity;

import java.util.EnumSet;
import java.util.UUID;

import javax.annotation.Nullable;

import com.dynasty.realm.SoldierType;
import com.dynasty.registry.ModItems;
import com.dynasty.util.Fx;
import com.dynasty.util.Names;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** A recruited soldier that defends the realm and follows the ruler's orders. */
public class SoldierEntity extends PathfinderMob implements ShooterMob {
    public static final int MODE_FOLLOW = 0;
    public static final int MODE_POST = 1;

    private static final EntityDataAccessor<Integer> DATA_TYPE =
            SynchedEntityData.defineId(SoldierEntity.class, EntityDataSerializers.INT);

    @Nullable
    private UUID owner;
    private int mode = MODE_FOLLOW;
    @Nullable
    private BlockPos post;

    public SoldierEntity(EntityType<? extends SoldierEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 5.0D)
                .add(Attributes.ARMOR, 0.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_TYPE, 0);
    }

    public SoldierType getSoldierType() {
        return SoldierType.byIndex(this.entityData.get(DATA_TYPE));
    }

    public void setSoldierType(SoldierType type) {
        this.entityData.set(DATA_TYPE, type.ordinal());
        setBase(Attributes.MAX_HEALTH, type.health);
        setBase(Attributes.ATTACK_DAMAGE, type.damage);
        setBase(Attributes.ARMOR, type.armor);
        setBase(Attributes.MOVEMENT_SPEED, type.speed);
        this.setHealth(this.getMaxHealth());
        equip();
    }

    private void setBase(Holder<Attribute> attribute, double value) {
        AttributeInstance instance = this.getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    private void equip() {
        ItemStack main;
        switch (getSoldierType()) {
            case ARCHER:
                main = new ItemStack(Items.BOW);
                break;
            case KNIGHT:
                main = new ItemStack(ModItems.HALBERD.get());
                break;
            case MUSKETEER:
                main = new ItemStack(ModItems.MUSKET.get());
                break;
            case RIFLEMAN:
                main = new ItemStack(ModItems.RIFLE.get());
                break;
            case GUNNER:
                main = new ItemStack(ModItems.SMG.get());
                break;
            default:
                main = new ItemStack(Items.IRON_SWORD);
                break;
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, main);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    /** Creates a soldier of a type with a random name. */
    public void initSoldier(SoldierType type, @Nullable UUID owner, @Nullable BlockPos post) {
        this.owner = owner;
        this.post = post;
        setSoldierType(type);
        if (this.getCustomName() == null) {
            this.setCustomName(Component.literal(Names.random(false, this.getRandom())));
            this.setCustomNameVisible(false);
        }
    }

    @Nullable
    public UUID getOwnerId() {
        return owner;
    }

    public void setOwner(@Nullable UUID owner) {
        this.owner = owner;
    }

    public int getMode() {
        return mode;
    }

    public void orderFollow() {
        this.mode = MODE_FOLLOW;
    }

    public void orderPost(BlockPos pos) {
        this.mode = MODE_POST;
        this.post = pos;
    }

    // ---- ShooterMob ----------------------------------------------------------------------

    @Override
    public boolean usesRanged() {
        return !getSoldierType().melee;
    }

    @Override
    public double shootRange() {
        return getSoldierType().range;
    }

    @Override
    public int shootInterval() {
        return getSoldierType().interval;
    }

    @Override
    public void shoot(LivingEntity target) {
        SoldierType t = getSoldierType();
        BulletEntity.Kind kind;
        switch (t) {
            case ARCHER:
                kind = BulletEntity.Kind.ARROW;
                break;
            case MUSKETEER:
                kind = BulletEntity.Kind.BALL;
                break;
            default:
                kind = BulletEntity.Kind.CARTRIDGE;
                break;
        }
        BulletEntity bullet = new BulletEntity(this.level(), this);
        bullet.configure(kind, (float) t.damage);
        double dx = target.getX() - this.getX();
        double dy = target.getEyeY() - 0.1D - bullet.getY();
        double dz = target.getZ() - this.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        boolean arrow = kind == BulletEntity.Kind.ARROW;
        bullet.shoot(dx, dy + (arrow ? dist * 0.05D : 0.0D), dz, arrow ? 1.8F : 3.0F, arrow ? 6.0F : 2.0F);
        this.level().addFreshEntity(bullet);
        Fx.sound(this, arrow ? "entity.arrow.shoot" : "entity.firework_rocket.blast", 1.0F,
                0.9F + this.getRandom().nextFloat() * 0.3F);
        this.swing(InteractionHand.MAIN_HAND);
    }

    // ---- AI ------------------------------------------------------------------------------

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeWhenGoal(this, 1.2D, true, () -> getSoldierType().melee));
        this.goalSelector.addGoal(1, new RangedShootGoal<SoldierEntity>(this));
        this.goalSelector.addGoal(3, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(4, new ReturnToPostGoal(this));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false,
                e -> e instanceof Enemy && !(e instanceof SoldierEntity)));
    }

    private boolean isFriend(@Nullable LivingEntity other) {
        if (other == null || owner == null) {
            return false;
        }
        if (other instanceof Player p) {
            return owner.equals(p.getUUID());
        }
        if (other instanceof SoldierEntity s) {
            return owner.equals(s.owner);
        }
        if (other instanceof CitizenEntity c) {
            return owner.equals(c.getOwnerId());
        }
        return false;
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (isFriend(target)) {
            return;
        }
        super.setTarget(target);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof LivingEntity attacker && isFriend(attacker)) {
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer sp && owner != null && owner.equals(sp.getUUID())) {
            if (sp.isShiftKeyDown()) {
                sp.displayClientMessage(Component.translatable("soldier.dynasty.dismissed",
                        this.getDisplayName(), Component.translatable(getSoldierType().nameKey())), true);
                this.discard();
            } else {
                sp.displayClientMessage(Component.translatable("soldier.dynasty.info",
                        this.getDisplayName(), Component.translatable(getSoldierType().nameKey()),
                        Math.round(this.getHealth()), Math.round(this.getMaxHealth()),
                        Component.translatable(mode == MODE_FOLLOW ? "soldier.dynasty.mode.follow" : "soldier.dynasty.mode.post")), true);
            }
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SoldierType", getSoldierType().ordinal());
        if (owner != null) {
            tag.putUUID("Owner", owner);
        }
        tag.putInt("Mode", mode);
        if (post != null) {
            tag.putLong("Post", post.asLong());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_TYPE, tag.getInt("SoldierType"));
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        mode = tag.getInt("Mode");
        post = tag.contains("Post") ? BlockPos.of(tag.getLong("Post")) : null;
        SoldierType t = getSoldierType();
        setBase(Attributes.MAX_HEALTH, t.health);
        setBase(Attributes.ATTACK_DAMAGE, t.damage);
        setBase(Attributes.ARMOR, t.armor);
        setBase(Attributes.MOVEMENT_SPEED, t.speed);
        equip();
    }

    // ---- goals ---------------------------------------------------------------------------

    static class FollowOwnerGoal extends Goal {
        private final SoldierEntity soldier;
        private Player player;
        private int recalc;

        FollowOwnerGoal(SoldierEntity soldier) {
            this.soldier = soldier;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (soldier.mode != MODE_FOLLOW || soldier.owner == null || soldier.getTarget() != null) {
                return false;
            }
            Player p = soldier.level().getPlayerByUUID(soldier.owner);
            if (p == null || p.isSpectator() || soldier.distanceToSqr(p) < 25.0D) {
                return false;
            }
            this.player = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return soldier.mode == MODE_FOLLOW && soldier.getTarget() == null && player != null
                    && player.isAlive() && soldier.distanceToSqr(player) > 9.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            soldier.getNavigation().stop();
            player = null;
        }

        @Override
        public void tick() {
            if (--recalc <= 0) {
                recalc = 10;
                if (soldier.distanceToSqr(player) > 40.0D * 40.0D) {
                    soldier.teleportTo(player.getX(), player.getY(), player.getZ());
                } else {
                    soldier.getNavigation().moveTo(player, 1.15D);
                }
            }
        }
    }

    static class ReturnToPostGoal extends Goal {
        private final SoldierEntity soldier;

        ReturnToPostGoal(SoldierEntity soldier) {
            this.soldier = soldier;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (soldier.mode != MODE_POST || soldier.post == null || soldier.getTarget() != null) {
                return false;
            }
            return soldier.distanceToSqr(soldier.post.getX() + 0.5D, soldier.post.getY(), soldier.post.getZ() + 0.5D) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return soldier.mode == MODE_POST && soldier.getTarget() == null && !soldier.getNavigation().isDone();
        }

        @Override
        public void start() {
            soldier.getNavigation().moveTo(soldier.post.getX() + 0.5D, soldier.post.getY(), soldier.post.getZ() + 0.5D, 1.1D);
        }
    }
}
