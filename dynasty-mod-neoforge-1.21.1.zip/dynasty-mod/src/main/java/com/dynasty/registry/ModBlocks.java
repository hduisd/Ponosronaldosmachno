package com.dynasty.registry;

import java.util.EnumMap;
import java.util.Map;

import com.dynasty.Dynasty;
import com.dynasty.block.BuildingBlock;
import com.dynasty.realm.BuildingType;

import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Dynasty.MODID);

    public static final Map<BuildingType, DeferredBlock<BuildingBlock>> BUILDINGS = new EnumMap<>(BuildingType.class);

    static {
        for (BuildingType type : BuildingType.values()) {
            BUILDINGS.put(type, BLOCKS.registerBlock(type.id, props -> new BuildingBlock(props, type),
                    BlockBehaviour.Properties.of()
                            .mapColor(type.stone ? MapColor.STONE : MapColor.WOOD)
                            .strength(2.5F, 6.0F)
                            .pushReaction(PushReaction.BLOCK)
                            .sound(type.stone ? SoundType.STONE : SoundType.WOOD)));
        }
    }

    private ModBlocks() {}
}
