package com.dynasty.registry;

import java.util.EnumMap;
import java.util.Map;

import com.dynasty.Dynasty;
import com.dynasty.entity.BulletEntity;
import com.dynasty.entity.VehicleKind;
import com.dynasty.item.CommandBannerItem;
import com.dynasty.item.GrenadeItem;
import com.dynasty.item.GunItem;
import com.dynasty.item.RoyalScrollItem;
import com.dynasty.item.VehicleItem;
import com.dynasty.realm.BuildingType;
import com.dynasty.realm.Tech;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Dynasty.MODID);

    // ---- buildings -----------------------------------------------------------------------
    public static final Map<BuildingType, DeferredItem<BlockItem>> BUILDING_ITEMS = new EnumMap<>(BuildingType.class);

    static {
        for (BuildingType type : BuildingType.values()) {
            BUILDING_ITEMS.put(type, ITEMS.registerSimpleBlockItem(type.id, ModBlocks.BUILDINGS.get(type)));
        }
    }

    // ---- rule items ----------------------------------------------------------------------
    public static final DeferredItem<Item> COIN = ITEMS.registerSimpleItem("coin", new Item.Properties());
    public static final DeferredItem<Item> RING = ITEMS.registerSimpleItem("ring", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> FUEL_CANISTER = ITEMS.registerSimpleItem("fuel_canister", new Item.Properties().stacksTo(16));
    public static final DeferredItem<RoyalScrollItem> ROYAL_SCROLL = ITEMS.registerItem("royal_scroll",
            RoyalScrollItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<CommandBannerItem> COMMAND_BANNER = ITEMS.registerItem("command_banner",
            CommandBannerItem::new, new Item.Properties().stacksTo(1));

    // ---- ammunition ----------------------------------------------------------------------
    public static final DeferredItem<Item> MUSKET_BALL = ITEMS.registerSimpleItem("musket_ball", new Item.Properties());
    public static final DeferredItem<Item> CARTRIDGE = ITEMS.registerSimpleItem("cartridge", new Item.Properties());
    public static final DeferredItem<Item> ROCKET = ITEMS.registerSimpleItem("rocket", new Item.Properties());
    public static final DeferredItem<Item> SHELL = ITEMS.registerSimpleItem("shell", new Item.Properties());
    public static final DeferredItem<GrenadeItem> GRENADE = ITEMS.registerItem("grenade",
            GrenadeItem::new, new Item.Properties().stacksTo(16));

    // ---- weapons -------------------------------------------------------------------------
    public static final DeferredItem<GunItem> FLINTLOCK_PISTOL = ITEMS.registerItem("flintlock_pistol",
            p -> new GunItem(p, Tech.GUNPOWDER, () -> ModItems.MUSKET_BALL.get(), BulletEntity.Kind.BALL,
                    8.0F, 35, 3.0F, 3.0F, false, "entity.firework_rocket.blast", 1.15F),
            new Item.Properties().stacksTo(1));
    public static final DeferredItem<GunItem> MUSKET = ITEMS.registerItem("musket",
            p -> new GunItem(p, Tech.GUNPOWDER, () -> ModItems.MUSKET_BALL.get(), BulletEntity.Kind.BALL,
                    12.0F, 60, 1.0F, 3.6F, false, "entity.firework_rocket.large_blast", 0.8F),
            new Item.Properties().stacksTo(1));
    public static final DeferredItem<GunItem> RIFLE = ITEMS.registerItem("rifle",
            p -> new GunItem(p, Tech.RIFLING, () -> ModItems.CARTRIDGE.get(), BulletEntity.Kind.CARTRIDGE,
                    10.0F, 22, 0.3F, 4.2F, false, "entity.firework_rocket.blast", 0.9F),
            new Item.Properties().stacksTo(1));
    public static final DeferredItem<GunItem> SMG = ITEMS.registerItem("smg",
            p -> new GunItem(p, Tech.AUTOMATIC, () -> ModItems.CARTRIDGE.get(), BulletEntity.Kind.CARTRIDGE,
                    4.5F, 3, 4.0F, 3.8F, true, "entity.firework_rocket.blast", 1.4F),
            new Item.Properties().stacksTo(1));
    public static final DeferredItem<GunItem> BAZOOKA = ITEMS.registerItem("bazooka",
            p -> new GunItem(p, Tech.EXPLOSIVES, () -> ModItems.ROCKET.get(), BulletEntity.Kind.ROCKET,
                    14.0F, 50, 1.0F, 2.0F, false, "entity.firework_rocket.launch", 0.7F),
            new Item.Properties().stacksTo(1));
    public static final DeferredItem<SwordItem> HALBERD = ITEMS.registerItem("halberd",
            p -> new SwordItem(Tiers.IRON, p.attributes(SwordItem.createAttributes(Tiers.IRON, 5, -2.9F))),
            new Item.Properties());

    // ---- vehicles ------------------------------------------------------------------------
    public static final Map<VehicleKind, DeferredItem<VehicleItem>> VEHICLE_ITEMS = new EnumMap<>(VehicleKind.class);

    static {
        for (VehicleKind kind : VehicleKind.values()) {
            VEHICLE_ITEMS.put(kind, ITEMS.registerItem(kind.id, p -> new VehicleItem(p, kind),
                    new Item.Properties().stacksTo(1)));
        }
    }

    // ---- spawn eggs ----------------------------------------------------------------------
    public static final DeferredItem<DeferredSpawnEggItem> CITIZEN_SPAWN_EGG = ITEMS.register("citizen_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CITIZEN, 0xD9B38C, 0x3E6BA8, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> SOLDIER_SPAWN_EGG = ITEMS.register("soldier_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SOLDIER, 0x5B6B3A, 0xC2B280, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> BANDIT_SPAWN_EGG = ITEMS.register("bandit_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BANDIT, 0x4A2C2A, 0xA33B3B, new Item.Properties()));

    private ModItems() {}
}
