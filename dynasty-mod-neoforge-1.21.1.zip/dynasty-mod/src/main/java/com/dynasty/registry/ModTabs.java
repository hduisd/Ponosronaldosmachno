package com.dynasty.registry;

import com.dynasty.Dynasty;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Dynasty.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DYNASTY_TAB = TABS.register("dynasty",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.dynasty"))
                    .icon(() -> ModItems.ROYAL_SCROLL.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        ModItems.ITEMS.getEntries().forEach(entry -> output.accept(entry.get()));
                    })
                    .build());

    private ModTabs() {}
}
