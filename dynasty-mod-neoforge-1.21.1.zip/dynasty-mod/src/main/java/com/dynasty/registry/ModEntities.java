package com.dynasty.registry;

import java.util.EnumMap;
import java.util.Map;

import com.dynasty.Dynasty;
import com.dynasty.entity.BanditEntity;
import com.dynasty.entity.BulletEntity;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.entity.SoldierEntity;
import com.dynasty.entity.VehicleEntity;
import com.dynasty.entity.VehicleKind;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, Dynasty.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<CitizenEntity>> CITIZEN =
            ENTITY_TYPES.register("citizen", () -> EntityType.Builder.of(CitizenEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("citizen"));

    public static final DeferredHolder<EntityType<?>, EntityType<SoldierEntity>> SOLDIER =
            ENTITY_TYPES.register("soldier", () -> EntityType.Builder.of(SoldierEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("soldier"));

    public static final DeferredHolder<EntityType<?>, EntityType<BanditEntity>> BANDIT =
            ENTITY_TYPES.register("bandit", () -> EntityType.Builder.of(BanditEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("bandit"));

    public static final DeferredHolder<EntityType<?>, EntityType<BulletEntity>> BULLET =
            ENTITY_TYPES.register("bullet", () -> EntityType.Builder.<BulletEntity>of(BulletEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10).build("bullet"));

    public static final Map<VehicleKind, DeferredHolder<EntityType<?>, EntityType<VehicleEntity>>> VEHICLES =
            new EnumMap<>(VehicleKind.class);

    static {
        for (VehicleKind kind : VehicleKind.values()) {
            VEHICLES.put(kind, ENTITY_TYPES.register(kind.id, () -> EntityType.Builder
                    .<VehicleEntity>of((type, level) -> new VehicleEntity(type, level, kind), MobCategory.MISC)
                    .sized(kind.width, kind.height).clientTrackingRange(10).updateInterval(2).build(kind.id)));
        }
    }

    private ModEntities() {}
}
