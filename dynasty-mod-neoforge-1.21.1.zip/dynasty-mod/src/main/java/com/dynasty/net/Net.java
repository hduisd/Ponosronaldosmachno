package com.dynasty.net;

import com.dynasty.Dynasty;
import com.dynasty.client.ClientHooks;
import com.dynasty.entity.CitizenEntity;
import com.dynasty.entity.VehicleEntity;
import com.dynasty.realm.RealmManager;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Registers the network payloads of the mod and routes them to the game logic. */
@EventBusSubscriber(modid = Dynasty.MODID)
public final class Net {
    private Net() {}

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(OpenRealmPayload.TYPE, OpenRealmPayload.STREAM_CODEC, Net::onOpenRealm);
        registrar.playToClient(OpenCitizenPayload.TYPE, OpenCitizenPayload.STREAM_CODEC, Net::onOpenCitizen);
        registrar.playToServer(RealmActionPayload.TYPE, RealmActionPayload.STREAM_CODEC, Net::onRealmAction);
        registrar.playToServer(CitizenActionPayload.TYPE, CitizenActionPayload.STREAM_CODEC, Net::onCitizenAction);
        registrar.playToServer(FireVehiclePayload.TYPE, FireVehiclePayload.STREAM_CODEC, Net::onFireVehicle);
    }

    // ---- sending -------------------------------------------------------------------------

    public static void sendRealm(ServerPlayer player, RealmSnapshot snapshot) {
        PacketDistributor.sendToPlayer(player, new OpenRealmPayload(snapshot));
    }

    public static void sendCitizen(ServerPlayer player, CitizenSnapshot snapshot) {
        PacketDistributor.sendToPlayer(player, new OpenCitizenPayload(snapshot));
    }

    // ---- client side handlers ------------------------------------------------------------

    private static void onOpenRealm(OpenRealmPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            ClientHooks.openRealm(payload.snapshot());
        });
    }

    private static void onOpenCitizen(OpenCitizenPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            ClientHooks.openCitizen(payload.snapshot());
        });
    }

    // ---- server side handlers ------------------------------------------------------------

    private static void onRealmAction(RealmActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                RealmManager.handleAction(player, payload.action(), payload.arg1(), payload.arg2(), payload.arg3());
            }
        });
    }

    private static void onCitizenAction(CitizenActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                Entity entity = player.level().getEntity(payload.entityId());
                if (entity instanceof CitizenEntity citizen) {
                    citizen.handleAction(player, payload.action());
                }
            }
        });
    }

    private static void onFireVehicle(FireVehiclePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player && player.getVehicle() instanceof VehicleEntity vehicle) {
                vehicle.fire(player);
            }
        });
    }
}
