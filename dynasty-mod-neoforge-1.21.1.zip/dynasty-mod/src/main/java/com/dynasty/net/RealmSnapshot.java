package com.dynasty.net;

import java.util.ArrayList;
import java.util.List;

import com.dynasty.realm.Faction;
import com.dynasty.realm.Profession;
import com.dynasty.realm.Realm;
import com.dynasty.realm.SoldierType;

import net.minecraft.network.FriendlyByteBuf;

/** Everything the realm screen needs to know (server to client). */
public final class RealmSnapshot {
    public static final int TAB_KEEP = -1;
    public static final long NO_FOCUS = Long.MIN_VALUE;

    public int tab = TAB_KEEP;
    public long focus = NO_FOCUS;
    public String message = "";

    public String ownerName = "";
    public int day;
    public final int[] res = new int[Realm.RES_COUNT];
    public final int[] income = new int[Realm.RES_COUNT];
    public int science;
    public int happiness;
    public int population;
    public int babies;
    public int capacity;
    public int prestige;
    public int generation = 1;
    public int armyCap;
    public int defense;
    public int upkeepCoins;
    public final int[] soldiers = new int[SoldierType.values().length];
    public final int[] jobs = new int[Profession.values().length];
    public String researching = "";
    public int progress;
    public int techBits;
    public int edicts;
    public final int[] relation = new int[Faction.COUNT];
    public final int[] status = new int[Faction.COUNT];
    public int garageLevels;
    public int hallLevel = 1;
    public int raidSize;
    public int raidKills;
    public String spouseName = "";
    public String heirName = "";
    public int childrenBorn;
    public int adultChildren;
    public final List<String> family = new ArrayList<>();
    public final List<String> report = new ArrayList<>();
    public final List<Integer> bType = new ArrayList<>();
    public final List<Integer> bLevel = new ArrayList<>();
    public final List<Long> bPos = new ArrayList<>();

    public boolean knows(int techIndex) {
        return (techBits & (1 << techIndex)) != 0;
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeVarInt(tab + 1);
        buf.writeLong(focus);
        buf.writeUtf(message);
        buf.writeUtf(ownerName);
        buf.writeVarInt(day);
        for (int v : res) {
            buf.writeVarInt(v);
        }
        for (int v : income) {
            buf.writeInt(v);
        }
        buf.writeInt(science);
        buf.writeVarInt(happiness);
        buf.writeVarInt(population);
        buf.writeVarInt(babies);
        buf.writeVarInt(capacity);
        buf.writeVarInt(prestige);
        buf.writeVarInt(generation);
        buf.writeVarInt(armyCap);
        buf.writeVarInt(defense);
        buf.writeVarInt(upkeepCoins);
        for (int v : soldiers) {
            buf.writeVarInt(v);
        }
        for (int v : jobs) {
            buf.writeVarInt(v);
        }
        buf.writeUtf(researching);
        buf.writeVarInt(progress);
        buf.writeInt(techBits);
        buf.writeVarInt(edicts);
        for (int v : relation) {
            buf.writeInt(v);
        }
        for (int v : status) {
            buf.writeVarInt(v);
        }
        buf.writeVarInt(garageLevels);
        buf.writeVarInt(hallLevel);
        buf.writeVarInt(raidSize);
        buf.writeVarInt(raidKills);
        buf.writeUtf(spouseName);
        buf.writeUtf(heirName);
        buf.writeVarInt(childrenBorn);
        buf.writeVarInt(adultChildren);
        buf.writeVarInt(family.size());
        for (String s : family) {
            buf.writeUtf(s);
        }
        buf.writeVarInt(report.size());
        for (String s : report) {
            buf.writeUtf(s);
        }
        buf.writeVarInt(bType.size());
        for (int i = 0; i < bType.size(); i++) {
            buf.writeVarInt(bType.get(i));
            buf.writeVarInt(bLevel.get(i));
            buf.writeLong(bPos.get(i));
        }
    }

    public static RealmSnapshot read(FriendlyByteBuf buf) {
        RealmSnapshot s = new RealmSnapshot();
        s.tab = buf.readVarInt() - 1;
        s.focus = buf.readLong();
        s.message = buf.readUtf();
        s.ownerName = buf.readUtf();
        s.day = buf.readVarInt();
        for (int i = 0; i < s.res.length; i++) {
            s.res[i] = buf.readVarInt();
        }
        for (int i = 0; i < s.income.length; i++) {
            s.income[i] = buf.readInt();
        }
        s.science = buf.readInt();
        s.happiness = buf.readVarInt();
        s.population = buf.readVarInt();
        s.babies = buf.readVarInt();
        s.capacity = buf.readVarInt();
        s.prestige = buf.readVarInt();
        s.generation = buf.readVarInt();
        s.armyCap = buf.readVarInt();
        s.defense = buf.readVarInt();
        s.upkeepCoins = buf.readVarInt();
        for (int i = 0; i < s.soldiers.length; i++) {
            s.soldiers[i] = buf.readVarInt();
        }
        for (int i = 0; i < s.jobs.length; i++) {
            s.jobs[i] = buf.readVarInt();
        }
        s.researching = buf.readUtf();
        s.progress = buf.readVarInt();
        s.techBits = buf.readInt();
        s.edicts = buf.readVarInt();
        for (int i = 0; i < s.relation.length; i++) {
            s.relation[i] = buf.readInt();
        }
        for (int i = 0; i < s.status.length; i++) {
            s.status[i] = buf.readVarInt();
        }
        s.garageLevels = buf.readVarInt();
        s.hallLevel = buf.readVarInt();
        s.raidSize = buf.readVarInt();
        s.raidKills = buf.readVarInt();
        s.spouseName = buf.readUtf();
        s.heirName = buf.readUtf();
        s.childrenBorn = buf.readVarInt();
        s.adultChildren = buf.readVarInt();
        int n = buf.readVarInt();
        for (int i = 0; i < n; i++) {
            s.family.add(buf.readUtf());
        }
        n = buf.readVarInt();
        for (int i = 0; i < n; i++) {
            s.report.add(buf.readUtf());
        }
        n = buf.readVarInt();
        for (int i = 0; i < n; i++) {
            s.bType.add(buf.readVarInt());
            s.bLevel.add(buf.readVarInt());
            s.bPos.add(buf.readLong());
        }
        return s;
    }
}
