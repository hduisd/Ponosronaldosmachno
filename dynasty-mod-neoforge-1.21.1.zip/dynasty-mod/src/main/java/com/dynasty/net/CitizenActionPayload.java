package com.dynasty.net;

import com.dynasty.Dynasty;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client to server: a button press in the citizen screen. */
public record CitizenActionPayload(int entityId, int action) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<CitizenActionPayload> TYPE =
            new CustomPacketPayload.Type<>(Dynasty.id("citizen_action"));

    public static final StreamCodec<FriendlyByteBuf, CitizenActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public CitizenActionPayload decode(FriendlyByteBuf buf) {
            return new CitizenActionPayload(buf.readInt(), buf.readVarInt());
        }

        @Override
        public void encode(FriendlyByteBuf buf, CitizenActionPayload payload) {
            buf.writeInt(payload.entityId());
            buf.writeVarInt(payload.action());
        }
    };

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
