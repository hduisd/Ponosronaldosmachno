package com.dynasty.net;

import com.dynasty.Dynasty;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server to client: open or refresh the citizen screen. */
public record OpenCitizenPayload(CitizenSnapshot snapshot) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<OpenCitizenPayload> TYPE =
            new CustomPacketPayload.Type<>(Dynasty.id("open_citizen"));

    public static final StreamCodec<FriendlyByteBuf, OpenCitizenPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public OpenCitizenPayload decode(FriendlyByteBuf buf) {
            return new OpenCitizenPayload(CitizenSnapshot.read(buf));
        }

        @Override
        public void encode(FriendlyByteBuf buf, OpenCitizenPayload payload) {
            payload.snapshot().write(buf);
        }
    };

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
