package com.dynasty.net;

import com.dynasty.Dynasty;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client to server: a button press in the realm screen. */
public record RealmActionPayload(int action, int arg1, int arg2, long arg3) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<RealmActionPayload> TYPE =
            new CustomPacketPayload.Type<>(Dynasty.id("realm_action"));

    public static final StreamCodec<FriendlyByteBuf, RealmActionPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public RealmActionPayload decode(FriendlyByteBuf buf) {
            return new RealmActionPayload(buf.readVarInt(), buf.readInt(), buf.readInt(), buf.readLong());
        }

        @Override
        public void encode(FriendlyByteBuf buf, RealmActionPayload payload) {
            buf.writeVarInt(payload.action());
            buf.writeInt(payload.arg1());
            buf.writeInt(payload.arg2());
            buf.writeLong(payload.arg3());
        }
    };

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
