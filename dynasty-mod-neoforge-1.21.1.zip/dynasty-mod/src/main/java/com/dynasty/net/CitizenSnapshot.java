package com.dynasty.net;

import net.minecraft.network.FriendlyByteBuf;

/** Everything the citizen interaction screen needs to know (server to client). */
public final class CitizenSnapshot {
    public static final int F_TALK = 1;
    public static final int F_GIFT = 2;
    public static final int F_DATE = 4;
    public static final int F_HUG = 8;
    public static final int F_PROPOSE = 16;
    public static final int F_PROFESSION = 32;

    public int entityId;
    public String name = "";
    public boolean female;
    public boolean baby;
    public int profession;
    public int affection;
    public int partnerKind;
    public String partnerName = "";
    public String parents = "";
    public int generation = 1;
    public int favoriteIndex = -1;
    public int flags;
    public int happiness;
    public String messageKey = "";
    public String messageArg = "";

    public void write(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeUtf(name);
        buf.writeBoolean(female);
        buf.writeBoolean(baby);
        buf.writeInt(profession);
        buf.writeInt(affection);
        buf.writeInt(partnerKind);
        buf.writeUtf(partnerName);
        buf.writeUtf(parents);
        buf.writeInt(generation);
        buf.writeInt(favoriteIndex);
        buf.writeInt(flags);
        buf.writeInt(happiness);
        buf.writeUtf(messageKey);
        buf.writeUtf(messageArg);
    }

    public static CitizenSnapshot read(FriendlyByteBuf buf) {
        CitizenSnapshot s = new CitizenSnapshot();
        s.entityId = buf.readInt();
        s.name = buf.readUtf();
        s.female = buf.readBoolean();
        s.baby = buf.readBoolean();
        s.profession = buf.readInt();
        s.affection = buf.readInt();
        s.partnerKind = buf.readInt();
        s.partnerName = buf.readUtf();
        s.parents = buf.readUtf();
        s.generation = buf.readInt();
        s.favoriteIndex = buf.readInt();
        s.flags = buf.readInt();
        s.happiness = buf.readInt();
        s.messageKey = buf.readUtf();
        s.messageArg = buf.readUtf();
        return s;
    }

    public boolean can(int flag) {
        return (flags & flag) != 0;
    }
}
