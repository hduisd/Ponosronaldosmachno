package com.dynasty.net;

import com.dynasty.Dynasty;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client to server: the driver pressed the fire key. */
public record FireVehiclePayload() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<FireVehiclePayload> TYPE =
            new CustomPacketPayload.Type<>(Dynasty.id("fire_vehicle"));

    public static final StreamCodec<FriendlyByteBuf, FireVehiclePayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public FireVehiclePayload decode(FriendlyByteBuf buf) {
            return new FireVehiclePayload();
        }

        @Override
        public void encode(FriendlyByteBuf buf, FireVehiclePayload payload) {
        }
    };

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
