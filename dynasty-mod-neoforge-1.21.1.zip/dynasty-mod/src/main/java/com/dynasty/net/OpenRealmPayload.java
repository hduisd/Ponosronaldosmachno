package com.dynasty.net;

import com.dynasty.Dynasty;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server to client: open or refresh the realm screen. */
public record OpenRealmPayload(RealmSnapshot snapshot) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<OpenRealmPayload> TYPE =
            new CustomPacketPayload.Type<>(Dynasty.id("open_realm"));

    public static final StreamCodec<FriendlyByteBuf, OpenRealmPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public OpenRealmPayload decode(FriendlyByteBuf buf) {
            return new OpenRealmPayload(RealmSnapshot.read(buf));
        }

        @Override
        public void encode(FriendlyByteBuf buf, OpenRealmPayload payload) {
            payload.snapshot().write(buf);
        }
    };

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
