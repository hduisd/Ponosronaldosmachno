package com.dynasty;

import com.dynasty.registry.ModBlocks;
import com.dynasty.registry.ModEntities;
import com.dynasty.registry.ModItems;
import com.dynasty.registry.ModTabs;
import com.mojang.logging.LogUtils;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;

/** Dynasty: a strategy and management mod. */
@Mod(Dynasty.MODID)
public class Dynasty {
    public static final String MODID = "dynasty";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Dynasty(IEventBus modBus, ModContainer container) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModTabs.TABS.register(modBus);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
